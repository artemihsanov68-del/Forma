import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { format } from "date-fns";
import { db } from "@/db";
import { foodCatalog, nutritionEntries } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { getNutritionForDate, getProfileWithTargets } from "@/lib/stats";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  await ensureSeeded();
  const date = new URL(req.url).searchParams.get("date") ?? format(new Date(), "yyyy-MM-dd");
  const [day, { targets }] = await Promise.all([getNutritionForDate(date), getProfileWithTargets()]);
  return NextResponse.json({ date, ...day, targets });
}

export async function POST(req: Request) {
  await ensureSeeded();
  const body = (await req.json()) as {
    date?: string;
    meal?: string;
    name?: string;
    grams?: number;
    foodId?: number;
    kcal?: number;
    protein?: number;
    fat?: number;
    carbs?: number;
  };

  const date = body.date ?? format(new Date(), "yyyy-MM-dd");
  const grams = Number(body.grams) || 100;
  let kcal = Number(body.kcal) || 0;
  let protein = Number(body.protein) || 0;
  let fat = Number(body.fat) || 0;
  let carbs = Number(body.carbs) || 0;
  let name = body.name?.trim() ?? "";

  if (body.foodId) {
    const [food] = await db.select().from(foodCatalog).where(eq(foodCatalog.id, body.foodId));
    if (food) {
      const k = grams / (food.perGrams || 100);
      name = name || food.name;
      kcal = Math.round(food.kcal * k);
      protein = Math.round(food.protein * k * 10) / 10;
      fat = Math.round(food.fat * k * 10) / 10;
      carbs = Math.round(food.carbs * k * 10) / 10;
    }
  }

  if (!name) return NextResponse.json({ error: "Укажите продукт" }, { status: 400 });

  const [entry] = await db
    .insert(nutritionEntries)
    .values({
      date,
      meal: body.meal ?? "snack",
      name,
      grams,
      kcal,
      protein,
      fat,
      carbs,
    })
    .returning();

  const day = await getNutritionForDate(date);
  return NextResponse.json({ entry, date, ...day });
}

export async function DELETE(req: Request) {
  await ensureSeeded();
  const id = Number(new URL(req.url).searchParams.get("id"));
  if (!id) return NextResponse.json({ error: "Нужен id" }, { status: 400 });
  const [row] = await db.select().from(nutritionEntries).where(eq(nutritionEntries.id, id));
  await db.delete(nutritionEntries).where(eq(nutritionEntries.id, id));
  const date = row?.date ?? format(new Date(), "yyyy-MM-dd");
  const day = await getNutritionForDate(date);
  return NextResponse.json({ ok: true, date, ...day });
}
