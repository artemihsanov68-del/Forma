import type { MetadataRoute } from "next";

/** Absolute URLs make the manifest more robust across Android and iOS installers. */
function siteUrl() {
  const raw = process.env.NEXT_PUBLIC_SITE_URL?.trim();
  if (!raw) return null;
  try {
    const parsed = new URL(raw.startsWith("http") ? raw : `https://${raw}`);
    return parsed.origin;
  } catch {
    return null;
  }
}

const base = siteUrl();

const icon = (path: string) => (base ? `${base}${path}` : path);
const shortcut = (path: string) => (base ? `${base}${path}` : path);

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "FORMA — тренировки, КБЖУ и ИИ-анализ",
    short_name: "FORMA",
    description:
      "Дневник тренировок, учёт калорий и БЖУ, обхваты тела, графики прогрессии и ИИ-разбор тренинга и питания.",
    id: "/",
    start_url: base ? `${base}/` : "/",
    scope: base ? `${base}/` : "/",
    display: "standalone",
    display_override: ["standalone", "minimal-ui"],
    orientation: "portrait",
    background_color: "#05060c",
    theme_color: "#05060c",
    lang: "ru",
    dir: "ltr",
    categories: ["health", "fitness", "lifestyle", "productivity"],
    icons: [
      {
        src: icon("/icons/icon-192.png"),
        sizes: "192x192",
        type: "image/png",
        purpose: "any",
      },
      {
        src: icon("/icons/icon-512.png"),
        sizes: "512x512",
        type: "image/png",
        purpose: "any",
      },
      {
        src: icon("/icons/icon-maskable-512.png"),
        sizes: "512x512",
        type: "image/png",
        purpose: "maskable",
      },
    ],
    shortcuts: [
      {
        name: "Новая тренировка",
        short_name: "Тренировка",
        description: "Записать подходы и объём",
        url: shortcut("/workouts?new=1"),
        icons: [{ src: icon("/icons/icon-192.png"), sizes: "192x192" }],
      },
      {
        name: "Добавить еду",
        short_name: "Питание",
        description: "Записать приём пищи в дневник КБЖУ",
        url: shortcut("/nutrition?add=1"),
        icons: [{ src: icon("/icons/icon-192.png"), sizes: "192x192" }],
      },
      {
        name: "Новый замер",
        short_name: "Обхваты",
        description: "Записать обхваты тела",
        url: shortcut("/body?add=1"),
        icons: [{ src: icon("/icons/icon-192.png"), sizes: "192x192" }],
      },
      {
        name: "ИИ-тренер",
        short_name: "ИИ-анализ",
        description: "Разбор тренировок и питания",
        url: shortcut("/coach"),
        icons: [{ src: icon("/icons/icon-192.png"), sizes: "192x192" }],
      },
    ],
  };
}
