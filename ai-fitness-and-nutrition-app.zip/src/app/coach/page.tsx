"use client";

import { useCallback, useEffect, useState } from "react";
import {
  Activity,
  BadgeCheck,
  BrainCircuit,
  CheckCircle2,
  Cloud,
  Cpu,
  Info,
  Lightbulb,
  ListChecks,
  Loader2,
  Ruler,
  Salad,
  Sparkles,
  Star,
  Trash2,
  TriangleAlert,
} from "lucide-react";
import { api, post } from "@/lib/client";
import type { AnalysisDTO, ProfileData } from "@/lib/types";
import {
  Bar,
  Btn,
  Card,
  EmptyState,
  Ring,
  SectionHeading,
  Skeleton,
  Stat,
  ToneDot,
} from "@/components/ui";
import { formatDate, fmt } from "@/lib/utils";

const KINDS: Array<{
  kind: "training" | "nutrition" | "body" | "full";
  title: string;
  hint: string;
  icon: React.ReactNode;
  accent: string;
}> = [
  {
    kind: "full",
    title: "Комплексный разбор",
    hint: "Тренировки + питание + тело в одной картине с планом на 2 недели",
    icon: <Sparkles className="size-5" />,
    accent: "from-[#a78bfa] to-[#46e0ff]",
  },
  {
    kind: "training",
    title: "Тренировки",
    hint: "Объём, частота, баланс групп, прогрессия e1RM, застой и перетренированность",
    icon: <Activity className="size-5" />,
    accent: "from-[#a78bfa] to-[#ff8fb1]",
  },
  {
    kind: "nutrition",
    title: "Питание и КБЖУ",
    hint: "Баланс калорий против TDEE, белок на кг, жиры, дисциплина дневника",
    icon: <Salad className="size-5" />,
    accent: "from-[#ffce6b] to-[#a6f97c]",
  },
  {
    kind: "body",
    title: "Обхваты тела",
    hint: "Динамика груди, плеч, талии, ягодиц, бедра, бицепса и предплечья",
    icon: <Ruler className="size-5" />,
    accent: "from-[#46e0ff] to-[#a6f97c]",
  },
];

const PRIORITY_STYLE: Record<string, string> = {
  high: "border-rose-glow/35 bg-rose-glow/12 text-rose-glow",
  medium: "border-amber-glow/35 bg-amber-glow/12 text-amber-glow",
  low: "border-white/12 bg-white/6 text-mist",
};

const PRIORITY_LABEL: Record<string, string> = { high: "срочно", medium: "важно", low: "по желанию" };

export default function CoachPage() {
  const [analyses, setAnalyses] = useState<AnalysisDTO[]>([]);
  const [active, setActive] = useState<AnalysisDTO | null>(null);
  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [loading, setLoading] = useState(true);
  const [running, setRunning] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [list, p] = await Promise.all([
        api<{ analyses: AnalysisDTO[] }>("/api/ai/analyses"),
        api<ProfileData>("/api/profile"),
      ]);
      setAnalyses(list.analyses);
      setProfile(p);
      setActive((prev) => prev ?? list.analyses[0] ?? null);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  async function openDetail(id: number) {
    const res = await api<{ analysis: AnalysisDTO }>(`/api/ai/analyses/${id}`);
    setActive(res.analysis);
  }

  async function run(kind: string) {
    setRunning(kind);
    setError(null);
    try {
      const res = await post<{ analysis: AnalysisDTO; recent: AnalysisDTO[] }>("/api/ai/analyze", { kind });
      setActive(res.analysis);
      const list = await api<{ analyses: AnalysisDTO[] }>("/api/ai/analyses");
      setAnalyses(list.analyses);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Не удалось выполнить анализ");
    } finally {
      setRunning(null);
    }
  }

  async function remove(id: number) {
    await api(`/api/ai/analyses/${id}`, { method: "DELETE" });
    setActive((prev) => (prev?.id === id ? null : prev));
    const list = await api<{ analyses: AnalysisDTO[] }>("/api/ai/analyses");
    setAnalyses(list.analyses);
  }

  const scores = analyses.map((a) => a.score ?? 0);
  const avgScore = scores.length ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length) : null;

  return (
    <div className="space-y-5">
      <Card className="overflow-hidden p-5 sm:p-7">
        <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
          <div className="min-w-0">
            <SectionHeading
              title="ИИ-тренер"
              subtitle="Разбор ваших данных большой моделью — результат сохраняется в приложении"
              icon={<BrainCircuit className="size-5" />}
            />
            <p className="mt-4 max-w-2xl text-[13.5px] leading-relaxed text-mist">
              На анализ уходят ваши тренировки, прогрессия рабочих весов, дневник КБЖУ и обхваты тела.
              {profile?.ai?.online ? (
                <>
                  {" "}
                  Сейчас подключена внешняя модель{" "}
                  <span className="font-semibold text-white/90">
                    {profile.ai.provider} · {profile.ai.model}
                  </span>{" "}
                  — запрос идёт через сервер приложения, ключ не покидает окружение.
                </>
              ) : (
                <>
                  {" "}
                  Внешний API-ключ не задан, поэтому работает встроенный экспертный движок: он считает
                  баланс калорий, прогрессию e1RM, дисбаланс групп и динамику обхватов. Добавьте
                  переменную <code className="rounded bg-white/8 px-1.5 py-0.5 text-[12px] text-white/90">OPENAI_API_KEY</code>{" "}
                  (или OPENROUTER / GROQ / ANTHROPIC), чтобы получить разбор от LLM.
                </>
              )}
            </p>
            <div className="mt-4 flex flex-wrap items-center gap-2">
              <span className="flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.05] px-3 py-1.5 text-[11.5px] text-mist">
                {profile?.ai?.online ? <Cloud className="size-3.5 text-cyan-glow" /> : <Cpu className="size-3.5 text-violet-glow" />}
                {profile?.ai?.online ? "Онлайн-модель" : "Локальный эксперт"} · {profile?.ai?.provider ?? "…"}
              </span>
              <span className="flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.05] px-3 py-1.5 text-[11.5px] text-mist">
                <BadgeCheck className="size-3.5 text-lime-glow" />
                Сохранено разборов: {analyses.length}
              </span>
            </div>
          </div>

          <div className="shrink-0">
            <div className="glass-soft rounded-[28px] p-5">
              <Ring value={avgScore ?? 0} max={100} size={132} stroke={12} from="#a6f97c" to="#46e0ff">
                <div>
                  <p className="text-[26px] font-semibold leading-none text-white">{avgScore ?? "—"}</p>
                  <p className="mt-1 text-[10px] uppercase tracking-[0.08em] text-mist/80">
                    средний индекс
                  </p>
                </div>
              </Ring>
              <p className="mt-3 max-w-[190px] text-center text-[11.5px] leading-relaxed text-mist">
                Индекс учитывает регулярность, прогрессию, питание и динамику тела
              </p>
            </div>
          </div>
        </div>
      </Card>

      <div className="grid gap-3.5 sm:grid-cols-2 xl:grid-cols-4">
        {KINDS.map((k) => (
          <Card key={k.kind} className="flex flex-col p-5" hover>
            <span
              className={`grid size-11 place-items-center rounded-2xl bg-gradient-to-br ${k.accent} text-[#0b0716] shadow-[0_12px_28px_-14px_rgba(124,92,255,0.9)]`}
            >
              {k.icon}
            </span>
            <p className="mt-3.5 text-[15px] font-semibold text-white">{k.title}</p>
            <p className="mt-1.5 flex-1 text-[12.5px] leading-relaxed text-mist">{k.hint}</p>
            <Btn
              className="mt-4 w-full"
              variant={k.kind === "full" ? "primary" : "ghost"}
              disabled={running !== null}
              onClick={() => void run(k.kind)}
            >
              {running === k.kind ? (
                <>
                  <Loader2 className="size-4 spin" /> Анализируем…
                </>
              ) : (
                <>
                  <Sparkles className="size-4" /> Запустить
                </>
              )}
            </Btn>
          </Card>
        ))}
      </div>

      {error ? (
        <Card className="flex items-center gap-3 border-rose-glow/30 p-4">
          <TriangleAlert className="size-4 shrink-0 text-rose-glow" />
          <p className="text-[12.5px] text-rose-glow">{error}</p>
        </Card>
      ) : null}

      {running ? (
        <Card className="p-5">
          <div className="flex items-center gap-3">
            <Loader2 className="size-4 spin text-violet-glow" />
            <p className="text-[13px] text-white/90">
              Собираем метрики и формируем разбор — это занимает несколько секунд.
            </p>
          </div>
          <div className="mt-4 grid gap-3 sm:grid-cols-3">
            {[0, 1, 2].map((i) => (
              <Skeleton key={i} className="h-20 w-full" />
            ))}
          </div>
        </Card>
      ) : null}

      <div className="grid gap-4 xl:grid-cols-[340px_1fr]">
        {/* Archive */}
        <Card className="p-5">
          <SectionHeading title="Архив разборов" subtitle="Все анализы хранятся в базе" icon={<ListChecks className="size-5" />} />
          <div className="thin-scroll mt-4 max-h-[520px] space-y-2 overflow-y-auto pr-1">
            {loading ? (
              [0, 1, 2].map((i) => <Skeleton key={i} className="h-20 w-full" />)
            ) : analyses.length ? (
              analyses.map((a) => (
                <button
                  key={a.id}
                  type="button"
                  onClick={() => void openDetail(a.id)}
                  className={
                    "w-full rounded-2xl border px-3.5 py-3 text-left transition-all " +
                    (active?.id === a.id
                      ? "border-violet-glow/40 bg-violet-glow/12"
                      : "border-white/8 bg-white/[0.03] hover:border-white/18")
                  }
                >
                  <div className="flex items-center gap-2">
                    <span className="text-[12.5px] font-semibold text-white">
                      {KINDS.find((k) => k.kind === a.kind)?.title ?? a.title}
                    </span>
                    <span className="ml-auto rounded-full bg-white/8 px-2 py-0.5 text-[11px] font-semibold text-white">
                      {a.score ?? "—"}
                    </span>
                  </div>
                  <p className="mt-1 line-clamp-2 text-[11.5px] leading-relaxed text-mist">{a.summary}</p>
                  <p className="mt-1.5 flex items-center gap-1.5 text-[10.5px] text-mist/70">
                    {a.online ? <Cloud className="size-3" /> : <Cpu className="size-3" />}
                    {formatDate(a.createdAt.slice(0, 10), "d MMM")} · {a.provider}
                  </p>
                </button>
              ))
            ) : (
              <EmptyState
                icon={<Sparkles className="size-7" />}
                title="Разборов ещё нет"
                hint="Нажмите «Запустить» на любой карточке выше."
              />
            )}
          </div>
        </Card>

        {/* Detail */}
        {active ? (
          <Card className="p-5 sm:p-6">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div className="min-w-0">
                <p className="text-[11px] uppercase tracking-[0.08em] text-mist/80">
                  {KINDS.find((k) => k.kind === active.kind)?.title ?? active.title}
                </p>
                <h2 className="mt-1.5 text-[22px] font-semibold leading-tight tracking-tight text-white">
                  {active.periodLabel || formatDate(active.createdAt.slice(0, 10), "d MMMM yyyy")}
                </h2>
                <p className="mt-1.5 flex flex-wrap items-center gap-2 text-[11.5px] text-mist">
                  <span className="flex items-center gap-1.5">
                    {active.online ? <Cloud className="size-3.5 text-cyan-glow" /> : <Cpu className="size-3.5 text-violet-glow" />}
                    {active.provider} · {active.model}
                  </span>
                  <span>·</span>
                  <span>{formatDate(active.createdAt.slice(0, 10), "d MMMM yyyy")}</span>
                  {active.durationMs ? <span>· {fmt(Math.round(active.durationMs / 100) / 10)} с</span> : null}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <div className="shrink-0">
                  <Ring
                    value={active.score ?? 0}
                    max={100}
                    size={84}
                    stroke={9}
                    from="#a6f97c"
                    to="#46e0ff"
                  >
                    <span className="text-[18px] font-semibold text-white">{active.score ?? "—"}</span>
                  </Ring>
                </div>
                <Btn size="icon" variant="subtle" title="Удалить разбор" onClick={() => void remove(active.id)}>
                  <Trash2 className="size-4 text-rose-glow/80" />
                </Btn>
              </div>
            </div>

            {active.error ? (
              <div className="mt-4 flex items-start gap-2.5 rounded-2xl border border-amber-glow/25 bg-amber-glow/8 px-4 py-3">
                <Info className="mt-0.5 size-4 shrink-0 text-amber-glow" />
                <p className="text-[12px] leading-relaxed text-amber-glow/90">{active.error}</p>
              </div>
            ) : null}

            <p className="mt-4 text-[14px] leading-relaxed text-white/90">{active.summary}</p>

            <div className="mt-5 grid gap-4 lg:grid-cols-2">
              <section>
                <h3 className="flex items-center gap-2 text-[12px] font-semibold uppercase tracking-[0.07em] text-mist/80">
                  <Star className="size-3.5 text-amber-glow" /> Ключевые наблюдения
                </h3>
                <div className="mt-3 space-y-2">
                  {(active.highlights ?? []).map((h, i) => (
                    <div key={i} className="glass-inset rounded-2xl px-4 py-3">
                      <p className="flex items-center gap-2 text-[13px] font-semibold text-white">
                        <ToneDot tone={h.tone} /> {h.title}
                      </p>
                      {h.detail ? <p className="mt-1.5 text-[12.5px] leading-relaxed text-mist">{h.detail}</p> : null}
                    </div>
                  ))}
                  {!active.highlights?.length ? <p className="text-[12.5px] text-mist">—</p> : null}
                </div>
              </section>

              <section>
                <h3 className="flex items-center gap-2 text-[12px] font-semibold uppercase tracking-[0.07em] text-mist/80">
                  <Lightbulb className="size-3.5 text-cyan-glow" /> Инсайты
                </h3>
                <div className="mt-3 space-y-2">
                  {(active.insights ?? []).map((h, i) => (
                    <div key={i} className="glass-inset rounded-2xl px-4 py-3">
                      <p className="text-[13px] font-semibold text-white">{h.title}</p>
                      <p className="mt-1.5 text-[12.5px] leading-relaxed text-mist">{h.detail}</p>
                    </div>
                  ))}
                  {!active.insights?.length ? <p className="text-[12.5px] text-mist">—</p> : null}
                </div>
              </section>
            </div>

            <section className="mt-5">
              <h3 className="flex items-center gap-2 text-[12px] font-semibold uppercase tracking-[0.07em] text-mist/80">
                <CheckCircle2 className="size-3.5 text-lime-glow" /> Рекомендации
              </h3>
              <div className="mt-3 space-y-2.5">
                {(active.recommendations ?? []).map((r, i) => (
                  <div key={i} className="glass-soft rounded-2xl px-4 py-3.5">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="text-[13.5px] font-semibold text-white">{r.title}</p>
                      <span
                        className={`ml-auto rounded-full border px-2.5 py-0.5 text-[10.5px] font-semibold uppercase tracking-[0.05em] ${
                          PRIORITY_STYLE[r.priority ?? "medium"]
                        }`}
                      >
                        {PRIORITY_LABEL[r.priority ?? "medium"]}
                      </span>
                    </div>
                    {r.detail ? <p className="mt-1.5 text-[12.5px] leading-relaxed text-mist">{r.detail}</p> : null}
                  </div>
                ))}
                {!active.recommendations?.length ? <p className="text-[12.5px] text-mist">—</p> : null}
              </div>
            </section>

            {active.plan?.length ? (
              <section className="mt-5">
                <h3 className="flex items-center gap-2 text-[12px] font-semibold uppercase tracking-[0.07em] text-mist/80">
                  <ListChecks className="size-3.5 text-violet-glow" /> План действий
                </h3>
                <ol className="mt-3 space-y-2">
                  {active.plan.map((step, i) => (
                    <li key={i} className="glass-inset flex items-start gap-3 rounded-2xl px-4 py-3">
                      <span className="grid size-6 shrink-0 place-items-center rounded-full bg-violet-glow/18 text-[11.5px] font-semibold text-[#cbb8ff]">
                        {i + 1}
                      </span>
                      <span className="text-[12.5px] leading-relaxed text-white/85">{step}</span>
                    </li>
                  ))}
                </ol>
              </section>
            ) : null}

            {active.metrics ? (
              <section className="mt-5">
                <h3 className="text-[12px] font-semibold uppercase tracking-[0.07em] text-mist/80">
                  Метрики, на которых основан разбор
                </h3>
                <div className="mt-3 grid gap-2.5 sm:grid-cols-3">
                  {[
                    { l: "Тренировок", v: active.metrics.workouts, max: 60 },
                    { l: "Недельный объём", v: active.metrics.weeklyVolume, max: 40000 },
                    { l: "Ккал / день", v: active.metrics.avgCalories, max: 4000 },
                  ].map((m) => (
                    <div key={m.l} className="glass-inset rounded-2xl px-4 py-3">
                      <p className="text-[11px] uppercase tracking-[0.06em] text-mist/75">{m.l}</p>
                      <p className="mt-1 text-[17px] font-semibold text-white">{fmt(Number(m.v ?? 0))}</p>
                      <Bar className="mt-2" value={Number(m.v ?? 0)} max={m.max} />
                    </div>
                  ))}
                </div>
                <div className="mt-3 grid gap-2.5 sm:grid-cols-3">
                  <Stat label="Белок" value={fmt(Number(active.metrics.proteinPerKg ?? 0), 2)} unit="г/кг" />
                  <Stat label="Замеров тела" value={fmt(Number(active.metrics.measurements ?? 0))} unit="шт" />
                  <Stat
                    label="Плечи / талия"
                    value={active.metrics.shoulderWaistRatio ? fmt(Number(active.metrics.shoulderWaistRatio), 2) : "—"}
                  />
                </div>
              </section>
            ) : null}
          </Card>
        ) : (
          <Card className="grid place-items-center p-10">
            <EmptyState
              icon={<BrainCircuit className="size-8" />}
              title="Выберите разбор"
              hint="Запустите анализ или откройте любой сохранённый разбор в архиве слева."
            />
          </Card>
        )}
      </div>
    </div>
  );
}
