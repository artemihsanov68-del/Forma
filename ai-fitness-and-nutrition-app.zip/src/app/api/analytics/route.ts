import { NextResponse } from "next/server";
import { ensureSeeded } from "@/db/seed";
import { detectProvider } from "@/lib/coach";
import {
  buildBodySummary,
  buildNutritionSummary,
  buildTrainingSummary,
  getProfileWithTargets,
} from "@/lib/stats";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  await ensureSeeded();
  const days = Number(new URL(req.url).searchParams.get("days") ?? 90);
  const [training, nutrition, body, profile] = await Promise.all([
    buildTrainingSummary(days),
    buildNutritionSummary(30),
    buildBodySummary(),
    getProfileWithTargets(),
  ]);
  const provider = detectProvider();
  return NextResponse.json({
    training,
    nutrition,
    body,
    profile: {
      ...profile,
      ai: {
        online: Boolean(provider),
        provider: provider?.name ?? "Локальный эксперт",
        model: provider?.model ?? "expert-engine-v1",
      },
    },
  });
}
