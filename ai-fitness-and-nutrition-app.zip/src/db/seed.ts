import { format, subDays } from "date-fns";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import {
  exerciseSets,
  exercises,
  foodCatalog,
  measurements,
  nutritionEntries,
  profiles,
  workoutExercises,
  workouts,
} from "@/db/schema";

export const EXERCISE_CATALOG: Array<{
  name: string;
  muscleGroup: string;
  equipment: string;
  kind?: string;
}> = [
  { name: "Жим штанги лёжа", muscleGroup: "chest", equipment: "barbell" },
  { name: "Жим гантелей на наклонной скамье", muscleGroup: "chest", equipment: "dumbbell" },
  { name: "Отжимания на брусьях", muscleGroup: "chest", equipment: "bodyweight", kind: "bodyweight" },
  { name: "Сведение рук в кроссовере", muscleGroup: "chest", equipment: "cable" },
  { name: "Разводка гантелей лёжа", muscleGroup: "chest", equipment: "dumbbell" },
  { name: "Становая тяга", muscleGroup: "back", equipment: "barbell" },
  { name: "Подтягивания", muscleGroup: "back", equipment: "bodyweight", kind: "bodyweight" },
  { name: "Тяга штанги в наклоне", muscleGroup: "back", equipment: "barbell" },
  { name: "Тяга верхнего блока", muscleGroup: "back", equipment: "cable" },
  { name: "Тяга гантели одной рукой", muscleGroup: "back", equipment: "dumbbell" },
  { name: "Гиперэкстензия", muscleGroup: "back", equipment: "bodyweight", kind: "bodyweight" },
  { name: "Приседания со штангой", muscleGroup: "legs", equipment: "barbell" },
  { name: "Жим ногами", muscleGroup: "legs", equipment: "machine" },
  { name: "Румынская тяга", muscleGroup: "legs", equipment: "barbell" },
  { name: "Выпады с гантелями", muscleGroup: "legs", equipment: "dumbbell" },
  { name: "Разгибания ног в тренажёре", muscleGroup: "legs", equipment: "machine" },
  { name: "Сгибания ног лёжа", muscleGroup: "legs", equipment: "machine" },
  { name: "Подъём на носки стоя", muscleGroup: "legs", equipment: "machine" },
  { name: "Ягодичный мост со штангой", muscleGroup: "legs", equipment: "barbell" },
  { name: "Жим штанги стоя", muscleGroup: "shoulders", equipment: "barbell" },
  { name: "Жим гантелей сидя", muscleGroup: "shoulders", equipment: "dumbbell" },
  { name: "Махи гантелями в стороны", muscleGroup: "shoulders", equipment: "dumbbell" },
  { name: "Махи в наклоне", muscleGroup: "shoulders", equipment: "dumbbell" },
  { name: "Тяга к подбородку", muscleGroup: "shoulders", equipment: "barbell" },
  { name: "Подъём штанги на бицепс", muscleGroup: "arms", equipment: "barbell" },
  { name: "Молотки с гантелями", muscleGroup: "arms", equipment: "dumbbell" },
  { name: "Французский жим", muscleGroup: "arms", equipment: "barbell" },
  { name: "Разгибания на трицепс в блоке", muscleGroup: "arms", equipment: "cable" },
  { name: "Сгибания рук на скамье Скотта", muscleGroup: "arms", equipment: "machine" },
  { name: "Сгибания запястий со штангой", muscleGroup: "arms", equipment: "barbell" },
  { name: "Планка", muscleGroup: "core", equipment: "bodyweight", kind: "bodyweight" },
  { name: "Скручивания", muscleGroup: "core", equipment: "bodyweight", kind: "bodyweight" },
  { name: "Подъём ног в висе", muscleGroup: "core", equipment: "bodyweight", kind: "bodyweight" },
  { name: "Ролик для пресса", muscleGroup: "core", equipment: "other" },
  { name: "Бег на дорожке", muscleGroup: "cardio", equipment: "machine", kind: "cardio" },
  { name: "Велотренажёр", muscleGroup: "cardio", equipment: "machine", kind: "cardio" },
  { name: "Гребной тренажёр", muscleGroup: "cardio", equipment: "machine", kind: "cardio" },
  { name: "Эллипс", muscleGroup: "cardio", equipment: "machine", kind: "cardio" },
];

export const FOOD_CATALOG: Array<{
  name: string;
  category: string;
  kcal: number;
  protein: number;
  fat: number;
  carbs: number;
  perGrams?: number;
}> = [
  { name: "Куриная грудка отварная", category: "Белки", kcal: 137, protein: 29.8, fat: 1.8, carbs: 0.5 },
  { name: "Куриное бедро без кожи", category: "Белки", kcal: 185, protein: 24, fat: 10, carbs: 0 },
  { name: "Говядина постная", category: "Белки", kcal: 187, protein: 26, fat: 9, carbs: 0 },
  { name: "Лосось", category: "Белки", kcal: 208, protein: 20, fat: 13, carbs: 0 },
  { name: "Треска", category: "Белки", kcal: 82, protein: 18, fat: 0.7, carbs: 0 },
  { name: "Тунец консервированный", category: "Белки", kcal: 96, protein: 21, fat: 1, carbs: 0 },
  { name: "Яйцо куриное", category: "Белки", kcal: 143, protein: 12.7, fat: 9.9, carbs: 0.7 },
  { name: "Яичный белок", category: "Белки", kcal: 48, protein: 11, fat: 0, carbs: 0.4 },
  { name: "Творог 5%", category: "Белки", kcal: 121, protein: 17, fat: 5, carbs: 1.8 },
  { name: "Греческий йогурт 2%", category: "Белки", kcal: 60, protein: 9, fat: 2, carbs: 3.6 },
  { name: "Протеин сывороточный (мерная ложка)", category: "Спортпит", kcal: 120, protein: 24, fat: 1.5, carbs: 3, perGrams: 30 },
  { name: "Креатин моногидрат", category: "Спортпит", kcal: 0, protein: 0, fat: 0, carbs: 0, perGrams: 5 },
  { name: "Рис белый отварной", category: "Углеводы", kcal: 116, protein: 2.2, fat: 0.5, carbs: 24.9 },
  { name: "Гречка отварная", category: "Углеводы", kcal: 104, protein: 3.8, fat: 1.1, carbs: 20 },
  { name: "Овсянка на воде", category: "Углеводы", kcal: 88, protein: 3, fat: 1.7, carbs: 15 },
  { name: "Макароны твёрдых сортов", category: "Углеводы", kcal: 131, protein: 5, fat: 1.1, carbs: 27 },
  { name: "Картофель отварной", category: "Углеводы", kcal: 82, protein: 2, fat: 0.4, carbs: 16.7 },
  { name: "Хлеб цельнозерновой", category: "Углеводы", kcal: 247, protein: 13, fat: 3.4, carbs: 41 },
  { name: "Банан", category: "Фрукты", kcal: 89, protein: 1.1, fat: 0.3, carbs: 22.8 },
  { name: "Яблоко", category: "Фрукты", kcal: 52, protein: 0.3, fat: 0.2, carbs: 13.8 },
  { name: "Авокадо", category: "Жиры", kcal: 160, protein: 2, fat: 14.7, carbs: 8.5 },
  { name: "Оливковое масло", category: "Жиры", kcal: 884, protein: 0, fat: 100, carbs: 0 },
  { name: "Арахисовая паста", category: "Жиры", kcal: 588, protein: 25, fat: 50, carbs: 20 },
  { name: "Миндаль", category: "Жиры", kcal: 579, protein: 21, fat: 50, carbs: 22 },
  { name: "Грецкие орехи", category: "Жиры", kcal: 654, protein: 15, fat: 65, carbs: 14 },
  { name: "Сыр твёрдый 45%", category: "Белки", kcal: 364, protein: 25, fat: 29, carbs: 0.5 },
  { name: "Молоко 2.5%", category: "Белки", kcal: 52, protein: 2.9, fat: 2.5, carbs: 4.7 },
  { name: "Кефир 1%", category: "Белки", kcal: 40, protein: 3, fat: 1, carbs: 4 },
  { name: "Брокколи", category: "Овощи", kcal: 34, protein: 2.8, fat: 0.4, carbs: 6.6 },
  { name: "Огурец", category: "Овощи", kcal: 15, protein: 0.7, fat: 0.1, carbs: 3.1 },
  { name: "Помидор", category: "Овощи", kcal: 18, protein: 0.9, fat: 0.2, carbs: 3.9 },
  { name: "Шпинат", category: "Овощи", kcal: 23, protein: 2.9, fat: 0.4, carbs: 3.6 },
  { name: "Салат из овощей с маслом", category: "Овощи", kcal: 90, protein: 1.5, fat: 7, carbs: 5 },
  { name: "Кофе американо", category: "Напитки", kcal: 2, protein: 0.1, fat: 0, carbs: 0.3, perGrams: 200 },
  { name: "Кофе латте", category: "Напитки", kcal: 55, protein: 3, fat: 2.5, carbs: 5, perGrams: 250 },
  { name: "Апельсиновый сок", category: "Напитки", kcal: 45, protein: 0.7, fat: 0.2, carbs: 10.4 },
  { name: "Тёмный шоколад 75%", category: "Сладкое", kcal: 546, protein: 7.8, fat: 42, carbs: 33 },
  { name: "Мёд", category: "Сладкое", kcal: 329, protein: 0.8, fat: 0, carbs: 81 },
  { name: "Пицца Маргарита (кусок)", category: "Готовые блюда", kcal: 266, protein: 11, fat: 10, carbs: 33, perGrams: 107 },
  { name: "Бургер с говядиной", category: "Готовые блюда", kcal: 295, protein: 15, fat: 14, carbs: 26 },
  { name: "Суп куриный с лапшой", category: "Готовые блюда", kcal: 68, protein: 4.5, fat: 2.5, carbs: 7 },
  { name: "Плов с курицей", category: "Готовые блюда", kcal: 175, protein: 9, fat: 6, carbs: 21 },
];

const PROGRAM: Record<string, Array<[string, number, number, number]>> = {
  push: [
    ["Жим штанги лёжа", 4, 6, 80],
    ["Жим гантелей на наклонной скамье", 3, 10, 30],
    ["Жим штанги стоя", 4, 8, 40],
    ["Махи гантелями в стороны", 3, 15, 12],
    ["Разгибания на трицепс в блоке", 3, 12, 30],
  ],
  pull: [
    ["Становая тяга", 4, 5, 110],
    ["Подтягивания", 4, 8, 0],
    ["Тяга штанги в наклоне", 4, 8, 60],
    ["Тяга верхнего блока", 3, 12, 55],
    ["Подъём штанги на бицепс", 3, 12, 30],
    ["Молотки с гантелями", 3, 12, 14],
  ],
  legs: [
    ["Приседания со штангой", 5, 5, 100],
    ["Румынская тяга", 4, 8, 70],
    ["Жим ногами", 3, 12, 160],
    ["Сгибания ног лёжа", 3, 12, 40],
    ["Подъём на носки стоя", 4, 15, 60],
    ["Планка", 3, 0, 0],
  ],
};

const DAY_NAMES = ["Воскресенье", "Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота"];

function round1(n: number) {
  return Math.round(n * 10) / 10;
}

/** Deterministic-ish PRNG so demo data looks organic but is stable per run. */
function rng(seed: number) {
  let s = seed;
  return () => {
    s = (s * 1664525 + 1013904223) % 4294967296;
    return s / 4294967296;
  };
}

let seedPromise: Promise<void> | null = null;

/** Runs the catalog/demo seeding exactly once per server process. */
export function ensureSeeded() {
  if (!seedPromise) {
    seedPromise = runSeed().catch((err) => {
      seedPromise = null;
      throw err;
    });
  }
  return seedPromise;
}

async function runSeed() {
  const existing = await db.select({ id: profiles.id }).from(profiles).limit(1);
  const firstBoot = existing.length === 0;

  if (existing.length === 0) {
    await db.insert(profiles).values({
      id: 1,
      name: "Атлет",
      sex: "male",
      heightCm: 180,
      weightKg: 84.2,
      activityLevel: "moderate",
      goal: "recomp",
      targetCalories: 2750,
      targetProtein: 170,
      targetFat: 85,
      targetCarbs: 320,
      workoutsPerWeek: 4,
    });
  }

  const exCount = await db.select({ id: exercises.id }).from(exercises).limit(1);
  if (exCount.length === 0) {
    await db.insert(exercises).values(EXERCISE_CATALOG.map((e) => ({ ...e, kind: e.kind ?? "strength" })));
  }

  const foodCount = await db.select({ id: foodCatalog.id }).from(foodCatalog).limit(1);
  if (foodCount.length === 0) {
    await db.insert(foodCatalog).values(FOOD_CATALOG.map((f) => ({ ...f, perGrams: f.perGrams ?? 100 })));
  }

  if (!firstBoot) return;

  await seedDemoHistory();
}

async function seedDemoHistory() {
  const rand = rng(20260214);
  const exRows = await db.select().from(exercises);
  const byName = new Map(exRows.map((e) => [e.name, e]));
  const foodRows = await db.select().from(foodCatalog);
  const today = new Date();

  // ---- Workouts: 12 weeks of Push / Pull / Legs progression ----
  const splits = Object.keys(PROGRAM) as Array<keyof typeof PROGRAM>;
  let weekIndex = 0;
  for (let w = 11; w >= 0; w--) {
    const perWeek = 3;
    for (let d = 0; d < perWeek; d++) {
      const dayOffset = w * 7 + (6 - d * 2);
      if (dayOffset < 0) continue;
      const date = subDays(today, dayOffset);
      const split = splits[(weekIndex + d) % splits.length];
      const plan = PROGRAM[split];
      const progressFactor = 1 + (11 - w) * 0.018; // gradual overload across weeks
      const volumeFactor = 0.9 + (11 - w) * 0.012;
      const [created] = await db
        .insert(workouts)
        .values({
          date: format(date, "yyyy-MM-dd"),
          title:
            split === "push"
              ? "Жим / Плечи / Трицепс"
              : split === "pull"
                ? "Спина / Бицепс"
                : "Ноги / Кор",
          focus: split,
          durationMinutes: Math.round(58 + rand() * 26),
          feeling: 3 + Math.round(rand() * 2),
          notes:
            w < 3 && split === "legs"
              ? "Чувствовал себя мощно, добавил рабочие веса."
              : undefined,
        })
        .returning({ id: workouts.id });

      let volume = 0;
      let sets = 0;
      for (let i = 0; i < plan.length; i++) {
        const [name, setCount, reps, baseWeight] = plan[i];
        const ex = byName.get(name);
        const [weRow] = await db
          .insert(workoutExercises)
          .values({
            workoutId: created.id,
            exerciseId: ex?.id ?? null,
            exerciseName: name,
            muscleGroup: ex?.muscleGroup ?? "other",
            sortOrder: i,
          })
          .returning({ id: workoutExercises.id });

        const isPlank = name === "Планка";
        const setRows: Array<{
          setNumber: number;
          weightKg: number;
          reps: number;
          rpe: number;
          durationSeconds: number | null;
          isWarmup: boolean;
        }> = [];

        for (let s = 0; s < setCount; s++) {
          const jitter = 1 + (rand() - 0.5) * 0.05;
          if (isPlank) {
            setRows.push({
              setNumber: s + 1,
              weightKg: 0,
              reps: 0,
              rpe: round1(6.5 + rand() * 2),
              durationSeconds: Math.round((40 + (11 - w) * 3 + s * 5) * jitter),
              isWarmup: false,
            });
            continue;
          }
          const weight =
            baseWeight === 0
              ? Math.round((bodyweightProgress(11 - w) + rand() * 2) * 2) / 2
              : round1(baseWeight * progressFactor * jitter * (s === 0 ? 0.94 : 1));
          const repCount = Math.max(
            3,
            Math.round(reps * (s === 0 ? 1 : volumeFactor) + (rand() - 0.5) * 1.6),
          );
          setRows.push({
            setNumber: s + 1,
            weightKg: weight,
            reps: repCount,
            rpe: round1(6.5 + rand() * 2.6),
            durationSeconds: null,
            isWarmup: false,
          });
          volume += weight * repCount;
          sets += 1;
        }
        await db.insert(exerciseSets).values(setRows.map((r) => ({ ...r, workoutExerciseId: weRow.id })));
      }

      await db
        .update(workouts)
        .set({ totalVolume: Math.round(volume), totalSets: sets })
        .where(eq(workouts.id, created.id));
    }
    weekIndex++;
  }

  // ---- Measurements: every 14 days, slow recomposition ----
  const base = {
    weightKg: 87.4,
    chest: 104,
    shoulders: 122,
    waist: 88,
    hips: 100,
    glutes: 102,
    thigh: 60,
    biceps: 36.5,
    forearm: 29,
    neck: 39,
    calf: 38,
  };
  for (let i = 0; i < 9; i++) {
    const date = subDays(today, i * 14);
    const t = (8 - i) / 8; // 1 = oldest, 0 = newest
    await db.insert(measurements).values({
      date: format(date, "yyyy-MM-dd"),
      // t = 1 for the newest measurement, 0 for the oldest
      weightKg: round1(base.weightKg - t * 3.1 + (rand() - 0.5) * 0.5),
      bodyFat: round1(19.4 - t * 2.6 + (rand() - 0.5) * 0.4),
      chest: round1(base.chest + t * 2.4 + (rand() - 0.5) * 0.4),
      shoulders: round1(base.shoulders + t * 3.1),
      waist: round1(base.waist - t * 4.2 + (rand() - 0.5) * 0.6),
      hips: round1(base.hips - t * 1.6),
      glutes: round1(base.glutes + t * 1.2),
      thigh: round1(base.thigh + t * 1.4),
      biceps: round1(base.biceps + t * 1.7),
      forearm: round1(base.forearm + t * 0.9),
      neck: round1(base.neck + t * 0.4),
      calf: round1(base.calf + t * 0.6),
    });
  }

  // ---- Nutrition: last 24 days (realistic ~2600-3000 kcal menu) ----
  const menu: Array<[string, number, string]> = [
    ["Овсянка на воде", 250, "breakfast"],
    ["Яйцо куриное", 120, "breakfast"],
    ["Банан", 120, "breakfast"],
    ["Кофе латте", 250, "breakfast"],
    ["Протеин сывороточный (мерная ложка)", 30, "snack"],
    ["Арахисовая паста", 25, "snack"],
    ["Куриная грудка отварная", 180, "lunch"],
    ["Рис белый отварной", 220, "lunch"],
    ["Салат из овощей с маслом", 200, "lunch"],
    ["Оливковое масло", 10, "lunch"],
    ["Творог 5%", 200, "snack"],
    ["Мёд", 20, "snack"],
    ["Лосось", 150, "dinner"],
    ["Гречка отварная", 200, "dinner"],
    ["Брокколи", 150, "dinner"],
  ];
  const extras: Array<[string, number, string]> = [
    ["Тёмный шоколад 75%", 25, "snack"],
    ["Миндаль", 35, "snack"],
    ["Греческий йогурт 2%", 180, "snack"],
    ["Плов с курицей", 350, "lunch"],
    ["Хлеб цельнозерновой", 70, "lunch"],
    ["Яблоко", 180, "snack"],
    ["Сыр твёрдый 45%", 40, "snack"],
    ["Бургер с говядиной", 220, "dinner"],
  ];

  for (let d = 23; d >= 0; d--) {
    if (rand() < 0.12) continue; // occasionally untracked day — realistic adherence
    const date = format(subDays(today, d), "yyyy-MM-dd");
    const dayMenu = [...menu];
    const extraCount = 1 + Math.floor(rand() * 2);
    for (let e = 0; e < extraCount; e++) {
      dayMenu.push(extras[Math.floor(rand() * extras.length)]);
    }
    for (const [name, gramsRaw, meal] of dayMenu) {
      const item = foodRows.find((f) => f.name === name);
      if (!item) continue;
      const grams = Math.max(5, Math.round((gramsRaw * (0.85 + rand() * 0.32)) / 5) * 5);
      const k = grams / item.perGrams;
      await db.insert(nutritionEntries).values({
        date,
        meal,
        name: item.name,
        grams,
        kcal: Math.round(item.kcal * k),
        protein: round1(item.protein * k),
        fat: round1(item.fat * k),
        carbs: round1(item.carbs * k),
      });
    }
  }
}

/** Дополнительный вес в подтягиваниях: плавный рост за 12 недель. */
function bodyweightProgress(weeksFromStart: number) {
  return 7.5 + weeksFromStart * 0.35;
}

export const DAY_LABELS = DAY_NAMES;
