import { sql } from "drizzle-orm";
import { db } from "@/db";

/**
 * DDL for every table in the app. Executed statement-by-statement so it also works
 * on a brand-new database where nothing exists yet (fresh Neon project, for example).
 */
export const TABLE_NAMES = [
  "profiles",
  "exercises",
  "workouts",
  "workout_exercises",
  "exercise_sets",
  "food_catalog",
  "nutrition_entries",
  "measurements",
  "ai_analyses",
] as const;

const DDL: string[] = [
  `CREATE TABLE IF NOT EXISTS profiles (
     id SERIAL PRIMARY KEY,
     name TEXT NOT NULL DEFAULT 'Атлет',
     sex TEXT NOT NULL DEFAULT 'male',
     birth_date DATE,
     height_cm DOUBLE PRECISION NOT NULL DEFAULT 178,
     weight_kg DOUBLE PRECISION NOT NULL DEFAULT 80,
     activity_level TEXT NOT NULL DEFAULT 'moderate',
     goal TEXT NOT NULL DEFAULT 'recomp',
     target_calories INTEGER NOT NULL DEFAULT 2600,
     target_protein INTEGER NOT NULL DEFAULT 160,
     target_fat INTEGER NOT NULL DEFAULT 80,
     target_carbs INTEGER NOT NULL DEFAULT 300,
     workouts_per_week INTEGER NOT NULL DEFAULT 4,
     notes TEXT,
     created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
     updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
   )`,
  `CREATE TABLE IF NOT EXISTS exercises (
     id SERIAL PRIMARY KEY,
     name TEXT NOT NULL,
     muscle_group TEXT NOT NULL,
     equipment TEXT NOT NULL DEFAULT 'barbell',
     kind TEXT NOT NULL DEFAULT 'strength',
     is_custom BOOLEAN NOT NULL DEFAULT FALSE
   )`,
  `CREATE UNIQUE INDEX IF NOT EXISTS exercises_name_uniq ON exercises (name)`,
  `CREATE TABLE IF NOT EXISTS workouts (
     id SERIAL PRIMARY KEY,
     date DATE NOT NULL,
     title TEXT NOT NULL DEFAULT 'Тренировка',
     focus TEXT,
     duration_minutes INTEGER,
     notes TEXT,
     feeling INTEGER,
     total_volume DOUBLE PRECISION NOT NULL DEFAULT 0,
     total_sets INTEGER NOT NULL DEFAULT 0,
     created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
   )`,
  `CREATE INDEX IF NOT EXISTS workouts_date_idx ON workouts (date)`,
  `CREATE TABLE IF NOT EXISTS workout_exercises (
     id SERIAL PRIMARY KEY,
     workout_id INTEGER NOT NULL REFERENCES workouts(id) ON DELETE CASCADE,
     exercise_id INTEGER REFERENCES exercises(id) ON DELETE SET NULL,
     exercise_name TEXT NOT NULL,
     muscle_group TEXT NOT NULL DEFAULT 'other',
     sort_order INTEGER NOT NULL DEFAULT 0,
     notes TEXT
   )`,
  `CREATE INDEX IF NOT EXISTS workout_exercises_workout_idx ON workout_exercises (workout_id)`,
  `CREATE TABLE IF NOT EXISTS exercise_sets (
     id SERIAL PRIMARY KEY,
     workout_exercise_id INTEGER NOT NULL REFERENCES workout_exercises(id) ON DELETE CASCADE,
     set_number INTEGER NOT NULL DEFAULT 1,
     weight_kg DOUBLE PRECISION NOT NULL DEFAULT 0,
     reps INTEGER NOT NULL DEFAULT 0,
     rpe DOUBLE PRECISION,
     duration_seconds INTEGER,
     distance_km DOUBLE PRECISION,
     is_warmup BOOLEAN NOT NULL DEFAULT FALSE
   )`,
  `CREATE INDEX IF NOT EXISTS exercise_sets_parent_idx ON exercise_sets (workout_exercise_id)`,
  `CREATE TABLE IF NOT EXISTS food_catalog (
     id SERIAL PRIMARY KEY,
     name TEXT NOT NULL,
     brand TEXT,
     category TEXT NOT NULL DEFAULT 'other',
     kcal DOUBLE PRECISION NOT NULL DEFAULT 0,
     protein DOUBLE PRECISION NOT NULL DEFAULT 0,
     fat DOUBLE PRECISION NOT NULL DEFAULT 0,
     carbs DOUBLE PRECISION NOT NULL DEFAULT 0,
     per_grams DOUBLE PRECISION NOT NULL DEFAULT 100,
     is_custom BOOLEAN NOT NULL DEFAULT FALSE
   )`,
  `CREATE INDEX IF NOT EXISTS food_catalog_name_idx ON food_catalog (name)`,
  `CREATE TABLE IF NOT EXISTS nutrition_entries (
     id SERIAL PRIMARY KEY,
     date DATE NOT NULL,
     meal TEXT NOT NULL DEFAULT 'snack',
     name TEXT NOT NULL,
     grams DOUBLE PRECISION NOT NULL DEFAULT 100,
     kcal DOUBLE PRECISION NOT NULL DEFAULT 0,
     protein DOUBLE PRECISION NOT NULL DEFAULT 0,
     fat DOUBLE PRECISION NOT NULL DEFAULT 0,
     carbs DOUBLE PRECISION NOT NULL DEFAULT 0,
     created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
   )`,
  `CREATE INDEX IF NOT EXISTS nutrition_date_idx ON nutrition_entries (date)`,
  `CREATE TABLE IF NOT EXISTS measurements (
     id SERIAL PRIMARY KEY,
     date DATE NOT NULL,
     weight_kg DOUBLE PRECISION,
     body_fat DOUBLE PRECISION,
     neck DOUBLE PRECISION,
     chest DOUBLE PRECISION,
     shoulders DOUBLE PRECISION,
     waist DOUBLE PRECISION,
     hips DOUBLE PRECISION,
     glutes DOUBLE PRECISION,
     thigh DOUBLE PRECISION,
     biceps DOUBLE PRECISION,
     forearm DOUBLE PRECISION,
     calf DOUBLE PRECISION,
     notes TEXT,
     created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
   )`,
  `CREATE INDEX IF NOT EXISTS measurements_date_idx ON measurements (date)`,
  `CREATE TABLE IF NOT EXISTS ai_analyses (
     id SERIAL PRIMARY KEY,
     kind TEXT NOT NULL,
     title TEXT NOT NULL,
     period_label TEXT NOT NULL DEFAULT '',
     provider TEXT NOT NULL DEFAULT 'local-expert',
     model TEXT NOT NULL DEFAULT 'expert-engine-v1',
     online BOOLEAN NOT NULL DEFAULT FALSE,
     prompt TEXT,
     raw_response TEXT,
     summary TEXT NOT NULL DEFAULT '',
     score INTEGER,
     highlights JSONB,
     insights JSONB,
     recommendations JSONB,
     plan JSONB,
     metrics JSONB,
     data_snapshot JSONB,
     duration_ms INTEGER,
     error TEXT,
     created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
   )`,
  `CREATE INDEX IF NOT EXISTS ai_created_idx ON ai_analyses (created_at)`,
];

export interface DbStatus {
  connected: boolean;
  ready: boolean;
  existing: string[];
  missing: string[];
  error?: string;
}

/** Checks which app tables exist in the configured database. */
export async function checkDatabase(): Promise<DbStatus> {
  try {
    const result = await db.execute<{ table_name: string }>(sql`
      SELECT table_name FROM information_schema.tables
      WHERE table_schema = 'public' AND table_type = 'BASE TABLE'
    `);
    const existing = new Set((result.rows ?? []).map((r) => r.table_name));
    const present = TABLE_NAMES.filter((t) => existing.has(t));
    const missing = TABLE_NAMES.filter((t) => !existing.has(t));
    return { connected: true, ready: missing.length === 0, existing: present, missing };
  } catch (err) {
    return {
      connected: false,
      ready: false,
      existing: [],
      missing: [...TABLE_NAMES],
      error: err instanceof Error ? err.message : String(err),
    };
  }
}

/** Creates all missing tables. Safe to run repeatedly. */
export async function createTables() {
  const executed: string[] = [];
  for (const statement of DDL) {
    await db.execute(sql.raw(statement));
    executed.push(statement.split("(")[0].replace(/[^a-z_]/gi, ""));
  }
  return executed.length;
}
