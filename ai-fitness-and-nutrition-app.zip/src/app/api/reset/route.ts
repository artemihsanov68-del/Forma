import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  aiAnalyses,
  exerciseSets,
  measurements,
  nutritionEntries,
  workoutExercises,
  workouts,
} from "@/db/schema";
import { ensureSeeded } from "@/db/seed";

export const dynamic = "force-dynamic";

/** Clears all user data (trainings, nutrition, measurements, AI analyses) but keeps catalogs and profile. */
export async function POST() {
  await ensureSeeded();
  await db.delete(aiAnalyses);
  await db.delete(exerciseSets);
  await db.delete(workoutExercises);
  await db.delete(workouts);
  await db.delete(nutritionEntries);
  await db.delete(measurements);
  return NextResponse.json({ ok: true });
}
