import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { profiles } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { getProfileWithTargets } from "@/lib/stats";
import { detectProvider } from "@/lib/coach";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSeeded();
  const data = await getProfileWithTargets();
  const provider = detectProvider();
  return NextResponse.json({
    ...data,
    ai: {
      online: Boolean(provider),
      provider: provider?.name ?? "Локальный эксперт",
      model: provider?.model ?? "expert-engine-v1",
    },
  });
}

export async function PATCH(req: Request) {
  await ensureSeeded();
  const body = (await req.json()) as Record<string, unknown>;
  const allowed = [
    "name",
    "sex",
    "birthDate",
    "heightCm",
    "weightKg",
    "activityLevel",
    "goal",
    "targetCalories",
    "targetProtein",
    "targetFat",
    "targetCarbs",
    "workoutsPerWeek",
    "notes",
  ] as const;

  const patch: Record<string, unknown> = {};
  for (const key of allowed) {
    if (body[key] !== undefined) patch[key] = body[key];
  }
  if (Object.keys(patch).length === 0) {
    return NextResponse.json({ ok: true });
  }
  patch.updatedAt = new Date();

  await db.update(profiles).set(patch).where(eq(profiles.id, 1));
  const data = await getProfileWithTargets();
  return NextResponse.json(data);
}
