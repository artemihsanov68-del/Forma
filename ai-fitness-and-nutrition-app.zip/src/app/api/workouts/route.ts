import { NextResponse } from "next/server";
import { desc } from "drizzle-orm";
import { format } from "date-fns";
import { db } from "@/db";
import { exerciseSets, exercises, workoutExercises, workouts } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { getWorkoutsDetailed } from "@/lib/stats";

export const dynamic = "force-dynamic";

export interface IncomingSet {
  weightKg?: number;
  reps?: number;
  rpe?: number | null;
  durationSeconds?: number | null;
  distanceKm?: number | null;
  isWarmup?: boolean;
}

export interface IncomingExercise {
  exerciseId?: number | null;
  exerciseName?: string;
  muscleGroup?: string;
  sets?: IncomingSet[];
}

export function totalsFor(list: IncomingExercise[]) {
  let volume = 0;
  let sets = 0;
  for (const ex of list) {
    for (const s of ex.sets ?? []) {
      if (s.isWarmup) continue;
      volume += (Number(s.weightKg) || 0) * (Number(s.reps) || 0) + (Number(s.durationSeconds) || 0) * 0.1;
      sets += 1;
    }
  }
  return { volume: Math.round(volume), sets };
}

export async function GET(req: Request) {
  await ensureSeeded();
  const url = new URL(req.url);
  const limit = Number(url.searchParams.get("limit") ?? 60);
  const fromDate = url.searchParams.get("from");
  const list = await getWorkoutsDetailed({ limit, fromDate: fromDate ?? undefined });
  const countRow = await db
    .select({ id: workouts.id })
    .from(workouts)
    .orderBy(desc(workouts.date))
    .limit(1000);
  return NextResponse.json({ workouts: list, total: countRow.length });
}

export async function POST(req: Request) {
  await ensureSeeded();
  const body = (await req.json()) as {
    date?: string;
    title?: string;
    focus?: string;
    durationMinutes?: number;
    notes?: string;
    feeling?: number;
    exercises?: IncomingExercise[];
  };

  const date = body.date ?? format(new Date(), "yyyy-MM-dd");
  const incoming = body.exercises ?? [];
  const catalog = await db.select().from(exercises);
  const totals = totalsFor(incoming);

  const [workout] = await db
    .insert(workouts)
    .values({
      date,
      title: body.title?.trim() || "Тренировка",
      focus: body.focus ?? null,
      durationMinutes: body.durationMinutes ?? null,
      notes: body.notes?.trim() || null,
      feeling: body.feeling ?? null,
      totalVolume: totals.volume,
      totalSets: totals.sets,
    })
    .returning();

  for (let i = 0; i < incoming.length; i++) {
    const ex = incoming[i];
    const name = ex.exerciseName?.trim();
    if (!name) continue;
    const match = ex.exerciseId
      ? catalog.find((c) => c.id === ex.exerciseId)
      : catalog.find((c) => c.name.toLowerCase() === name.toLowerCase());
    const [row] = await db
      .insert(workoutExercises)
      .values({
        workoutId: workout.id,
        exerciseId: match?.id ?? null,
        exerciseName: name,
        muscleGroup: ex.muscleGroup ?? match?.muscleGroup ?? "other",
        sortOrder: i,
      })
      .returning();

    const sets = (ex.sets ?? []).map((s, idx) => ({
      workoutExerciseId: row.id,
      setNumber: idx + 1,
      weightKg: Number(s.weightKg) || 0,
      reps: Number(s.reps) || 0,
      rpe: s.rpe == null || Number.isNaN(Number(s.rpe)) ? null : Number(s.rpe),
      durationSeconds: s.durationSeconds ? Number(s.durationSeconds) : null,
      distanceKm: s.distanceKm ? Number(s.distanceKm) : null,
      isWarmup: Boolean(s.isWarmup),
    }));
    if (sets.length) await db.insert(exerciseSets).values(sets);
  }

  return NextResponse.json({ workout: { ...workout, exercises: incoming } });
}
