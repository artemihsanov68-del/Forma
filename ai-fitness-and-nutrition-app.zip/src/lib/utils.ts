import { differenceInDays, format, isSameDay, parseISO, startOfDay } from "date-fns";
import { ru } from "date-fns/locale";

type ClassValue = string | number | null | undefined | false | Record<string, boolean>;

export function cn(...inputs: ClassValue[]) {
  const out: string[] = [];
  for (const input of inputs) {
    if (!input) continue;
    if (typeof input === "string" || typeof input === "number") {
      out.push(String(input));
    } else if (typeof input === "object") {
      for (const [key, value] of Object.entries(input)) {
        if (value) out.push(key);
      }
    }
  }
  return out.join(" ");
}

export const todayISO = () => format(new Date(), "yyyy-MM-dd");

export function parseDate(iso: string) {
  return parseISO(iso);
}

export function isToday(iso: string) {
  return isSameDay(parseISO(iso), startOfDay(new Date()));
}

export function daysAgo(iso: string) {
  return differenceInDays(startOfDay(new Date()), startOfDay(parseISO(iso)));
}

export function formatDate(iso: string, pattern = "d MMM") {
  return format(parseISO(iso), pattern, { locale: ru });
}

export function formatDateFull(iso: string) {
  return format(parseISO(iso), "d MMMM yyyy, EEEE", { locale: ru });
}

export function shortWeekday(iso: string) {
  return format(parseISO(iso), "EEE", { locale: ru });
}

export const MUSCLE_LABELS: Record<string, string> = {
  chest: "Грудь",
  back: "Спина",
  legs: "Ноги",
  shoulders: "Плечи",
  arms: "Руки",
  core: "Кор",
  cardio: "Кардио",
  other: "Другое",
};

export const MUSCLE_ORDER = ["chest", "back", "legs", "shoulders", "arms", "core", "cardio", "other"];

export const MEAL_LABELS: Record<string, string> = {
  breakfast: "Завтрак",
  lunch: "Обед",
  dinner: "Ужин",
  snack: "Перекус",
};

export const MEAL_ORDER = ["breakfast", "lunch", "dinner", "snack"];

export const GOAL_LABELS: Record<string, string> = {
  cut: "Сушка / жиросжигание",
  recomp: "Рекомпозиция",
  maintain: "Поддержание",
  bulk: "Набор массы",
};

export const ACTIVITY_LABELS: Record<string, string> = {
  sedentary: "Минимальная",
  light: "Лёгкая (1–2 трен.)",
  moderate: "Средняя (3–4 трен.)",
  high: "Высокая (5–6 трен.)",
  athlete: "Очень высокая",
};

export const ACTIVITY_K: Record<string, number> = {
  sedentary: 1.2,
  light: 1.375,
  moderate: 1.55,
  high: 1.725,
  athlete: 1.9,
};

export interface MeasurementPoint {
  key: string;
  label: string;
  short: string;
}

export const MEASUREMENT_POINTS: MeasurementPoint[] = [
  { key: "weightKg", label: "Вес тела", short: "Вес" },
  { key: "chest", label: "Грудь", short: "Грудь" },
  { key: "shoulders", label: "Плечи", short: "Плечи" },
  { key: "waist", label: "Талия", short: "Талия" },
  { key: "hips", label: "Таз / бёдра", short: "Таз" },
  { key: "glutes", label: "Ягодицы", short: "Ягодицы" },
  { key: "thigh", label: "Бедро", short: "Бедро" },
  { key: "biceps", label: "Бицепс", short: "Бицепс" },
  { key: "forearm", label: "Предплечье", short: "Предплечье" },
  { key: "neck", label: "Шея", short: "Шея" },
  { key: "calf", label: "Голень", short: "Голень" },
];

/** Epley one-rep-max estimate. */
export function estimate1RM(weightKg: number, reps: number) {
  if (reps <= 0 || weightKg <= 0) return 0;
  if (reps === 1) return weightKg;
  return Math.round(weightKg * (1 + reps / 30) * 10) / 10;
}

export function bestSet(sets: Array<{ weightKg: number; reps: number; isWarmup?: boolean }>) {
  const working = sets.filter((s) => !s.isWarmup && s.weightKg > 0 && s.reps > 0);
  if (working.length === 0) return null;
  return working.reduce((best, s) =>
    estimate1RM(s.weightKg, s.reps) > estimate1RM(best.weightKg, best.reps) ? s : best,
  );
}

export function fmt(n: number | null | undefined, digits = 0) {
  if (n === null || n === undefined || Number.isNaN(n)) return "—";
  return n.toLocaleString("ru-RU", {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  });
}

export function signed(n: number, digits = 1) {
  const v = Number(n.toFixed(digits));
  return `${v > 0 ? "+" : v < 0 ? "−" : ""}${Math.abs(v).toLocaleString("ru-RU", {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  })}`;
}

export function clamp(n: number, min: number, max: number) {
  return Math.min(max, Math.max(min, n));
}

export function pct(part: number, total: number) {
  if (!total) return 0;
  return clamp(Math.round((part / total) * 100), 0, 999);
}

/** Mifflin-St Jeor BMR. */
export function calcBMR(sex: string, weightKg: number, heightCm: number, age: number) {
  const base = 10 * weightKg + 6.25 * heightCm - 5 * age;
  return Math.round(sex === "female" ? base - 161 : base + 5);
}

export function ageFrom(birthDate?: string | null) {
  if (!birthDate) return 30;
  const b = parseISO(birthDate);
  const now = new Date();
  let age = now.getFullYear() - b.getFullYear();
  const m = now.getMonth() - b.getMonth();
  if (m < 0 || (m === 0 && now.getDate() < b.getDate())) age--;
  return age || 30;
}

export function macroTargets(goal: string, tdee: number) {
  let kcal = tdee;
  if (goal === "cut") kcal = tdee - 450;
  else if (goal === "bulk") kcal = tdee + 350;
  return {
    calories: Math.round(kcal),
    protein: Math.round((kcal * 0.3) / 4),
    fat: Math.round((kcal * 0.27) / 9),
    carbs: Math.round((kcal * 0.43) / 4),
  };
}
