import { NextResponse } from "next/server";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { aiAnalyses } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSeeded();
  const rows = await db
    .select({
      id: aiAnalyses.id,
      kind: aiAnalyses.kind,
      title: aiAnalyses.title,
      periodLabel: aiAnalyses.periodLabel,
      summary: aiAnalyses.summary,
      score: aiAnalyses.score,
      online: aiAnalyses.online,
      provider: aiAnalyses.provider,
      model: aiAnalyses.model,
      error: aiAnalyses.error,
      createdAt: aiAnalyses.createdAt,
    })
    .from(aiAnalyses)
    .orderBy(desc(aiAnalyses.createdAt))
    .limit(100);
  return NextResponse.json({ analyses: rows });
}
