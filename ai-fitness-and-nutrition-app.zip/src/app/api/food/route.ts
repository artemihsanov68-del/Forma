import { NextResponse } from "next/server";
import { asc, ilike } from "drizzle-orm";
import { db } from "@/db";
import { foodCatalog } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  await ensureSeeded();
  const q = new URL(req.url).searchParams.get("q")?.trim();
  const rows = q
    ? await db
        .select()
        .from(foodCatalog)
        .where(ilike(foodCatalog.name, `%${q}%`))
        .orderBy(asc(foodCatalog.name))
        .limit(60)
    : await db.select().from(foodCatalog).orderBy(asc(foodCatalog.category), asc(foodCatalog.name));
  return NextResponse.json({ foods: rows });
}

export async function POST(req: Request) {
  await ensureSeeded();
  const body = (await req.json()) as Record<string, unknown>;
  const name = String(body.name ?? "").trim();
  if (!name) return NextResponse.json({ error: "Укажите название продукта" }, { status: 400 });
  const num = (v: unknown, d = 0) => (typeof v === "number" && Number.isFinite(v) ? v : Number(v) || d);
  const [created] = await db
    .insert(foodCatalog)
    .values({
      name,
      category: String(body.category ?? "Моё"),
      kcal: num(body.kcal),
      protein: num(body.protein),
      fat: num(body.fat),
      carbs: num(body.carbs),
      perGrams: num(body.perGrams, 100) || 100,
      isCustom: true,
    })
    .returning();
  return NextResponse.json({ food: created });
}
