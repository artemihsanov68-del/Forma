"use client";

import { useEffect, useState } from "react";
import { RefreshCcw, Save, Trash2 } from "lucide-react";
import { api, patch } from "@/lib/client";
import type { ProfileData } from "@/lib/types";
import { Btn, Field, Input, Select, Sheet } from "@/components/ui";
import { ACTIVITY_LABELS, GOAL_LABELS } from "@/lib/utils";

export function ProfileSheet({
  open,
  onClose,
  profile,
  onSaved,
}: {
  open: boolean;
  onClose: () => void;
  profile: ProfileData | null;
  onSaved: () => void;
}) {
  const [form, setForm] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [confirmReset, setConfirmReset] = useState(false);
  const [resetting, setResetting] = useState(false);

  async function doReset() {
    setResetting(true);
    try {
      await api("/api/reset", { method: "POST" });
      setConfirmReset(false);
      onSaved();
      onClose();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Не удалось очистить данные");
    } finally {
      setResetting(false);
    }
  }

  useEffect(() => {
    if (!open || !profile?.profile) return;
    const p = profile.profile;
    setForm({
      name: p.name ?? "",
      sex: p.sex ?? "male",
      birthDate: p.birthDate ?? "",
      heightCm: String(p.heightCm ?? ""),
      activityLevel: p.activityLevel ?? "moderate",
      goal: p.goal ?? "recomp",
      workoutsPerWeek: String(p.workoutsPerWeek ?? 4),
      targetCalories: String(p.targetCalories ?? ""),
      targetProtein: String(p.targetProtein ?? ""),
      targetFat: String(p.targetFat ?? ""),
      targetCarbs: String(p.targetCarbs ?? ""),
    });
    setError(null);
  }, [open, profile]);

  const set = (k: string, v: string) => setForm((f) => ({ ...f, [k]: v }));
  const suggested = profile?.targets.suggested;

  async function save() {
    setSaving(true);
    setError(null);
    try {
      await patch("/api/profile", {
        name: form.name || "Атлет",
        sex: form.sex,
        birthDate: form.birthDate || null,
        heightCm: Number(form.heightCm) || 178,
        activityLevel: form.activityLevel,
        goal: form.goal,
        workoutsPerWeek: Number(form.workoutsPerWeek) || 4,
        targetCalories: Number(form.targetCalories) || 0,
        targetProtein: Number(form.targetProtein) || 0,
        targetFat: Number(form.targetFat) || 0,
        targetCarbs: Number(form.targetCarbs) || 0,
      });
      onSaved();
      onClose();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Не удалось сохранить");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Sheet
      open={open}
      onClose={onClose}
      title="Профиль и цели"
      subtitle={`BMR ${profile?.bmr ?? "—"} ккал · TDEE ≈ ${profile?.tdee ?? "—"} ккал · вес ${profile?.weight ?? "—"} кг`}
      footer={
        <div className="flex items-center gap-3">
          {error ? <span className="flex-1 text-[12px] text-rose-glow">{error}</span> : <span className="flex-1" />}
          <Btn onClick={onClose}>Отмена</Btn>
          <Btn variant="primary" onClick={() => void save()} disabled={saving}>
            <Save className="size-4" /> {saving ? "Сохраняем…" : "Сохранить"}
          </Btn>
        </div>
      }
    >
      <div className="space-y-4">
        <div className="grid gap-3.5 sm:grid-cols-2">
          <Field label="Имя">
            <Input value={form.name ?? ""} onChange={(e) => set("name", e.target.value)} placeholder="Атлет" />
          </Field>
          <Field label="Пол">
            <Select value={form.sex ?? "male"} onChange={(e) => set("sex", e.target.value)}>
              <option value="male">Мужской</option>
              <option value="female">Женский</option>
            </Select>
          </Field>
          <Field label="Дата рождения">
            <Input type="date" value={form.birthDate ?? ""} onChange={(e) => set("birthDate", e.target.value)} />
          </Field>
          <Field label="Рост, см">
            <Input
              type="number"
              inputMode="decimal"
              value={form.heightCm ?? ""}
              onChange={(e) => set("heightCm", e.target.value)}
            />
          </Field>
          <Field label="Цель">
            <Select value={form.goal ?? "recomp"} onChange={(e) => set("goal", e.target.value)}>
              {Object.entries(GOAL_LABELS).map(([k, v]) => (
                <option key={k} value={k}>
                  {v}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Активность">
            <Select
              value={form.activityLevel ?? "moderate"}
              onChange={(e) => set("activityLevel", e.target.value)}
            >
              {Object.entries(ACTIVITY_LABELS).map(([k, v]) => (
                <option key={k} value={k}>
                  {v}
                </option>
              ))}
            </Select>
          </Field>
        </div>

        <div className="glass-inset rounded-2xl p-4">
          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="text-[13px] font-semibold text-white">Суточные цели КБЖУ</p>
              <p className="mt-0.5 text-[11.5px] text-mist">
                Расчёт по Миффлину-Сан Жору с учётом цели «{GOAL_LABELS[form.goal ?? "recomp"] ?? ""}»
              </p>
            </div>
            <Btn
              size="sm"
              variant="subtle"
              onClick={() => {
                if (!suggested) return;
                set("targetCalories", String(suggested.calories));
                set("targetProtein", String(suggested.protein));
                set("targetFat", String(suggested.fat));
                set("targetCarbs", String(suggested.carbs));
              }}
            >
              <RefreshCcw className="size-3.5" /> Рассчитать
            </Btn>
          </div>
          <div className="mt-3.5 grid grid-cols-2 gap-3 sm:grid-cols-4">
            <Field label="Ккал">
              <Input
                type="number"
                value={form.targetCalories ?? ""}
                onChange={(e) => set("targetCalories", e.target.value)}
              />
            </Field>
            <Field label="Белки, г">
              <Input
                type="number"
                value={form.targetProtein ?? ""}
                onChange={(e) => set("targetProtein", e.target.value)}
              />
            </Field>
            <Field label="Жиры, г">
              <Input
                type="number"
                value={form.targetFat ?? ""}
                onChange={(e) => set("targetFat", e.target.value)}
              />
            </Field>
            <Field label="Углеводы, г">
              <Input
                type="number"
                value={form.targetCarbs ?? ""}
                onChange={(e) => set("targetCarbs", e.target.value)}
              />
            </Field>
          </div>
          {suggested ? (
            <p className="mt-3 text-[11.5px] text-mist/80">
              Авто-расчёт: {suggested.calories} ккал · Б {suggested.protein} · Ж {suggested.fat} · У{" "}
              {suggested.carbs}
            </p>
          ) : null}
        </div>

        <Field label="План тренировок в неделю">
          <Input
            type="number"
            min={1}
            max={14}
            value={form.workoutsPerWeek ?? ""}
            onChange={(e) => set("workoutsPerWeek", e.target.value)}
          />
        </Field>

        <div className="rounded-2xl border border-rose-glow/20 bg-rose-glow/[0.06] p-4">
          <p className="text-[13px] font-semibold text-white">Очистить мои данные</p>
          <p className="mt-1 text-[11.5px] leading-relaxed text-mist">
            Удалит все тренировки, записи питания, обхваты и сохранённые ИИ-разборы. Профиль и
            каталоги продуктов/упражнений останутся.
          </p>
          <div className="mt-3 flex items-center gap-2">
            {confirmReset ? (
              <>
                <Btn
                  size="sm"
                  variant="danger"
                  disabled={resetting}
                  onClick={() => void doReset()}
                >
                  {resetting ? "Удаляем…" : "Да, удалить всё"}
                </Btn>
                <Btn size="sm" variant="subtle" onClick={() => setConfirmReset(false)}>
                  Отмена
                </Btn>
              </>
            ) : (
              <Btn size="sm" variant="danger" onClick={() => setConfirmReset(true)}>
                <Trash2 className="size-3.5" /> Очистить
              </Btn>
            )}
          </div>
        </div>
      </div>
    </Sheet>
  );
}
