"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { AlertTriangle, Award, Dumbbell, LineChart, PieChart, TrendingUp } from "lucide-react";
import { api } from "@/lib/client";
import type { AnalyticsResponse, ProgressionEntry } from "@/lib/types";
import { Btn, Card, Chip, EmptyState, SectionHeading, Skeleton, Stat } from "@/components/ui";
import { BarsChart, TrendChart } from "@/components/charts";
import { MUSCLE_LABELS, formatDate, fmt, signed } from "@/lib/utils";

const PERIODS = [
  { value: 30, label: "30 дней" },
  { value: 90, label: "90 дней" },
  { value: 180, label: "6 месяцев" },
  { value: 365, label: "Год" },
];

const MUSCLE_COLORS = ["#a78bfa", "#46e0ff", "#a6f97c", "#ffce6b", "#ff8fb1", "#5eead4", "#c084fc", "#f472b6"];

export default function ProgressPage() {
  const [data, setData] = useState<AnalyticsResponse | null>(null);
  const [days, setDays] = useState(90);
  const [activeExercise, setActiveExercise] = useState<string | null>(null);
  const [metric, setMetric] = useState<"e1rm" | "volume">("e1rm");
  const [loading, setLoading] = useState(true);

  const load = useCallback(async (d: number) => {
    setLoading(true);
    try {
      setData(await api<AnalyticsResponse>(`/api/analytics?days=${d}`));
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load(days);
  }, [days, load]);

  const progression = data?.training.progression ?? [];
  const current: ProgressionEntry | undefined = useMemo(
    () => progression.find((p) => p.exercise === activeExercise) ?? progression[0],
    [progression, activeExercise],
  );

  if (loading || !data) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-40 w-full" />
        <Skeleton className="h-80 w-full" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  const t = data.training;
  const chartData = (current?.history ?? []).map((h) => ({
    date: h.date,
    e1rm: h.e1rm,
    topWeight: h.topWeight,
    volume: h.volume,
    reps: h.reps,
  }));
  const stalled = progression.filter((p) => p.stalled && p.sessions >= 3);
  const declining = progression.filter((p) => p.trend === "down" && p.sessions >= 3);

  return (
    <div className="space-y-5">
      <Card className="p-5 sm:p-6">
        <SectionHeading
          title="График прогрессии"
          subtitle="Расчётный 1ПМ по формуле Эппли, тоннаж и распределение нагрузки"
          icon={<LineChart className="size-5" />}
          action={
            <div className="scroll-x flex gap-2 overflow-x-auto">
              {PERIODS.map((p) => (
                <Chip key={p.value} active={days === p.value} onClick={() => setDays(p.value)}>
                  {p.label}
                </Chip>
              ))}
            </div>
          }
        />
        <div className="mt-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
          <Stat
            label="Тренировок"
            value={t.workoutCount}
            delta={`${t.workoutsPerWeek} в неделю · план ${data.profile.profile?.workoutsPerWeek ?? "—"}`}
            tone={t.workoutsPerWeek >= (data.profile.profile?.workoutsPerWeek ?? 4) ? "good" : "warn"}
          />
          <Stat
            label="Тоннаж"
            value={fmt(t.totalVolume)}
            unit="кг"
            delta={`в среднем ${fmt(t.avgVolume)} кг за сессию`}
          />
          <Stat
            label="Подходов"
            value={fmt(t.totalSets)}
            delta={`${t.avgSetsPerWorkout} на тренировку`}
          />
          <Stat
            label="Недельный объём"
            value={fmt(t.weeklyVolume)}
            unit="кг"
            delta={`${signed(t.volumeTrendPct, 0)}% к прошлой неделе`}
            tone={t.volumeTrendPct >= 0 ? "good" : "warn"}
          />
        </div>
      </Card>

      <Card className="p-5">
        <SectionHeading
          title={current ? current.exercise : "Прогрессия упражнения"}
          subtitle={
            current
              ? `${MUSCLE_LABELS[current.muscleGroup] ?? current.muscleGroup} · ${current.sessions} сессий · ${
                  current.unit === "kg"
                    ? `${fmt(current.firstValue, 1)} → ${fmt(current.lastValue, 1)} кг (${signed(current.changePct, 1)}%)`
                    : `${fmt(current.firstValue)} → ${fmt(current.lastValue)} сек`
                }`
              : "Нет данных"
          }
          icon={<TrendingUp className="size-5" />}
          action={
            current?.unit === "kg" ? (
              <div className="glass-inset flex gap-1 rounded-full p-1">
                {(
                  [
                    { k: "e1rm", l: "1ПМ" },
                    { k: "volume", l: "Объём" },
                  ] as const
                ).map((o) => (
                  <button
                    key={o.k}
                    type="button"
                    onClick={() => setMetric(o.k)}
                    className={
                      "rounded-full px-3 py-1.5 text-[12px] font-semibold transition-all " +
                      (metric === o.k
                        ? "tab-active-glow bg-gradient-to-b from-white/20 to-white/8 text-white"
                        : "text-mist hover:text-white/80")
                    }
                  >
                    {o.l}
                  </button>
                ))}
              </div>
            ) : null
          }
        />

        {progression.length ? (
          <>
            <div className="scroll-x mt-4 flex gap-2 overflow-x-auto pb-1">
              {progression.map((p) => (
                <Chip
                  key={p.exercise}
                  active={current?.exercise === p.exercise}
                  onClick={() => setActiveExercise(p.exercise)}
                >
                  <span className="flex items-center gap-1.5">
                    {p.exercise}
                    <span
                      className={
                        "text-[10.5px] font-semibold " +
                        (p.trend === "up" ? "text-lime-glow" : p.trend === "down" ? "text-rose-glow" : "text-mist")
                      }
                    >
                      {signed(p.changePct, 0)}%
                    </span>
                  </span>
                </Chip>
              ))}
            </div>

            <div className="mt-4">
              {chartData.length ? (
                <TrendChart
                  data={chartData}
                  unit={metric === "e1rm" ? "кг" : "кг·повт"}
                  height={300}
                  series={
                    metric === "e1rm"
                      ? [
                          { key: "e1rm", name: "Расчётный 1ПМ", color: "#a78bfa" },
                          { key: "topWeight", name: "Рабочий вес", color: "#46e0ff", dashed: true },
                        ]
                      : [{ key: "volume", name: "Объём упражнения", color: "#a6f97c" }]
                  }
                  area={metric === "volume"}
                />
              ) : (
                <EmptyState title="Недостаточно подходов" hint="Записывайте вес и повторения в подходах." />
              )}
            </div>
          </>
        ) : (
          <div className="mt-4">
            <EmptyState
              icon={<Dumbbell className="size-8" />}
              title="Прогрессии пока нет"
              hint="Добавьте тренировки с рабочими весами — график построится автоматически."
              action={
                <Link href="/workouts?new=1">
                  <Btn variant="primary">Создать тренировку</Btn>
                </Link>
              }
            />
          </div>
        )}
      </Card>

      <div className="grid gap-4 xl:grid-cols-2">
        <Card className="p-5">
          <SectionHeading
            title="Объём по неделям"
            subtitle="Тоннаж и число рабочих подходов"
            icon={<TrendingUp className="size-5" />}
          />
          <div className="mt-4">
            {t.weeklySeries.length ? (
              <TrendChart
                data={t.weeklySeries.map((w) => ({ ...w, date: w.week }))}
                series={[{ key: "volume", name: "Объём, кг", color: "#a78bfa" }]}
                area
                unit="кг"
                height={240}
              />
            ) : (
              <EmptyState title="Нет данных" />
            )}
          </div>
        </Card>

        <Card className="p-5">
          <SectionHeading
            title="Подходы по неделям"
            subtitle="Плотность нагрузки и частота"
            icon={<PieChart className="size-5" />}
          />
          <div className="mt-4">
            {t.weeklySeries.length ? (
              <BarsChart
                data={t.weeklySeries.map((w) => ({ ...w, date: w.week }))}
                xKey="date"
                series={[
                  { key: "sets", name: "Подходы", color: "#46e0ff" },
                  { key: "workouts", name: "Тренировки", color: "#a6f97c" },
                ]}
                height={240}
              />
            ) : (
              <EmptyState title="Нет данных" />
            )}
          </div>
        </Card>
      </div>

      <div className="grid gap-4 xl:grid-cols-3">
        <Card className="p-5">
          <SectionHeading
            title="Баланс мышечных групп"
            subtitle="Доля подходов за период"
            icon={<PieChart className="size-5" />}
          />
          <div className="mt-4 space-y-3">
            {t.muscleSplit.length ? (
              t.muscleSplit.map((m, i) => (
                <div key={m.group}>
                  <div className="mb-1.5 flex items-baseline justify-between">
                    <span className="text-[12.5px] font-medium text-white/90">
                      {MUSCLE_LABELS[m.group] ?? m.group}
                    </span>
                    <span className="text-[11.5px] text-mist">
                      {m.sets} подх. · {m.share}% · {fmt(m.volume)} кг
                    </span>
                  </div>
                  <div className="glass-inset h-2.5 w-full overflow-hidden rounded-full">
                    <div
                      className="h-full rounded-full"
                      style={{
                        width: `${m.share}%`,
                        background: `linear-gradient(90deg, ${MUSCLE_COLORS[i % MUSCLE_COLORS.length]}, ${MUSCLE_COLORS[(i + 1) % MUSCLE_COLORS.length]})`,
                        boxShadow: `0 0 14px ${MUSCLE_COLORS[i % MUSCLE_COLORS.length]}55`,
                        transition: "width 900ms cubic-bezier(0.22,1,0.36,1)",
                      }}
                    />
                  </div>
                </div>
              ))
            ) : (
              <EmptyState title="Нет данных" />
            )}
          </div>
        </Card>

        <Card className="p-5">
          <SectionHeading
            title="Личные рекорды"
            subtitle="Лучший расчётный 1ПМ за период"
            icon={<Award className="size-5" />}
          />
          <div className="mt-4 space-y-2">
            {t.personalRecords.length ? (
              t.personalRecords.slice(0, 8).map((pr) => (
                <div
                  key={pr.exercise}
                  className="glass-inset flex items-center gap-3 rounded-2xl px-3.5 py-2.5"
                >
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[13px] font-semibold text-white">{pr.exercise}</p>
                    <p className="mt-0.5 text-[11px] text-mist">
                      {fmt(pr.weightKg, 1)} кг × {pr.reps} · {formatDate(pr.date, "d MMM")}
                    </p>
                  </div>
                  <span className="shrink-0 rounded-full bg-violet-glow/16 px-2.5 py-1 text-[12px] font-semibold text-[#cbb8ff]">
                    {fmt(pr.e1rm, 1)} кг
                  </span>
                </div>
              ))
            ) : (
              <EmptyState title="Рекордов пока нет" />
            )}
          </div>
        </Card>

        <Card className="p-5">
          <SectionHeading
            title="Зоны внимания"
            subtitle="Плато и регресс силовых"
            icon={<AlertTriangle className="size-5" />}
          />
          <div className="mt-4 space-y-2">
            {[...stalled, ...declining].length ? (
              [...stalled, ...declining].slice(0, 8).map((p) => (
                <div key={p.exercise} className="glass-inset rounded-2xl px-3.5 py-2.5">
                  <div className="flex items-center justify-between gap-2">
                    <p className="truncate text-[13px] font-semibold text-white">{p.exercise}</p>
                    <span
                      className={
                        "shrink-0 rounded-full px-2.5 py-1 text-[11px] font-semibold " +
                        (p.trend === "down"
                          ? "bg-rose-glow/14 text-rose-glow"
                          : "bg-amber-glow/14 text-amber-glow")
                      }
                    >
                      {p.trend === "down" ? "регресс" : "плато"}
                    </span>
                  </div>
                  <p className="mt-1 text-[11.5px] text-mist">
                    {p.sessions} сессий · {fmt(p.lastValue, 1)} {p.unit === "kg" ? "кг e1RM" : "сек"} ·{" "}
                    {signed(p.changePct, 1)}% за период
                  </p>
                </div>
              ))
            ) : (
              <EmptyState
                title="Всё растёт"
                hint="Ни одно упражнение не стоит на месте — продолжайте в том же духе."
              />
            )}
          </div>
        </Card>
      </div>
    </div>
  );
}
