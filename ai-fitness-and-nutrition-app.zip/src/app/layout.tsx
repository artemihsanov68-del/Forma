import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { AppShell } from "@/components/AppShell";
import { PwaProvider } from "@/components/Pwa";

export const metadata: Metadata = {
  applicationName: "FORMA",
  title: {
    default: "FORMA — тренировки, КБЖУ и ИИ-анализ",
    template: "%s · FORMA",
  },
  description:
    "Дневник тренировок, учёт калорий и БЖУ, обхваты тела, графики прогрессии и ИИ-разбор вашего тренинга и питания.",
  manifest: "/manifest.webmanifest",
  appleWebApp: {
    capable: true,
    title: "FORMA",
    statusBarStyle: "black-translucent",
    startupImage: [
      {
        url: "/icons/splash-750x1334.png",
        media:
          "(device-width: 375px) and (device-height: 667px) and (-webkit-device-pixel-ratio: 2)",
      },
      {
        url: "/icons/splash-1170x2532.png",
        media:
          "(device-width: 390px) and (device-height: 844px) and (-webkit-device-pixel-ratio: 3)",
      },
      {
        url: "/icons/splash-1179x2556.png",
        media:
          "(device-width: 393px) and (device-height: 852px) and (-webkit-device-pixel-ratio: 3)",
      },
      {
        url: "/icons/splash-1284x2778.png",
        media:
          "(device-width: 428px) and (device-height: 926px) and (-webkit-device-pixel-ratio: 3)",
      },
      {
        url: "/icons/splash-2048x2732.png",
        media:
          "(device-width: 1024px) and (device-height: 1366px) and (-webkit-device-pixel-ratio: 2)",
      },
    ],
  },
  icons: {
    icon: [
      { url: "/icons/favicon-32.png", sizes: "32x32", type: "image/png" },
      { url: "/icons/icon-192.png", sizes: "192x192", type: "image/png" },
    ],
    apple: [{ url: "/icons/apple-touch-icon.png", sizes: "180x180", type: "image/png" }],
  },
  formatDetection: { telephone: false },
  other: {
    "mobile-web-app-capable": "yes",
    "apple-mobile-web-app-capable": "yes",
  },
};

export const viewport: Viewport = {
  themeColor: "#05060c",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  viewportFit: "cover",
};

/** Captures Android's install prompt before hydration so the in-app button can use it. */
const INSTALL_CAPTURE = `(function(){window.__formaPrompt=null;window.addEventListener('beforeinstallprompt',function(e){e.preventDefault();window.__formaPrompt=e;window.dispatchEvent(new Event('forma-installable'));});window.addEventListener('appinstalled',function(){window.__formaInstalled=true;window.dispatchEvent(new Event('forma-installed'));});})();`;

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ru">
      <head>
        <script dangerouslySetInnerHTML={{ __html: INSTALL_CAPTURE }} />
      </head>
      <body className="min-h-screen text-ink antialiased">
        <div className="aurora">
          <span className="blob blob-a" />
          <span className="blob blob-b" />
          <span className="blob blob-c" />
        </div>
        <div className="grain" />
        <PwaProvider />
        <AppShell>{children}</AppShell>
      </body>
    </html>
  );
}
