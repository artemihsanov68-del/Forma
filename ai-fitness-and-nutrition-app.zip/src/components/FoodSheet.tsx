"use client";

import { useEffect, useMemo, useState } from "react";
import { Plus, Search, Utensils } from "lucide-react";
import { api, post } from "@/lib/client";
import type { FoodDTO } from "@/lib/types";
import { Btn, Field, Input, Segmented, Sheet } from "@/components/ui";
import { MEAL_LABELS, fmt } from "@/lib/utils";

const QUICK = [50, 100, 150, 200, 250, 300];

export function FoodSheet({
  open,
  onClose,
  date,
  meal,
  onSaved,
}: {
  open: boolean;
  onClose: () => void;
  date: string;
  meal: string;
  onSaved: () => void;
}) {
  const [mode, setMode] = useState<"catalog" | "custom">("catalog");
  const [query, setQuery] = useState("");
  const [foods, setFoods] = useState<FoodDTO[]>([]);
  const [selected, setSelected] = useState<FoodDTO | null>(null);
  const [grams, setGrams] = useState("150");
  const [activeMeal, setActiveMeal] = useState(meal);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [custom, setCustom] = useState({
    name: "",
    kcal: "",
    protein: "",
    fat: "",
    carbs: "",
    perGrams: "100",
  });

  useEffect(() => {
    if (open) {
      setActiveMeal(meal);
      setQuery("");
      setSelected(null);
      setGrams("150");
      setError(null);
    }
  }, [open, meal]);

  useEffect(() => {
    if (!open || mode !== "catalog") return;
    const t = setTimeout(() => {
      api<{ foods: FoodDTO[] }>(`/api/food?q=${encodeURIComponent(query)}`)
        .then((r) => setFoods(r.foods))
        .catch(() => setFoods([]));
    }, 180);
    return () => clearTimeout(t);
  }, [query, open, mode]);

  const g = Number(grams) || 0;
  const perGrams = Number(selected?.perGrams ?? 100) || 100;
  const preview = useMemo(() => {
    const k = g / perGrams;
    if (mode === "catalog" && selected) {
      return {
        kcal: Math.round(selected.kcal * k),
        protein: Math.round(selected.protein * k * 10) / 10,
        fat: Math.round(selected.fat * k * 10) / 10,
        carbs: Math.round(selected.carbs * k * 10) / 10,
      };
    }
    const per = Number(custom.perGrams) || 100;
    const kc = g / per;
    return {
      kcal: Math.round((Number(custom.kcal) || 0) * kc),
      protein: Math.round((Number(custom.protein) || 0) * kc * 10) / 10,
      fat: Math.round((Number(custom.fat) || 0) * kc * 10) / 10,
      carbs: Math.round((Number(custom.carbs) || 0) * kc * 10) / 10,
    };
  }, [g, perGrams, selected, mode, custom]);

  async function save() {
    setSaving(true);
    setError(null);
    try {
      if (mode === "catalog") {
        if (!selected) throw new Error("Выберите продукт");
        await post("/api/nutrition", {
          date,
          meal: activeMeal,
          foodId: selected.id,
          name: selected.name,
          grams: g,
        });
      } else {
        if (!custom.name.trim()) throw new Error("Введите название блюда");
        const per = Number(custom.perGrams) || 100;
        await post("/api/nutrition", {
          date,
          meal: activeMeal,
          name: custom.name.trim(),
          grams: g,
          kcal: preview.kcal,
          protein: preview.protein,
          fat: preview.fat,
          carbs: preview.carbs,
        });
        await post("/api/food", {
          name: custom.name.trim(),
          category: "Моё",
          kcal: Number(custom.kcal) || 0,
          protein: Number(custom.protein) || 0,
          fat: Number(custom.fat) || 0,
          carbs: Number(custom.carbs) || 0,
          perGrams: per,
        });
      }
      onSaved();
      onClose();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Не удалось добавить");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Sheet
      open={open}
      onClose={onClose}
      title="Добавить в дневник"
      subtitle={`${new Date(`${date}T12:00:00`).toLocaleDateString("ru-RU", { day: "numeric", month: "long" })} · ${MEAL_LABELS[activeMeal] ?? activeMeal}`}
      footer={
        <div className="flex items-center gap-3">
          {error ? (
            <span className="flex-1 text-[12px] text-rose-glow">{error}</span>
          ) : (
            <span className="flex-1 text-[12px] text-mist">
              {fmt(preview.kcal)} ккал · Б {fmt(preview.protein, 1)} · Ж {fmt(preview.fat, 1)} · У{" "}
              {fmt(preview.carbs, 1)}
            </span>
          )}
          <Btn variant="primary" onClick={() => void save()} disabled={saving}>
            <Plus className="size-4" /> {saving ? "…" : "Добавить"}
          </Btn>
        </div>
      }
    >
      <div className="space-y-4">
        <div className="flex gap-2">
          {(["breakfast", "lunch", "dinner", "snack"] as const).map((m) => (
            <button
              key={m}
              type="button"
              onClick={() => setActiveMeal(m)}
              className={
                "flex-1 rounded-2xl border px-2 py-2 text-[12px] font-semibold transition-all " +
                (activeMeal === m
                  ? "tab-active-glow border-white/25 bg-gradient-to-b from-white/18 to-white/6 text-white"
                  : "border-white/8 bg-white/[0.03] text-mist")
              }
            >
              {MEAL_LABELS[m]}
            </button>
          ))}
        </div>

        <Segmented
          value={mode}
          onChange={setMode}
          options={[
            { value: "catalog", label: "Из каталога" },
            { value: "custom", label: "Своё блюдо" },
          ]}
        />

        {mode === "catalog" ? (
          <div className="space-y-3">
            <div className="relative">
              <Search className="pointer-events-none absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-mist/60" />
              <Input
                autoFocus
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Курица, рис, творог…"
                className="pl-10"
              />
            </div>
            <div className="thin-scroll max-h-[300px] space-y-1.5 overflow-y-auto pr-1">
              {foods.map((f) => (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => {
                    setSelected(f);
                    setGrams(String(f.perGrams === 30 ? 30 : 150));
                  }}
                  className={
                    "flex w-full items-center gap-3 rounded-2xl border px-3.5 py-2.5 text-left transition-all " +
                    (selected?.id === f.id
                      ? "border-violet-glow/45 bg-violet-glow/12"
                      : "border-white/8 bg-white/[0.03] hover:border-white/18")
                  }
                >
                  <Utensils className="size-4 shrink-0 text-mist/70" />
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[13px] font-medium text-white">{f.name}</span>
                    <span className="block text-[11px] text-mist">
                      {f.category} · на {fmt(f.perGrams)} г: {fmt(f.kcal)} ккал, Б {fmt(f.protein, 1)}, Ж{" "}
                      {fmt(f.fat, 1)}, У {fmt(f.carbs, 1)}
                    </span>
                  </span>
                </button>
              ))}
              {!foods.length ? (
                <p className="px-2 py-6 text-center text-[12.5px] text-mist">
                  Ничего не найдено — переключитесь на «Своё блюдо».
                </p>
              ) : null}
            </div>
          </div>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Название" className="sm:col-span-2">
              <Input
                value={custom.name}
                onChange={(e) => setCustom({ ...custom, name: e.target.value })}
                placeholder="Например: домашний плов"
              />
            </Field>
            <Field label="Порция справочника, г">
              <Input
                type="number"
                value={custom.perGrams}
                onChange={(e) => setCustom({ ...custom, perGrams: e.target.value })}
              />
            </Field>
            <Field label="Ккал">
              <Input
                type="number"
                value={custom.kcal}
                onChange={(e) => setCustom({ ...custom, kcal: e.target.value })}
                placeholder="0"
              />
            </Field>
            <Field label="Белки, г">
              <Input
                type="number"
                value={custom.protein}
                onChange={(e) => setCustom({ ...custom, protein: e.target.value })}
                placeholder="0"
              />
            </Field>
            <Field label="Жиры, г">
              <Input
                type="number"
                value={custom.fat}
                onChange={(e) => setCustom({ ...custom, fat: e.target.value })}
                placeholder="0"
              />
            </Field>
            <Field label="Углеводы, г" className="sm:col-span-2">
              <Input
                type="number"
                value={custom.carbs}
                onChange={(e) => setCustom({ ...custom, carbs: e.target.value })}
                placeholder="0"
              />
            </Field>
          </div>
        )}

        <div className="glass-inset rounded-2xl p-4">
          <Field label="Сколько съедено, г">
            <Input
              type="number"
              inputMode="decimal"
              value={grams}
              onChange={(e) => setGrams(e.target.value)}
            />
          </Field>
          <div className="mt-3 flex flex-wrap gap-2">
            {QUICK.map((q) => (
              <button
                key={q}
                type="button"
                onClick={() => setGrams(String(q))}
                className={
                  "rounded-full border px-3 py-1.5 text-[12px] font-medium transition-colors " +
                  (Number(grams) === q
                    ? "border-white/25 bg-white/14 text-white"
                    : "border-white/8 bg-white/[0.03] text-mist hover:text-white")
                }
              >
                {q} г
              </button>
            ))}
          </div>
          <div className="mt-4 grid grid-cols-4 gap-2">
            {[
              { l: "ккал", v: preview.kcal, c: "text-white" },
              { l: "белки", v: preview.protein, c: "text-[#cbb8ff]" },
              { l: "жиры", v: preview.fat, c: "text-amber-glow" },
              { l: "углев.", v: preview.carbs, c: "text-cyan-glow" },
            ].map((x) => (
              <div key={x.l} className="rounded-xl bg-white/[0.04] px-2 py-2 text-center">
                <p className="text-[10px] uppercase tracking-[0.06em] text-mist/70">{x.l}</p>
                <p className={`mt-0.5 text-[14px] font-semibold ${x.c}`}>{fmt(x.v, x.l === "ккал" ? 0 : 1)}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Sheet>
  );
}
