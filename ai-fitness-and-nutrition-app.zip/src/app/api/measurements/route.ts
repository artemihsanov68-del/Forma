import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { format } from "date-fns";
import { db } from "@/db";
import { measurements, profiles } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { buildBodySummary } from "@/lib/stats";
import { MEASUREMENT_POINTS } from "@/lib/utils";

export const dynamic = "force-dynamic";

const FIELDS = [...MEASUREMENT_POINTS.map((p) => p.key), "bodyFat"] as const;

type MeasurementInsert = typeof measurements.$inferInsert;

async function snapshot() {
  const rows = await db.select().from(measurements);
  const summary = await buildBodySummary();
  return { measurements: rows, summary };
}

export async function GET() {
  await ensureSeeded();
  return NextResponse.json(await snapshot());
}

export async function POST(req: Request) {
  await ensureSeeded();
  const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;

  const values: MeasurementInsert = {
    date: typeof body.date === "string" && body.date ? body.date : format(new Date(), "yyyy-MM-dd"),
    notes: typeof body.notes === "string" && body.notes.trim() ? body.notes.trim() : null,
  };

  let hasData = false;
  for (const f of FIELDS) {
    const raw = body[f];
    if (raw === undefined || raw === null || raw === "") {
      (values as Record<string, unknown>)[f] = null;
      continue;
    }
    const parsed = Number(raw);
    (values as Record<string, unknown>)[f] = Number.isFinite(parsed) ? parsed : null;
    if (Number.isFinite(parsed) && parsed > 0) hasData = true;
  }

  if (!hasData) {
    return NextResponse.json({ error: "Заполните хотя бы один показатель" }, { status: 400 });
  }

  const [created] = await db.insert(measurements).values(values).returning();

  if (values.weightKg && values.weightKg > 0) {
    await db.update(profiles).set({ weightKg: values.weightKg, updatedAt: new Date() }).where(eq(profiles.id, 1));
  }

  const snap = await snapshot();
  return NextResponse.json({ measurement: created, ...snap });
}

export async function DELETE(req: Request) {
  await ensureSeeded();
  const id = Number(new URL(req.url).searchParams.get("id"));
  if (!id) return NextResponse.json({ error: "Нужен id" }, { status: 400 });
  await db.delete(measurements).where(eq(measurements.id, id));
  return NextResponse.json({ ok: true, ...(await snapshot()) });
}
