import {
  buildBodySummary,
  buildNutritionSummary,
  buildTrainingSummary,
  getProfileWithTargets,
  type BodySummary,
  type NutritionSummary,
  type TrainingSummary,
} from "@/lib/stats";
import { GOAL_LABELS, MUSCLE_LABELS, estimate1RM } from "@/lib/utils";

export type AnalysisKind = "training" | "nutrition" | "body" | "full";

export const KIND_META: Record<AnalysisKind, { title: string; short: string; period: string }> = {
  training: { title: "Анализ тренировочного процесса", short: "Тренировки", period: "90 дней" },
  nutrition: { title: "Анализ питания и КБЖУ", short: "Питание", period: "30 дней" },
  body: { title: "Анализ антропометрии и обхватов", short: "Тело", period: "вся история" },
  full: { title: "Комплексный разбор: тренировки + питание + тело", short: "Полный разбор", period: "90 дней" },
};

export interface AnalysisResult {
  summary: string;
  score: number;
  highlights: Array<{ title: string; detail: string; tone?: string }>;
  insights: Array<{ title: string; detail: string }>;
  recommendations: Array<{ title: string; detail: string; priority?: string }>;
  plan: string[];
  provider: string;
  model: string;
  online: boolean;
  error?: string | null;
}

export interface CoachContext {
  profile: Awaited<ReturnType<typeof getProfileWithTargets>>;
  training: TrainingSummary;
  nutrition: NutritionSummary;
  body: BodySummary;
}

export async function buildContext(): Promise<CoachContext> {
  const [profile, training, nutrition, body] = await Promise.all([
    getProfileWithTargets(),
    buildTrainingSummary(90),
    buildNutritionSummary(30),
    buildBodySummary(),
  ]);
  return { profile, training, nutrition, body };
}

/* ------------------------------------------------------------------ */
/* Provider detection                                                  */
/* ------------------------------------------------------------------ */

interface Provider {
  name: string;
  model: string;
  apiKey: string;
  baseUrl: string;
  style: "openai" | "anthropic";
}

export function detectProvider(): Provider | null {
  const env = process.env;
  if (env.OPENAI_API_KEY) {
    return {
      name: "OpenAI",
      model: env.OPENAI_MODEL || "gpt-4o-mini",
      apiKey: env.OPENAI_API_KEY,
      baseUrl: (env.OPENAI_BASE_URL || "https://api.openai.com/v1").replace(/\/$/, ""),
      style: "openai",
    };
  }
  if (env.OPENROUTER_API_KEY) {
    return {
      name: "OpenRouter",
      model: env.OPENROUTER_MODEL || "openai/gpt-4o-mini",
      apiKey: env.OPENROUTER_API_KEY,
      baseUrl: "https://openrouter.ai/api/v1",
      style: "openai",
    };
  }
  if (env.GROQ_API_KEY) {
    return {
      name: "Groq",
      model: env.GROQ_MODEL || "llama-3.3-70b-versatile",
      apiKey: env.GROQ_API_KEY,
      baseUrl: "https://api.groq.com/openai/v1",
      style: "openai",
    };
  }
  if (env.ANTHROPIC_API_KEY) {
    return {
      name: "Anthropic",
      model: env.ANTHROPIC_MODEL || "claude-3-5-haiku-latest",
      apiKey: env.ANTHROPIC_API_KEY,
      baseUrl: "https://api.anthropic.com/v1",
      style: "anthropic",
    };
  }
  if (env.AI_API_KEY && env.AI_BASE_URL) {
    return {
      name: env.AI_PROVIDER_NAME || "Custom LLM",
      model: env.AI_MODEL || "gpt-4o-mini",
      apiKey: env.AI_API_KEY,
      baseUrl: env.AI_BASE_URL.replace(/\/$/, ""),
      style: "openai",
    };
  }
  return null;
}

/* ------------------------------------------------------------------ */
/* Prompt                                                              */
/* ------------------------------------------------------------------ */

const SCHEMA_HINT = `Ответь СТРОГО валидным JSON без markdown-обёрток по схеме:
{
  "summary": "2-4 предложения, общая картина",
  "score": число 0-100,
  "highlights": [{"title": "...", "detail": "...", "tone": "good|warn|bad"}],
  "insights": [{"title": "...", "detail": "..."}],
  "recommendations": [{"title": "...", "detail": "...", "priority": "high|medium|low"}],
  "plan": ["конкретный шаг 1", "шаг 2", "..."]
}
highlights: 2-4, insights: 3-5, recommendations: 4-6, plan: 4-6. Только русский язык. Опирайся на цифры из данных, не выдумывай факты.`;

export function buildPrompt(kind: AnalysisKind, ctx: CoachContext) {
  const p = ctx.profile.profile;
  const head = {
    athlete: {
      goal: GOAL_LABELS[p?.goal ?? "recomp"] ?? p?.goal,
      sex: p?.sex,
      age: ctx.profile.age,
      heightCm: p?.heightCm,
      weightKg: ctx.profile.weight,
      bmr: ctx.profile.bmr,
      tdee: ctx.profile.tdee,
      targets: ctx.profile.targets,
      plannedWorkoutsPerWeek: p?.workoutsPerWeek,
    },
  };

  const training = {
    windowDays: ctx.training.days,
    workouts: ctx.training.workoutCount,
    perWeek: ctx.training.workoutsPerWeek,
    totalVolumeKg: ctx.training.totalVolume,
    avgVolumePerWorkoutKg: ctx.training.avgVolume,
    workingSets: ctx.training.totalSets,
    avgDurationMin: ctx.training.avgDuration,
    avgFeeling: ctx.training.avgFeeling,
    weeklyVolumeTrendPct: ctx.training.volumeTrendPct,
    daysSinceLastWorkout: ctx.training.daysSinceLastWorkout,
    muscleSplit: ctx.training.muscleSplit.map((m) => ({
      group: MUSCLE_LABELS[m.group] ?? m.group,
      sets: m.sets,
      sharePct: m.share,
    })),
    weeklyVolume: ctx.training.weeklySeries.slice(-10),
    progression: ctx.training.progression.slice(0, 14).map((pr) => ({
      exercise: pr.exercise,
      sessions: pr.sessions,
      unit: pr.unit,
      first: pr.firstValue,
      last: pr.lastValue,
      changePct: pr.changePct,
      trend: pr.trend,
      stalled: pr.stalled,
      topWeightKg: pr.topWeight,
      recent: pr.history.slice(-6).map((h) => ({
        date: h.date,
        e1rm: h.e1rm,
        weight: h.topWeight,
        reps: h.reps,
      })),
    })),
    personalRecords: ctx.training.personalRecords.slice(0, 8),
  };

  const nutrition = {
    windowDays: ctx.nutrition.days,
    loggedDays: ctx.nutrition.loggedDays,
    avgKcal: ctx.nutrition.avgCalories,
    avgProteinG: ctx.nutrition.avgProtein,
    avgFatG: ctx.nutrition.avgFat,
    avgCarbsG: ctx.nutrition.avgCarbs,
    proteinGPerKg: ctx.nutrition.proteinPerKg,
    fatSharePct: ctx.nutrition.fatSharePct,
    calorieAdherencePct: ctx.nutrition.calorieAdherencePct,
    proteinAdherencePct: ctx.nutrition.proteinAdherencePct,
    daysUnderTarget: ctx.nutrition.daysUnderTarget,
    daysOverTarget: ctx.nutrition.daysOverTarget,
    kcalTrendDelta: ctx.nutrition.weeklyDeltaKcal,
    today: ctx.nutrition.todayTotal,
    last14days: ctx.nutrition.dailySeries.slice(-14),
  };

  const body = {
    measurementCount: ctx.body.measurementCount,
    daysSinceLast: ctx.body.daysSinceLast,
    shoulderToWaistRatio: ctx.body.ratio,
    bodyFatDelta: ctx.body.bodyFatDelta,
    latest: ctx.body.latest,
    changes: ctx.body.changes,
    series: ctx.body.series.slice(-12),
  };

  const payload =
    kind === "training"
      ? { athlete: head.athlete, training }
      : kind === "nutrition"
        ? { athlete: head.athlete, nutrition, bodyWeightTrend: body.changes[0] }
        : kind === "body"
          ? { athlete: head.athlete, body, training: { workouts: training.workouts, perWeek: training.perWeek } }
          : { athlete: head.athlete, training, nutrition, body };

  const focus =
    kind === "training"
      ? "Ты — элитный тренер по силовой подготовке. Оцени объём, интенсивность, частоту, распределение по мышечным группам, прогрессию нагрузок (e1RM), застойные упражнения и риск перетренированности. Дай конкретную схему прогрессии на ближайшие 2-4 недели."
      : kind === "nutrition"
        ? "Ты — спортивный диетолог. Оцени калорийность относительно TDEE и цели, белок на кг веса, долю жиров, углеводы, регулярность ведения дневника. Дай конкретные граммовки и замены продуктов."
        : kind === "body"
          ? "Ты — специалист по антропометрии. Оцени динамику обхватов (грудь, плечи, талия, ягодицы, бедро, бицепс, предплечье), соотношение плечи/талия, признаки рекомпозиции, частоту замеров."
          : "Ты — междисциплинарный спортивный наставник. Свяжи тренировки, питание и антропометрию в единую картину: объясни причинно-следственные связи и дай план на 2 недели.";

  return `${focus}\n\n${SCHEMA_HINT}\n\nДАННЫЕ (JSON):\n${JSON.stringify(payload, null, 1)}`;
}

/* ------------------------------------------------------------------ */
/* Remote call                                                         */
/* ------------------------------------------------------------------ */

async function callProvider(provider: Provider, prompt: string, signal: AbortSignal) {
  if (provider.style === "anthropic") {
    const res = await fetch(`${provider.baseUrl}/messages`, {
      method: "POST",
      signal,
      headers: {
        "content-type": "application/json",
        "x-api-key": provider.apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: provider.model,
        max_tokens: 2400,
        messages: [{ role: "user", content: prompt }],
      }),
    });
    if (!res.ok) throw new Error(`Anthropic ${res.status}: ${(await res.text()).slice(0, 300)}`);
    const data = (await res.json()) as { content?: Array<{ text?: string }> };
    return data.content?.map((c) => c.text ?? "").join("\n") ?? "";
  }

  const res = await fetch(`${provider.baseUrl}/chat/completions`, {
    method: "POST",
    signal,
    headers: {
      "content-type": "application/json",
      authorization: `Bearer ${provider.apiKey}`,
    },
    body: JSON.stringify({
      model: provider.model,
      temperature: 0.4,
      max_tokens: 2400,
      messages: [
        {
          role: "system",
          content:
            "Ты спортивный аналитик. Отвечаешь только валидным JSON на русском языке, без пояснений вне JSON.",
        },
        { role: "user", content: prompt },
      ],
    }),
  });
  if (!res.ok) throw new Error(`${provider.name} ${res.status}: ${(await res.text()).slice(0, 300)}`);
  const data = (await res.json()) as {
    choices?: Array<{ message?: { content?: string } }>;
    usage?: { total_tokens?: number };
  };
  return data.choices?.[0]?.message?.content ?? "";
}

function parseJsonBlock(raw: string) {
  const cleaned = raw
    .trim()
    .replace(/^```(?:json)?/i, "")
    .replace(/```$/i, "")
    .trim();
  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  if (start === -1 || end === -1) throw new Error("В ответе модели нет JSON-объекта");
  return JSON.parse(cleaned.slice(start, end + 1)) as Record<string, unknown>;
}

function normalizeAnalysis(raw: Record<string, unknown>, provider: Provider): AnalysisResult {
  const str = (v: unknown, d = "") => (typeof v === "string" && v.trim() ? v.trim() : d);
  const arr = (v: unknown) => (Array.isArray(v) ? v : []);
  const scoreRaw = Number(raw.score);
  return {
    summary: str(raw.summary, "Модель не вернула краткое резюме."),
    score: Number.isFinite(scoreRaw) ? Math.max(0, Math.min(100, Math.round(scoreRaw))) : 70,
    highlights: arr(raw.highlights)
      .map((h) => {
        const o = (typeof h === "object" && h ? h : { title: str(h) }) as Record<string, unknown>;
        return {
          title: str(o.title, "Наблюдение"),
          detail: str(o.detail),
          tone: ["good", "warn", "bad"].includes(str(o.tone)) ? str(o.tone) : "good",
        };
      })
      .filter((h) => h.title || h.detail),
    insights: arr(raw.insights)
      .map((h) => {
        const o = (typeof h === "object" && h ? h : { title: str(h) }) as Record<string, unknown>;
        return { title: str(o.title, "Инсайт"), detail: str(o.detail) };
      })
      .filter((h) => h.title || h.detail),
    recommendations: arr(raw.recommendations)
      .map((h) => {
        const o = (typeof h === "object" && h ? h : { title: str(h) }) as Record<string, unknown>;
        return {
          title: str(o.title, "Рекомендация"),
          detail: str(o.detail),
          priority: ["high", "medium", "low"].includes(str(o.priority)) ? str(o.priority) : "medium",
        };
      })
      .filter((h) => h.title || h.detail),
    plan: arr(raw.plan).map((p) => str(p)).filter(Boolean),
    provider: provider.name,
    model: provider.model,
    online: true,
  };
}

/* ------------------------------------------------------------------ */
/* Local expert engine (offline fallback)                              */
/* ------------------------------------------------------------------ */

const RECOMMENDED_SPLIT: Record<string, number> = {
  chest: 15,
  back: 20,
  legs: 22,
  shoulders: 12,
  arms: 13,
  core: 8,
  cardio: 10,
};

export function localExpert(kind: AnalysisKind, ctx: CoachContext): AnalysisResult {
  const t = ctx.training;
  const n = ctx.nutrition;
  const b = ctx.body;
  const goal = ctx.profile.profile?.goal ?? "recomp";
  const target = ctx.profile.targets;

  const highlights: AnalysisResult["highlights"] = [];
  const insights: AnalysisResult["insights"] = [];
  const recommendations: AnalysisResult["recommendations"] = [];
  const plan: string[] = [];
  let score = 60;

  const weightDelta = b.changes.find((c) => c.key === "weightKg")?.delta ?? null;
  const waistDelta = b.changes.find((c) => c.key === "waist")?.delta ?? null;
  const bestProgress = [...t.progression].sort((a, b2) => b2.changePct - a.changePct)[0];
  const stalled = t.progression.filter((p) => p.stalled && p.sessions >= 3);
  const declining = t.progression.filter((p) => p.trend === "down" && p.sessions >= 3);

  if (kind === "training" || kind === "full") {
    const planned = ctx.profile.profile?.workoutsPerWeek ?? 4;
    const consistency = planned ? Math.min(1, t.workoutsPerWeek / planned) : 1;
    score = Math.round(
      40 * consistency +
        25 * Math.min(1, Math.max(0, (bestProgress?.changePct ?? 0) / 8)) +
        20 * (t.volumeTrendPct > -5 ? 1 : 0.4) +
        15 * Math.min(1, t.avgFeeling / 4 || 0.5),
    );

    if (bestProgress && bestProgress.changePct > 0) {
      highlights.push({
        title: `Лучший рост: ${bestProgress.exercise}`,
        detail: `Расчётный 1ПМ вырос с ${bestProgress.firstValue} до ${bestProgress.lastValue} кг (${bestProgress.changePct > 0 ? "+" : ""}${bestProgress.changePct}%) за ${bestProgress.sessions} сессий.`,
        tone: "good",
      });
    }
    if (t.personalRecords.length) {
      const pr = t.personalRecords[0];
      highlights.push({
        title: `Личный рекорд: ${pr.exercise}`,
        detail: `${pr.weightKg} кг × ${pr.reps} → e1RM ${pr.e1rm} кг (${pr.date}).`,
        tone: "good",
      });
    }
    highlights.push({
      title: `${t.workoutCount} тренировок за ${t.days} дней`,
      detail: `${t.workoutsPerWeek} в неделю при плане ${ctx.profile.profile?.workoutsPerWeek ?? "—"}. Средний объём ${Math.round(t.avgVolume).toLocaleString("ru-RU")} кг за сессию, ${t.avgSetsPerWorkout} рабочих подходов.`,
      tone: t.workoutsPerWeek >= (ctx.profile.profile?.workoutsPerWeek ?? 4) ? "good" : "warn",
    });

    insights.push({
      title: "Динамика недельного объёма",
      detail: `Последняя неделя ${Math.round(t.weeklyVolume).toLocaleString("ru-RU")} кг против ${Math.round(t.prevWeeklyVolume).toLocaleString("ru-RU")} кг на предыдущей (${t.volumeTrendPct > 0 ? "+" : ""}${t.volumeTrendPct}%). ${
        t.volumeTrendPct > 15
          ? "Рост выше 10–15% в неделю — это агрессивная прогрессия, высок риск перегрузки суставов и ЦНС."
          : t.volumeTrendPct < -20
            ? "Резкое падение объёма обычно означает пропуск тренировок или незапланированный отдых."
            : "Темп изменения объёма в безопасном коридоре прогрессивной перегрузки (5–10% в неделю)."
      }`,
    });

    const legs = t.muscleSplit.find((m) => m.group === "legs");
    const back = t.muscleSplit.find((m) => m.group === "back");
    const chest = t.muscleSplit.find((m) => m.group === "chest");
    const imbalance: string[] = [];
    for (const [group, share] of Object.entries(RECOMMENDED_SPLIT)) {
      const actual = t.muscleSplit.find((m) => m.group === group)?.share ?? 0;
      if (group === "cardio" || group === "core") continue;
      if (actual < share * 0.6) imbalance.push(`${MUSCLE_LABELS[group]} (${actual}% вместо ~${share}%)`);
    }
    insights.push({
      title: "Распределение нагрузки",
      detail: imbalance.length
        ? `Недобор нагрузки: ${imbalance.join(", ")}. ${legs && chest && legs.sets < chest.sets ? "Ноги отстают от жимовых — это ограничивает общий гормональный отклик и силовой прогресс." : ""}`
        : `Баланс близок к оптимальному: ${t.muscleSplit
            .slice(0, 4)
            .map((m) => `${MUSCLE_LABELS[m.group] ?? m.group} ${m.share}%`)
            .join(", ")}.`,
    });

    if (stalled.length) {
      insights.push({
        title: `Застой в ${stalled.length} упражнениях`,
        detail: `${stalled
          .slice(0, 4)
          .map((s) => s.exercise)
          .join(", ")} — рабочие веса не меняются 3+ сессии подряд. Нужна смена стимула, а не добавление подходов.`,
      });
    }
    if (declining.length) {
      insights.push({
        title: "Регресс силовых",
        detail: `${declining
          .slice(0, 3)
          .map((s) => `${s.exercise} (${s.changePct}%)`)
          .join(", ")}. Частые причины: дефицит калорий/белка, недосып, отсутствие разгрузки.`,
      });
    }
    if (t.avgFeeling && t.avgFeeling < 3.4) {
      insights.push({
        title: "Низкое самочувствие на тренировках",
        detail: `Средняя оценка ${t.avgFeeling}/5. При таком фоне силовые растут плохо — приоритет на восстановление.`,
      });
    }
    if (t.daysSinceLastWorkout !== null && t.daysSinceLastWorkout >= 5) {
      insights.push({
        title: "Пауза в тренинге",
        detail: `С последней тренировки прошло ${t.daysSinceLastWorkout} дн. Детренинг начинается примерно с 10-го дня: сначала падает нервно-мышечная эффективность, затем силовые.`,
      });
    }

    recommendations.push({
      title: "Волновая прогрессия 3+1",
      detail: `Три недели добавляйте 2,5 кг на штанговые движения или 1 повтор в подходе, четвёртая — разгрузка (−40% объёма). Ориентир по недельному объёму: ${Math.round((t.avgVolume * (ctx.profile.profile?.workoutsPerWeek ?? 4)) / 100) * 100} кг.`,
      priority: "high",
    });
    if (stalled.length) {
      recommendations.push({
        title: `Перезапустить ${stalled[0].exercise}`,
        detail: `Снизьте рабочий вес на 10% и работайте 3 недели в диапазоне 8–12 с RPE 7–8, затем вернитесь к тяжёлым 5×5. Альтернатива — смена вариации на 4 недели.`,
        priority: "high",
      });
    }
    if (imbalance.length) {
      recommendations.push({
        title: "Подтянуть отстающие группы",
        detail: `Добавьте 4–6 подходов в неделю на ${imbalance
          .slice(0, 2)
          .map((s) => s.split(" (")[0])
          .join(" и ")} в конец тренировки, не трогая основные движения.`,
        priority: "medium",
      });
    }
    if ((legs?.share ?? 0) < 18 && back && (back?.share ?? 0) < 18) {
      recommendations.push({
        title: "Добавить день ног или спины",
        detail: "Крупные мышечные группы требуют 10–20 подходов в неделю каждая. Разбейте текущий сплит на 4 дня: ноги / жим / тяга / верх+слабые места.",
        priority: "medium",
      });
    }
    recommendations.push({
      title: "Контроль интенсивности по RPE",
      detail: "Держите основные подходы в RPE 7–9 (1–3 повторения в запасе). Отказ нужен только в изоляции и не чаще одного подхода на упражнение.",
      priority: "medium",
    });
    if (kind === "training") {
      plan.push(
        `Следующая тренировка: ${t.progression[0]?.exercise ?? "базовое движение"} — 5×5 с весом ${Math.round(estimate1RM(t.progression[0]?.topWeight ?? 60, 5) * 0.82 / 2.5) * 2.5} кг.`,
        "Замерить пульс покоя и сон 3 дня подряд — при росте пульса на 5+ уд/мин сделать разгрузку.",
        "Добавить 2 подхода на самую отстающую группу в конце каждой тренировки этой недели.",
        "Через 7 дней пересчитать e1RM и зафиксировать новый рабочий вес.",
      );
    }
  }

  if (kind === "nutrition" || kind === "full") {
    const kcalRatio = target.calories ? n.avgCalories / target.calories : 1;
    const proteinOk = n.proteinPerKg >= 1.6 && n.proteinPerKg <= 2.4;
    const nutritionScore =
      35 * Math.max(0, 1 - Math.abs(1 - kcalRatio) * 2) +
      30 * (proteinOk ? 1 : 0.5) +
      20 * Math.min(1, n.loggedDays / Math.max(7, n.days * 0.7)) +
      15 * (n.fatSharePct >= 20 && n.fatSharePct <= 35 ? 1 : 0.5);
    score = kind === "nutrition" ? Math.round(nutritionScore) : Math.round((score + nutritionScore) / 2);

    highlights.push({
      title: `${n.avgCalories} ккал в среднем за день`,
      detail: `Цель ${target.calories} ккал (соответствие ${n.calorieAdherencePct}%). TDEE ≈ ${ctx.profile.tdee} ккал, BMR ≈ ${ctx.profile.bmr} ккал.`,
      tone: Math.abs(100 - n.calorieAdherencePct) <= 8 ? "good" : "warn",
    });
    highlights.push({
      title: `Белок ${n.proteinPerKg} г/кг`,
      detail: `${n.avgProtein} г при цели ${target.protein} г. ${proteinOk ? "Диапазон 1,6–2,2 г/кг оптимален для сохранения мышц." : "Целевой коридор 1,6–2,2 г/кг массы тела."}`,
      tone: proteinOk ? "good" : "warn",
    });

    const balance = Math.round(n.avgCalories - ctx.profile.tdee);
    insights.push({
      title: "Энергетический баланс",
      detail: `${balance > 0 ? "Профицит" : "Дефицит"} ≈ ${Math.abs(balance)} ккал/день относительно TDEE. ${
        goal === "cut"
          ? balance < -250 && balance > -700
            ? "Это рабочий дефицит для сушки: ожидаемо −0,3…0,6 кг в неделю."
            : balance >= -250
              ? "Дефицита практически нет — жир не будет уходить даже при идеальных тренировках."
              : "Дефицит слишком жёсткий: страдают силовые, гормоны и восстановление."
          : goal === "bulk"
            ? balance > 150 && balance < 500
              ? "Умеренный профицит — набор с минимумом жира."
              : balance <= 150
                ? "Для набора массы профицита не хватает, рост будет очень медленным."
                : "Профицит выше 500 ккал даст заметную прибавку жира."
            : Math.abs(balance) < 250
              ? "Калорийность около поддержки — условия для рекомпозиции тела созданы."
              : `Отклонение ${Math.abs(balance)} ккал от поддержки: цель «${GOAL_LABELS[goal]}» предполагает более ровный коридор.`
      }`,
    });
    insights.push({
      title: "Макронутриенты",
      detail: `Б ${n.avgProtein} г / Ж ${n.avgFat} г / У ${n.avgCarbs} г. Доля жиров ${n.fatSharePct}% от калорийности. ${
        n.fatSharePct < 20
          ? "Жиры ниже 20% — риск для гормональной системы, добавьте орехи, авокадо, оливковое масло."
          : n.fatSharePct > 38
            ? "Жиров многовато — часть калорий лучше перевести в углеводы вокруг тренировки."
            : "Доля жиров в норме (20–35%)."
      }`,
    });
    insights.push({
      title: "Дисциплина дневника",
      detail: `Заполнено ${n.loggedDays} из ${n.days} дней (${Math.round((n.loggedDays / n.days) * 100)}%). Дней ниже цели: ${n.daysUnderTarget}, выше цели: ${n.daysOverTarget}. ${
        n.loggedDays / n.days < 0.7
          ? "При нерегулярном учёте реальная калорийность обычно на 15–25% выше расчётной."
          : "Учёт достаточно регулярный, расчётам можно доверять."
      }`,
    });
    if (weightDelta !== null) {
      insights.push({
        title: "Связка «питание → вес»",
        detail: `Вес изменился на ${weightDelta > 0 ? "+" : ""}${weightDelta} кг, талия ${waistDelta !== null ? `${waistDelta > 0 ? "+" : ""}${waistDelta} см` : "без замеров"}. ${
          weightDelta < 0 && waistDelta !== null && waistDelta < 0
            ? "Уходит жир — стратегия работает."
            : weightDelta > 0 && waistDelta !== null && waistDelta > 0.5
              ? "Растёт и вес, и талия: профицит великоват, урежьте 150–200 ккал."
              : weightDelta < 0 && (n.proteinPerKg < 1.6)
                ? "Вес падает при низком белке — велик риск потери мышц."
                : "Динамика нейтральная, продолжайте наблюдение 2 недели."
        }`,
      });
    }

    recommendations.push({
      title: `Держать ${target.calories} ккал ± 150`,
      detail:
        goal === "cut"
          ? `Белок ${Math.round(ctx.profile.weight * 2.1)} г, жиры ${Math.round(ctx.profile.weight * 0.9)} г, остальное — углеводы. Дефицит создавайте едой, а не пропуском приёмов.`
          : goal === "bulk"
            ? `Белок ${Math.round(ctx.profile.weight * 1.9)} г, углеводы концентрируйте в окне вокруг тренировки.`
            : `Белок ${Math.round(ctx.profile.weight * 2)} г в день, калорийность на уровне поддержки.`,
      priority: "high",
    });
    if (!proteinOk) {
      recommendations.push({
        title: "Добрать белок",
        detail: `Не хватает ~${Math.max(0, Math.round(ctx.profile.weight * 1.8 - n.avgProtein))} г. Простые источники: 30 г сывороточного протеина (24 г белка), 200 г творога 5% (34 г), 150 г куриной грудки (45 г).`,
        priority: "high",
      });
    }
    recommendations.push({
      title: "Углеводы под тренировку",
        detail: `${Math.round(n.avgCarbs * 0.5)} г углеводов за 2 часа до сессии и столько же после — это даст качество подходов без изменения суточной калорийности.`,
      priority: "medium",
    });
    recommendations.push({
      title: "Правило 80/20",
      detail: "80% калорий из цельных продуктов, 20% — гибко. Так дневник ведётся месяцами, а не неделю.",
      priority: "low",
    });
    if (kind === "nutrition") {
      plan.push(
        `Завтрак: белок 35–40 г + сложные углеводы ${Math.round(target.carbs * 0.25)} г.`,
        `Обед: ${Math.round(target.protein * 0.3)} г белка, ${Math.round(target.carbs * 0.35)} г углеводов, овощи.`,
        `Ужин: ${Math.round(target.protein * 0.3)} г белка, минимум крахмалистых углеводов.`,
        "Взвешивать еду 5 дней подряд и сравнить факт с целью — обычно ошибка учёта 10–20%.",
      );
    }
  }

  if (kind === "body" || kind === "full") {
    const growing = b.changes.filter((c) => (c.delta ?? 0) > 0.3 && c.key !== "weightKg");
    const shrinking = b.changes.filter((c) => (c.delta ?? 0) < -0.3 && c.key !== "waist");
    const freshness = (b.daysSinceLast ?? 0) > 21 ? 0.6 : 1;
    const bodyScore =
      30 * (b.ratio && b.ratio > 1.55 ? 1 : b.ratio && b.ratio > 1.35 ? 0.82 : 0.55) +
      25 * (b.measurementCount >= 6 ? 1 : b.measurementCount >= 3 ? 0.7 : 0.35) +
      25 * ((waistDelta ?? 0) <= 0 ? 1 : 0.5) +
      20 * (growing.length >= 3 ? 1 : growing.length >= 1 ? 0.75 : 0.4);
    const adjustedBodyScore = bodyScore * freshness;
    score =
      kind === "body"
        ? Math.round(adjustedBodyScore)
        : Math.round((score + adjustedBodyScore) / 2);

    if (b.ratio) {
      highlights.push({
        title: `Индекс плечи/талия ${b.ratio}`,
        detail:
          b.ratio >= 1.6
            ? "Выраженная V-образная silhouette — пропорции на уровне атлетического стандарта."
            : b.ratio >= 1.4
              ? "Хорошая пропорция. Цель — 1,6 и выше за счёт дельт/широчайших и снижения талии."
              : "Пропорции пока нейтральные: приоритет — расширение плечевого пояса и уменьшение талии.",
        tone: b.ratio >= 1.5 ? "good" : "warn",
      });
    }
    if (b.changes.length) {
      const notable = [...b.changes].sort(
        (x, y) => Math.abs(y.delta ?? 0) - Math.abs(x.delta ?? 0),
      )[0];
      if (notable?.delta !== null && notable?.delta !== undefined) {
        highlights.push({
          title: `Самое заметное изменение: ${notable.label}`,
          detail: `${notable.first} → ${notable.latest} (${notable.delta > 0 ? "+" : ""}${notable.delta}) за ${b.measurementCount} замеров.`,
          tone: notable.key === "waist" ? (notable.delta < 0 ? "good" : "warn") : notable.delta > 0 ? "good" : "warn",
        });
      }
    }

    insights.push({
      title: "Признаки рекомпозиции",
      detail:
        weightDelta !== null && waistDelta !== null
          ? Math.abs(weightDelta) < 1 && waistDelta < -0.5
            ? `Вес почти не изменился (${weightDelta} кг), но талия −${Math.abs(waistDelta)} см при росте ${growing
                .slice(0, 3)
                .map((c) => c.label.toLowerCase())
                .join(", ") || "обхватов"} — классическая рекомпозиция: жир уходит, мышцы растут.`
            : weightDelta < -0.5 && waistDelta < -0.5
              ? "Идёт снижение массы за счёт жира — темп правильный."
              : weightDelta > 0.5 && waistDelta > 0.5
                ? "Растёт и вес, и талия — часть набранного приходится на жир."
                : "Изменения пока неоднозначны, нужно минимум 3 замера с интервалом 2 недели."
          : "Недостаточно данных для вывода о рекомпозиции — добавьте замеры веса и талии.",
    });
    if (growing.length) {
      insights.push({
        title: "Растущие объёмы",
        detail: growing
          .map((c) => `${c.label}: ${c.first} → ${c.latest} (+${c.delta} см)`)
          .join("; "),
      });
    }
    if (shrinking.length) {
      insights.push({
        title: "Уменьшающиеся объёмы",
        detail: `${shrinking.map((c) => `${c.label} −${Math.abs(c.delta ?? 0)} см`).join(", ")}. Если это руки/грудь на фоне дефицита — снизьте дефицит и добавьте белок.`,
      });
    }
    insights.push({
      title: "Качество замеров",
      detail:
        b.daysSinceLast !== null && b.daysSinceLast > 21
          ? `Последний замер ${b.daysSinceLast} дней назад. Обхваты меняются медленно — оптимум раз в 10–14 дней, утром, натощак, в одной и той же точке.`
          : `Замеров: ${b.measurementCount}. Частота достаточная для отслеживания тренда.`,
    });

    recommendations.push({
      title: "Протокол замеров",
      detail: "Раз в 14 дней, утром натощак: лента параллельно полу, без натяжения. Талия — по линии пупка, грудь — по нижней точке лопаток и соскам, бицепс — в напряжении, предплечье — в самой широкой точке.",
      priority: "high",
    });
    recommendations.push({
      title: "Фокус на талии",
      detail:
        (waistDelta ?? 0) > 0
          ? "Талия растёт — урежьте 200–300 ккал за счёт жидких калорий и добавьте 2×20 минут низкоинтенсивного кардио в неделю."
          : "Талия уменьшается — сохраняйте текущий режим, не увеличивайте дефицит.",
      priority: (waistDelta ?? 0) > 0 ? "high" : "medium",
    });
    recommendations.push({
      title: "Приоритет объёмов верха",
      detail: "Чтобы поднять соотношение плечи/талия: 12–16 подходов на среднюю дельту и широчайшие в неделю, прогрессия по повторениям.",
      priority: "medium",
    });
    if (kind === "body") {
      plan.push(
        "Сделать контрольный замер всех точек в ближайшие 48 часов.",
        "Сфотографировать прогресс в трёх ракурсах при одинаковом свете.",
        "Через 14 дней повторить замер и сверить дельты.",
        "Скорректировать калорийность по динамике талии и веса.",
      );
    }
  }

  if (kind === "full") {
    const netCalories = Math.round(n.avgCalories - ctx.profile.tdee);
    plan.push(
      `Неделя 1: ${Math.min(4, ctx.profile.profile?.workoutsPerWeek ?? 4)} тренировки, недельный объём ${Math.round((t.weeklyVolume || t.avgVolume * 3) / 100) * 100} кг, ${target.calories} ккал/день.`,
      `Неделя 2: +2,5 кг в основном движении или +1 повтор в каждом подходе, белок не ниже ${Math.round(ctx.profile.weight * 1.8)} г.`,
      `Неделя 3: пиковая нагрузка (+5% объёма), контроль RPE ≤ 9.`,
      `Неделя 4: разгрузка −40% объёма, контрольные обхваты и взвешивание.`,
      `Корректировка: если вес растёт быстрее 0,4 кг/нед при цели «${GOAL_LABELS[goal]}» — минус 150 ккал; если силовые падают при балансе ${netCalories} ккал — плюс 150 ккал.`,
    );
    insights.push({
      title: "Связка всех трёх блоков",
      detail: `Тренировочный объём ${t.volumeTrendPct > 0 ? "растёт" : "снижается"} (${t.volumeTrendPct}%), калорийность ${Math.round(n.avgCalories)} ккал при цели ${target.calories}, вес ${weightDelta !== null ? `${weightDelta > 0 ? "+" : ""}${weightDelta} кг` : "—"}, талия ${waistDelta !== null ? `${waistDelta > 0 ? "+" : ""}${waistDelta} см` : "—"}. ${
        t.volumeTrendPct > 0 && n.avgCalories >= target.calories * 0.95
          ? "Условия для прогресса совпадают — увеличивайте нагрузку постепенно."
          : t.volumeTrendPct > 0 && n.avgCalories < target.calories * 0.9
            ? "Объём растёт при недоборе калорий — типичный сценарий плато через 3–4 недели."
            : "Сначала стабилизируйте питание, затем наращивайте объём."
      }`,
    });
  }

  score = Math.max(5, Math.min(98, score || 60));

  return {
    summary:
      kind === "training"
        ? `За ${t.days} дней — ${t.workoutCount} тренировок (${t.workoutsPerWeek}/нед), суммарный объём ${t.totalVolume.toLocaleString("ru-RU")} кг в ${t.totalSets} рабочих подходах. Прогрессия силовых ${bestProgress ? `лучше всего в «${bestProgress.exercise}» (+${bestProgress.changePct}%)` : "не выражена"}, недельный объём ${t.volumeTrendPct > 0 ? "+" : ""}${t.volumeTrendPct}% к прошлой неделе.`
        : kind === "nutrition"
          ? `Средняя калорийность ${n.avgCalories} ккал при цели ${target.calories} ккал (TDEE ≈ ${ctx.profile.tdee}). Белок ${n.avgProtein} г (${n.proteinPerKg} г/кг), жиры ${n.avgFat} г, углеводы ${n.avgCarbs} г. Дневник заполнен ${n.loggedDays} из ${n.days} дней.`
          : kind === "body"
            ? `${b.measurementCount} замеров: вес ${weightDelta !== null ? `${weightDelta > 0 ? "+" : ""}${weightDelta} кг` : "—"}, талия ${waistDelta !== null ? `${waistDelta > 0 ? "+" : ""}${waistDelta} см` : "—"}, соотношение плечи/талия ${b.ratio ?? "—"}. ${b.changes.filter((c) => (c.delta ?? 0) > 0).length} точек выросли, ${b.changes.filter((c) => (c.delta ?? 0) < 0).length} уменьшились.`
            : `Комплексная картина: ${t.workoutCount} тренировок за ${t.days} дней с недельным объёмом ${Math.round(t.weeklyVolume).toLocaleString("ru-RU")} кг, питание ${n.avgCalories} ккал/день (цель ${target.calories}, белок ${n.proteinPerKg} г/кг), тело — вес ${weightDelta !== null ? `${weightDelta > 0 ? "+" : ""}${weightDelta} кг` : "—"} и талия ${waistDelta !== null ? `${waistDelta > 0 ? "+" : ""}${waistDelta} см` : "—"} за ${b.measurementCount} замеров.`,
    score,
    highlights,
    insights,
    recommendations,
    plan,
    provider: "Локальный эксперт",
    model: "expert-engine-v1",
    online: false,
  };
}

/* ------------------------------------------------------------------ */
/* Entry point                                                         */
/* ------------------------------------------------------------------ */

export async function generateAnalysis(kind: AnalysisKind, ctx?: CoachContext) {
  const context = ctx ?? (await buildContext());
  const prompt = buildPrompt(kind, ctx ?? context);
  const started = Date.now();
  const provider = detectProvider();

  const metrics = {
    workouts: context.training.workoutCount,
    weeklyVolume: context.training.weeklyVolume,
    volumeTrendPct: context.training.volumeTrendPct,
    avgCalories: context.nutrition.avgCalories,
    proteinPerKg: context.nutrition.proteinPerKg,
    targetCalories: context.profile.targets.calories,
    weight: context.profile.weight,
    measurements: context.body.measurementCount,
    shoulderWaistRatio: context.body.ratio,
    progressionCount: context.training.progression.length,
  };

  const dataSnapshot = {
    athlete: {
      goal: context.profile.profile?.goal,
      heightCm: context.profile.profile?.heightCm,
      weightKg: context.profile.weight,
      bmr: context.profile.bmr,
      tdee: context.profile.tdee,
      targets: context.profile.targets,
    },
    training: {
      workouts: context.training.workoutCount,
      perWeek: context.training.workoutsPerWeek,
      totalVolume: context.training.totalVolume,
      totalSets: context.training.totalSets,
      avgDuration: context.training.avgDuration,
      weeklySeries: context.training.weeklySeries.slice(-12),
      muscleSplit: context.training.muscleSplit,
      progression: context.training.progression.slice(0, 12).map((p) => ({
        exercise: p.exercise,
        sessions: p.sessions,
        changePct: p.changePct,
        trend: p.trend,
        stalled: p.stalled,
        last: p.lastValue,
      })),
      personalRecords: context.training.personalRecords.slice(0, 6),
    },
    nutrition: {
      loggedDays: context.nutrition.loggedDays,
      avgCalories: context.nutrition.avgCalories,
      avgProtein: context.nutrition.avgProtein,
      avgFat: context.nutrition.avgFat,
      avgCarbs: context.nutrition.avgCarbs,
      proteinPerKg: context.nutrition.proteinPerKg,
      adherence: context.nutrition.calorieAdherencePct,
    },
    body: {
      changes: context.body.changes,
      ratio: context.body.ratio,
      measurementCount: context.body.measurementCount,
    },
  };

  if (!provider) {
    const result = localExpert(kind, context);
    return {
      result: {
        ...result,
        error: null,
      },
      prompt,
      raw: null as string | null,
      metrics,
      dataSnapshot,
      durationMs: Date.now() - started,
    };
  }

  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 75_000);
    const raw = await callProvider(provider, prompt, controller.signal);
    clearTimeout(timer);
    const parsed = parseJsonBlock(raw);
    const result = normalizeAnalysis(parsed, provider);
    if (!result.highlights.length && !result.recommendations.length) {
      throw new Error("Модель вернула пустой JSON");
    }
    return {
      result,
      prompt,
      raw,
      metrics,
      dataSnapshot,
      durationMs: Date.now() - started,
    };
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    const fallback = localExpert(kind, context);
    return {
      result: {
        ...fallback,
        error: `Онлайн-модель недоступна (${message}). Использован локальный экспертный движок.`,
        provider: `Локальный эксперт (резерв после ${provider.name})`,
      },
      prompt,
      raw: null,
      metrics,
      dataSnapshot,
      durationMs: Date.now() - started,
    };
  }
}
