/* FORMA service worker — makes the app installable and keeps a light offline shell. */
const VERSION = "forma-v1";
const SHELL = `${VERSION}-shell`;
const RUNTIME = `${VERSION}-runtime`;
const SHELL_FILES = [
  "/",
  "/icons/icon-192.png",
  "/icons/icon-512.png",
  "/icons/icon-maskable-512.png",
  "/icons/apple-touch-icon.png",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches
      .open(SHELL)
      .then((cache) => cache.addAll(SHELL_FILES).catch(() => undefined))
      .then(() => self.skipWaiting()),
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(keys.filter((k) => !k.startsWith(VERSION)).map((k) => caches.delete(k))),
      )
      .then(() => self.clients.claim()),
  );
});

const OFFLINE_HTML = `<!doctype html><html lang="ru"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>FORMA — офлайн</title>
<style>html,body{height:100%;margin:0;background:#05060c;color:#f2f4ff;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;display:grid;place-items:center;text-align:center;padding:24px}
.card{max-width:340px;border-radius:28px;padding:28px;background:linear-gradient(150deg,rgba(255,255,255,.11),rgba(255,255,255,.04));border:1px solid rgba(255,255,255,.13);box-shadow:inset 0 1px 0 rgba(255,255,255,.25),0 24px 60px -30px #000}
h1{font-size:20px;margin:0 0 8px}p{color:#a7aecb;font-size:14px;line-height:1.5;margin:0 0 18px}
a{display:inline-block;padding:11px 20px;border-radius:999px;text-decoration:none;color:#0b0716;font-weight:600;background:linear-gradient(140deg,#a78bfa,#7c5cff 45%,#22d3ee)}</style>
</head><body><div class="card"><h1>Нет соединения</h1>
<p>FORMA не смогла загрузить данные. Проверьте интернет и попробуйте снова — все сохранённые записи останутся на сервере.</p>
<a href="/">Обновить</a></div></body></html>`;

self.addEventListener("fetch", (event) => {
  const request = event.request;
  if (request.method !== "GET") return;

  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;
  // Never cache API/data routes — the app must always show fresh numbers.
  if (url.pathname.startsWith("/api/")) return;

  // Navigations: network-first, cached shell as a fallback.
  if (request.mode === "navigate") {
    event.respondWith(
      fetch(request)
        .then((response) => {
          const copy = response.clone();
          caches.open(RUNTIME).then((cache) => cache.put(request, copy)).catch(() => undefined);
          return response;
        })
        .catch(async () => {
          const cached = (await caches.match(request)) || (await caches.match("/"));
          if (cached) return cached;
          return new Response(OFFLINE_HTML, {
            headers: { "content-type": "text/html; charset=utf-8" },
          });
        }),
    );
    return;
  }

  // Static assets: cache-first.
  const isStatic =
    url.pathname.startsWith("/_next/static/") ||
    url.pathname.startsWith("/icons/") ||
    /\.(?:png|jpg|jpeg|svg|webp|ico|woff2?|css|js)$/.test(url.pathname);

  if (!isStatic) return;

  event.respondWith(
    caches.match(request).then(
      (cached) =>
        cached ||
        fetch(request).then((response) => {
          if (response.ok) {
            const copy = response.clone();
            caches.open(RUNTIME).then((cache) => cache.put(request, copy)).catch(() => undefined);
          }
          return response;
        }),
    ),
  );
});
