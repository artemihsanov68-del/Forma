"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState, type ReactNode } from "react";
import {
  Activity,
  BookOpen,
  Dumbbell,
  LineChart,
  Ruler,
  Salad,
  Smartphone,
  Sparkles,
  Waves,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { api } from "@/lib/client";
import { InstallHint } from "@/components/Pwa";

const NAV = [
  { href: "/", label: "Обзор", icon: Waves, short: "Обзор" },
  { href: "/workouts", label: "Тренировки", icon: Dumbbell, short: "Тренировки" },
  { href: "/nutrition", label: "Питание", icon: Salad, short: "КБЖУ" },
  { href: "/body", label: "Тело", icon: Ruler, short: "Тело" },
  { href: "/progress", label: "Прогресс", icon: LineChart, short: "Прогресс" },
  { href: "/coach", label: "ИИ-тренер", icon: Sparkles, short: "ИИ" },
] as const;

interface ProfileLite {
  profile?: { name?: string; goal?: string } | null;
  weight?: number;
  ai?: { online: boolean; provider: string };
}

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const [profile, setProfile] = useState<ProfileLite | null>(null);

  useEffect(() => {
    api<ProfileLite>("/api/profile")
      .then(setProfile)
      .catch(() => setProfile({}));
  }, []);

  const isActive = (href: string) =>
    href === "/" ? pathname === "/" : pathname.startsWith(href);

  const dateLabel = new Date().toLocaleDateString("ru-RU", {
    weekday: "long",
    day: "numeric",
    month: "long",
  });

  return (
    <div className="mx-auto flex w-full max-w-[1400px] gap-6 px-3 pb-28 pt-3 sm:px-5 lg:px-7 lg:pb-10 lg:pt-6">
      {/* Sidebar (desktop) */}
      <aside className="sticky top-6 hidden h-[calc(100vh-3rem)] w-[248px] shrink-0 flex-col lg:flex">
        <div className="glass flex h-full flex-col rounded-[32px] p-5">
          <Link href="/" className="flex items-center gap-3">
            <span className="grid size-11 place-items-center rounded-2xl bg-gradient-to-br from-violet-glow to-cyan-glow text-[#0b0716] shadow-[0_10px_28px_-10px_rgba(124,92,255,0.9)]">
              <Activity className="size-6" strokeWidth={2.4} />
            </span>
            <span>
              <span className="block text-[17px] font-semibold leading-none tracking-tight text-white">
                FORMA
              </span>
              <span className="mt-1 block text-[11px] text-mist">трекер прогресса</span>
            </span>
          </Link>

          <nav className="mt-8 flex flex-col gap-1.5">
            {NAV.map((item) => {
              const Icon = item.icon;
              const active = isActive(item.href);
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "group relative flex items-center gap-3 rounded-2xl px-3.5 py-2.5 text-[13.5px] font-medium transition-all duration-300",
                    active
                      ? "tab-active-glow bg-gradient-to-b from-white/18 to-white/6 text-white"
                      : "text-mist hover:bg-white/6 hover:text-white/90",
                  )}
                >
                  <Icon
                    className={cn("size-[18px]", active ? "text-white" : "text-mist group-hover:text-violet-glow")}
                    strokeWidth={2.1}
                  />
                  {item.label}
                  {item.href === "/coach" && profile?.ai ? (
                    <span
                      className={cn(
                        "ml-auto size-1.5 rounded-full",
                        profile.ai.online ? "bg-lime-glow shadow-[0_0_10px_#a6f97c]" : "bg-cyan-glow/70",
                      )}
                      title={profile.ai.online ? "Онлайн-модель подключена" : "Локальный эксперт"}
                    />
                  ) : null}
                </Link>
              );
            })}
          </nav>

          <div className="mt-auto space-y-3">
            <div className="glass-inset rounded-2xl p-3.5">
              <p className="text-[11px] uppercase tracking-[0.07em] text-mist/70">Атлет</p>
              <p className="mt-1 text-[14px] font-semibold text-white">
                {profile?.profile?.name ?? "…"}
              </p>
              <p className="mt-0.5 text-[11.5px] text-mist">
                {profile?.weight ? `${profile.weight} кг` : "вес не указан"}
              </p>
            </div>
            <Link
              href="/install"
              className={cn(
                "flex items-center gap-2.5 rounded-2xl border border-violet-glow/25 bg-gradient-to-br from-violet-glow/18 to-cyan-glow/10 px-3.5 py-2.5 text-[12.5px] font-medium text-white transition-all duration-300 hover:border-violet-glow/45",
                isActive("/install") && "tab-active-glow",
              )}
            >
              <Smartphone className="size-4 text-[#cbb8ff]" />
              Установить на телефон
            </Link>
            <p className="px-1 text-[11px] leading-relaxed text-mist/60">
              {dateLabel.charAt(0).toUpperCase() + dateLabel.slice(1)}
            </p>
          </div>
        </div>
      </aside>

      {/* Main */}
      <main className="min-w-0 flex-1">
        {/* Mobile header */}
        <header className="mb-4 flex items-center justify-between gap-3 lg:hidden">
          <Link href="/" className="flex items-center gap-2.5">
            <span className="grid size-9 place-items-center rounded-xl bg-gradient-to-br from-violet-glow to-cyan-glow text-[#0b0716]">
              <Activity className="size-5" strokeWidth={2.5} />
            </span>
            <span className="text-[15px] font-semibold tracking-tight text-white">FORMA</span>
          </Link>
          <div className="flex items-center gap-2">
            <Link
              href="/install"
              title="Установить на телефон"
              className={cn(
                "glass-soft grid size-9 place-items-center rounded-full text-mist transition-colors hover:text-white",
                isActive("/install") && "text-white",
              )}
            >
              <Smartphone className="size-4" />
            </Link>
            <div className="glass-soft rounded-full px-3 py-1.5 text-[11.5px] text-mist capitalize">
              {dateLabel}
            </div>
          </div>
        </header>

        <InstallHint />

        <div className="pop-in" key={pathname}>
          {children}
        </div>
      </main>

      {/* Bottom tab bar (mobile / tablet) */}
      <nav className="fixed inset-x-0 bottom-0 z-40 flex justify-center px-3 pb-3 lg:hidden">
        <div className="glass flex w-full max-w-xl items-center justify-between gap-1 rounded-[26px] px-2 py-2">
          {NAV.map((item) => {
            const Icon = item.icon;
            const active = isActive(item.href);
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex flex-1 flex-col items-center gap-1 rounded-2xl px-1 py-2 transition-all duration-300",
                  active
                    ? "tab-active-glow bg-gradient-to-b from-white/18 to-white/6 text-white"
                    : "text-mist/85",
                )}
              >
                <Icon className="size-[19px]" strokeWidth={2.1} />
                <span className="text-[10px] font-medium">{item.short}</span>
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
