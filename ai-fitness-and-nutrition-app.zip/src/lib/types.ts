/** Client-safe mirror of the server DTO shapes (no `pg`/drizzle imports). */

export interface SetDTO {
  id: number;
  setNumber: number;
  weightKg: number;
  reps: number;
  rpe: number | null;
  durationSeconds: number | null;
  distanceKm: number | null;
  isWarmup: boolean;
}

export interface ExerciseDTO {
  id: number;
  exerciseName: string;
  muscleGroup: string;
  sortOrder: number;
  exerciseId: number | null;
  sets: SetDTO[];
  volume: number;
  bestE1rm: number;
}

export interface WorkoutDTO {
  id: number;
  date: string;
  title: string;
  focus: string | null;
  durationMinutes: number | null;
  notes: string | null;
  feeling: number | null;
  totalVolume: number;
  totalSets: number;
  exercises: ExerciseDTO[];
}

export interface ProgressionHistoryPoint {
  date: string;
  e1rm: number;
  topWeight: number;
  reps: number;
  volume: number;
  seconds: number;
}

export interface ProgressionEntry {
  exercise: string;
  muscleGroup: string;
  sessions: number;
  firstValue: number;
  lastValue: number;
  changePct: number;
  topWeight: number;
  trend: "up" | "down" | "flat";
  stalled: boolean;
  unit: "kg" | "sec";
  history: ProgressionHistoryPoint[];
}

export interface TrainingSummary {
  days: number;
  workoutCount: number;
  workoutsPerWeek: number;
  totalVolume: number;
  avgVolume: number;
  totalSets: number;
  avgSetsPerWorkout: number;
  avgDuration: number;
  avgFeeling: number;
  weeklyVolume: number;
  prevWeeklyVolume: number;
  volumeTrendPct: number;
  daysSinceLastWorkout: number | null;
  muscleSplit: Array<{ group: string; sets: number; volume: number; share: number }>;
  weeklySeries: Array<{ week: string; volume: number; sets: number; workouts: number }>;
  progression: ProgressionEntry[];
  personalRecords: Array<{ exercise: string; e1rm: number; weightKg: number; reps: number; date: string }>;
  lastWorkout?: { date: string; title: string; volume: number; sets: number };
}

export interface NutritionSummary {
  days: number;
  loggedDays: number;
  avgCalories: number;
  avgProtein: number;
  avgFat: number;
  avgCarbs: number;
  proteinPerKg: number;
  fatSharePct: number;
  targetCalories: number;
  targetProtein: number;
  calorieAdherencePct: number;
  proteinAdherencePct: number;
  daysUnderTarget: number;
  daysOverTarget: number;
  weeklyDeltaKcal: number;
  weight: number;
  dailySeries: Array<{ date: string; kcal: number; protein: number; fat: number; carbs: number }>;
  todayTotal: { kcal: number; protein: number; fat: number; carbs: number };
}

export interface BodyChange {
  key: string;
  label: string;
  latest: number | null;
  first: number | null;
  delta: number | null;
}

export interface BodySummary {
  latest?: Record<string, number | string | null>;
  series: Array<Record<string, string | number | null>>;
  changes: BodyChange[];
  ratio: number | null;
  measurementCount: number;
  daysSinceLast: number | null;
  bodyFatDelta: number | null;
}

export interface ProfileData {
  profile: {
    id: number;
    name: string;
    sex: string;
    birthDate: string | null;
    heightCm: number;
    weightKg: number;
    activityLevel: string;
    goal: string;
    targetCalories: number;
    targetProtein: number;
    targetFat: number;
    targetCarbs: number;
    workoutsPerWeek: number;
    notes: string | null;
  } | null;
  weight: number;
  age: number;
  bmr: number;
  tdee: number;
  targets: {
    calories: number;
    protein: number;
    fat: number;
    carbs: number;
    suggested: { calories: number; protein: number; fat: number; carbs: number };
  };
  ai?: { online: boolean; provider: string; model: string };
}

export interface AnalyticsResponse {
  training: TrainingSummary;
  nutrition: NutritionSummary;
  body: BodySummary;
  profile: ProfileData;
}

export interface NutritionEntryDTO {
  id: number;
  date: string;
  meal: string;
  name: string;
  grams: number;
  kcal: number;
  protein: number;
  fat: number;
  carbs: number;
}

export interface MeasurementDTO {
  id: number;
  date: string;
  weightKg: number | null;
  bodyFat: number | null;
  neck: number | null;
  chest: number | null;
  shoulders: number | null;
  waist: number | null;
  hips: number | null;
  glutes: number | null;
  thigh: number | null;
  biceps: number | null;
  forearm: number | null;
  calf: number | null;
  notes: string | null;
}

export interface AnalysisDTO {
  id: number;
  kind: string;
  title: string;
  periodLabel: string;
  summary: string;
  score: number | null;
  online: boolean;
  provider: string;
  model: string;
  error: string | null;
  createdAt: string;
  highlights?: Array<{ title: string; detail: string; tone?: string }>;
  insights?: Array<{ title: string; detail: string }>;
  recommendations?: Array<{ title: string; detail: string; priority?: string }>;
  plan?: string[];
  metrics?: Record<string, number | string | null>;
  dataSnapshot?: Record<string, unknown>;
  prompt?: string | null;
  rawResponse?: string | null;
  durationMs?: number | null;
}

export interface FoodDTO {
  id: number;
  name: string;
  brand: string | null;
  category: string;
  kcal: number;
  protein: number;
  fat: number;
  carbs: number;
  perGrams: number;
}

export interface ExerciseCatalogItem {
  id: number;
  name: string;
  muscleGroup: string;
  equipment: string;
  kind: string;
  isCustom: boolean;
}
