"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { CheckCircle2, Copy, Download, Smartphone, X } from "lucide-react";
import { Btn } from "@/components/ui";
import { cn } from "@/lib/utils";

export interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed"; platform: string }>;
}

declare global {
  interface Window {
    __formaPrompt?: BeforeInstallPromptEvent | null;
    __formaInstalled?: boolean;
  }
  interface Navigator {
    standalone?: boolean;
  }
}

export function isStandalone() {
  if (typeof window === "undefined") return false;
  return (
    window.matchMedia("(display-mode: standalone)").matches ||
    window.matchMedia("(display-mode: fullscreen)").matches ||
    window.navigator.standalone === true ||
    window.location.search.includes("source=pwa")
  );
}

export type Platform = "ios" | "android" | "desktop";

export interface EnvInfo {
  platform: Platform;
  /** Safari, Chrome, Chrome iOS, Telegram, Instagram… */
  browser: string;
  inApp: boolean;
  /** iOS: only Safari can add to the Home Screen. */
  safari: boolean;
}

/** Client-only UA sniffing used to show the right install instructions. */
export function detectEnv(): EnvInfo {
  if (typeof navigator === "undefined") {
    return { platform: "desktop", browser: "Браузер", inApp: false, safari: false };
  }
  const ua = navigator.userAgent;
  const isIPad = /iPad/.test(ua) || (navigator.maxTouchPoints > 1 && /Macintosh/.test(ua));
  const ios = /iPhone|iPod/.test(ua) || isIPad;
  const android = /Android/.test(ua);
  const platform: Platform = ios ? "ios" : android ? "android" : "desktop";

  const inAppPatterns: Array<[RegExp, string]> = [
    [/Telegram/i, "Telegram"],
    [/Instagram/i, "Instagram"],
    [/VKClient|VKAndroidApp|vkShare/i, "ВКонтакте"],
    [/WhatsApp/i, "WhatsApp"],
    [/FBAN|FBAV|FB_IAB/i, "Facebook"],
    [/Snapchat/i, "Snapchat"],
    [/Line\//i, "LINE"],
    [/MicroMessenger/i, "WeChat"],
    [/Twitter/i, "X"],
  ];
  const inAppMatch = inAppPatterns.find(([re]) => re.test(ua));

  let browser = "браузере";
  if (/CriOS/.test(ua)) browser = "Chrome (iOS)";
  else if (/FxiOS/.test(ua)) browser = "Firefox (iOS)";
  else if (/EdgiOS/.test(ua)) browser = "Edge (iOS)";
  else if (/OPiOS/.test(ua)) browser = "Opera (iOS)";
  else if (inAppMatch) browser = inAppMatch[1];
  else if (/SamsungBrowser/.test(ua)) browser = "Samsung Internet";
  else if (/YaBrowser/.test(ua)) browser = "Яндекс.Браузере";
  else if (/Chrome/.test(ua) && !ios) browser = "Chrome";
  else if (/Safari/.test(ua)) browser = "Safari";

  const safari = ios && /Safari/.test(ua) && !/CriOS|FxiOS|EdgiOS|OPiOS/.test(ua) && !inAppMatch;

  return { platform, browser, inApp: Boolean(inAppMatch), safari };
}

/** iOS install hint that stays out of the way once dismissed on this device. */
export function InstallHint() {
  const [env, setEnv] = useState<EnvInfo | null>(null);
  const [visible, setVisible] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const info = detectEnv();
    setEnv(info);
    if (isStandalone()) return;
    const dismissedAt = Number(window.localStorage.getItem("forma-install-hint") ?? 0);
    if (Date.now() - dismissedAt < 7 * 86_400_000) return;
    const t = setTimeout(() => setVisible(true), 900);
    return () => clearTimeout(t);
  }, []);

  if (!visible || !env) return null;

  const needsSafari = env.platform === "ios" && !env.safari;

  async function copy() {
    try {
      await navigator.clipboard.writeText(window.location.origin);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(false);
    }
  }

  return (
    <div className="glass pop-in mb-4 rounded-[24px] p-3.5 lg:hidden">
      <div className="flex items-start gap-3">
        <span className="grid size-9 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-violet-glow to-cyan-glow text-[#0b0716]">
          <Smartphone className="size-[18px]" strokeWidth={2.3} />
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-[12.5px] font-semibold leading-snug text-white">
            {needsSafari
              ? `Откройте FORMA в Safari — иначе установка недоступна`
              : env.platform === "ios"
                ? "Добавьте FORMA на экран «Домой»"
                : "Установите FORMA как приложение"}
          </p>
          <p className="mt-1 text-[11.5px] leading-relaxed text-mist">
            {needsSafari
              ? `Вы сейчас в ${env.browser}. Скопируйте ссылку и вставьте её в Safari, либо откройте инструкцию.`
              : env.platform === "ios"
                ? "Поделиться → «На экран «Домой»» → «Добавить». Запуск на весь экран, иконка на рабочем столе."
                : "Меню ⋮ → «Установить приложение». Иконка на рабочем столе, запуск без адресной строки."}
          </p>
          <div className="mt-2.5 flex flex-wrap gap-2">
            <Link href="/install">
              <Btn size="sm" variant="primary">
                Инструкция
              </Btn>
            </Link>
            <Btn size="sm" variant="subtle" onClick={() => void copy()}>
              {copied ? <CheckCircle2 className="size-3.5 text-lime-glow" /> : <Copy className="size-3.5" />}
              {copied ? "Скопировано" : "Ссылка"}
            </Btn>
          </div>
        </div>
        <button
          type="button"
          aria-label="Скрыть"
          onClick={() => {
            window.localStorage.setItem("forma-install-hint", String(Date.now()));
            setVisible(false);
          }}
          className="grid size-7 shrink-0 place-items-center rounded-full text-mist/70 transition-colors hover:bg-white/8 hover:text-white"
        >
          <X className="size-3.5" />
        </button>
      </div>
    </div>
  );
}

/** Registers the service worker so Android offers a real "Установить приложение". */
export function PwaProvider() {
  useEffect(() => {
    if (typeof window === "undefined") return;
    if (!("serviceWorker" in navigator)) return;
    if (process.env.NODE_ENV !== "production") return;

    const register = () => {
      navigator.serviceWorker.register("/sw.js").catch(() => undefined);
    };
    if (document.readyState === "complete") register();
    else window.addEventListener("load", register, { once: true });
  }, []);

  return null;
}

export type InstallState = "loading" | "installed" | "ready" | "manual";

export function useInstallState() {
  const [state, setState] = useState<InstallState>("loading");

  useEffect(() => {
    if (isStandalone()) {
      setState("installed");
      return;
    }
    const sync = () => setState(window.__formaPrompt ? "ready" : "manual");
    sync();
    window.addEventListener("forma-installable", sync);
    window.addEventListener("forma-installed", () => setState("installed"));
    return () => {
      window.removeEventListener("forma-installable", sync);
    };
  }, []);

  return state;
}

export async function triggerInstall() {
  const prompt = window.__formaPrompt;
  if (!prompt) return "unavailable" as const;
  await prompt.prompt();
  const choice = await prompt.userChoice;
  window.__formaPrompt = null;
  return choice.outcome;
}

export function InstallButton({
  className,
  size = "lg",
  variant = "primary",
  label,
  showManualIcon = true,
}: {
  className?: string;
  size?: "sm" | "md" | "lg";
  variant?: "primary" | "ghost";
  label?: string;
  showManualIcon?: boolean;
}) {
  const state = useInstallState();
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [env, setEnv] = useState<EnvInfo | null>(null);

  useEffect(() => {
    setEnv(detectEnv());
  }, []);

  const actionLabel =
    label ??
    (env?.platform === "ios"
      ? "Добавить на экран «Домой»"
      : env?.platform === "android"
        ? "Установить приложение"
        : "Установить как приложение");

  if (state === "installed") {
    return (
      <span
        className={cn(
          "inline-flex items-center gap-2 rounded-full border border-lime-glow/30 bg-lime-glow/12 px-4 py-2.5 text-[13px] font-semibold text-lime-glow",
          className,
        )}
      >
        <CheckCircle2 className="size-4" /> Приложение установлено
      </span>
    );
  }

  return (
    <Btn
      variant={variant}
      size={size}
      className={className}
      disabled={busy || state === "loading"}
      onClick={async () => {
        if (state === "ready") {
          setBusy(true);
          try {
            await triggerInstall();
          } finally {
            setBusy(false);
          }
          return;
        }
        router.push("/install");
      }}
    >
      {state === "ready" ? <Download className="size-4" /> : showManualIcon ? <Smartphone className="size-4" /> : null}
      {state === "loading" ? "Проверяем…" : state === "ready" ? "Установить приложение" : actionLabel}
    </Btn>
  );
}
