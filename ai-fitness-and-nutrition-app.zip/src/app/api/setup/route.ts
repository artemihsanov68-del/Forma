import { NextResponse } from "next/server";
import { ensureSeeded } from "@/db/seed";
import { checkDatabase, createTables } from "@/lib/db-init";

export const dynamic = "force-dynamic";

export async function GET() {
  const status = await checkDatabase();
  return NextResponse.json(status);
}

/** Creates the tables (if needed) and seeds the catalog + demo history. */
export async function POST() {
  const before = await checkDatabase();
  if (!before.connected) {
    return NextResponse.json(
      { ok: false, error: before.error ?? "Нет подключения к базе данных" },
      { status: 500 },
    );
  }

  try {
    await createTables();
    await ensureSeeded();
    const after = await checkDatabase();
    return NextResponse.json({
      ok: true,
      created: before.missing,
      status: after,
      message: after.ready
        ? "Таблицы созданы, каталоги и демо-история загружены"
        : "Не удалось создать все таблицы",
    });
  } catch (err) {
    return NextResponse.json(
      { ok: false, error: err instanceof Error ? err.message : String(err) },
      { status: 500 },
    );
  }
}
