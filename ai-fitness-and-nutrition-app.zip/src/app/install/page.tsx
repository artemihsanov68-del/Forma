"use client";

import Image from "next/image";
import Link from "next/link";
import { useEffect, useState } from "react";
import {
  ArrowUp,
  BookOpen,
  CheckCircle2,
  Copy,
  Download,
  ExternalLink,
  Info,
  MonitorSmartphone,
  Package,
  Plus,
  QrCode,
  Compass,
  Share,
  Smartphone,
  Terminal,
  TriangleAlert,
} from "lucide-react";
import { Btn, Card, Chip, SectionHeading, Segmented, Stat } from "@/components/ui";
import {
  InstallButton,
  detectEnv,
  isStandalone,
  useInstallState,
  type EnvInfo,
} from "@/components/Pwa";
import { cn } from "@/lib/utils";

type Platform = "android" | "ios";

const ANDROID_STEPS = [
  {
    title: "Откройте FORMA в Chrome",
    detail:
      "Скопируйте ссылку на приложение и вставьте её в адресную строку Google Chrome. Важно: установка не работает из встроенных браузеров Telegram, Instagram или VK.",
  },
  {
    title: "Нажмите меню ⋮ справа сверху",
    detail:
      "В списке выберите «Установить приложение» (в старых версиях Chrome — «Добавить на главный экран»).",
  },
  {
    title: "Подтвердите установку",
    detail:
      "Chrome может предложить создать ярлык и показывать уведомления. Нажмите «Установить» — иконка FORMA появится на рабочем столе и в списке приложений.",
  },
  {
    title: "Запускайте как обычное приложение",
    detail:
      "Открывается на весь экран без адресной строки, работает офлайн-оболочка, а быстрые действия по долгому нажатию на иконку ведут сразу к тренировке, питанию и ИИ-разбору.",
  },
];

const IOS_STEPS = [
  {
    title: "Откройте ссылку именно в Safari",
    detail:
      "На iPhone и iPad добавить сайт на экран «Домой» умеет только Safari. Chrome, Firefox, Edge и встроенные браузеры мессенджеров этого не умеют — приложение не появится.",
  },
  {
    title: "Нажмите «Поделиться»",
    detail:
      "Это кнопка со стрелкой вверх в нижней панели Safari. На iPad она находится в верхней панели рядом с адресной строкой.",
  },
  {
    title: "Выберите «На экран «Домой»»",
    detail:
      "Прокрутите список действий вниз. Если пункта нет — нажмите «Изменить действия» в самом низу и включите его.",
  },
  {
    title: "Нажмите «Добавить»",
    detail:
      "Иконка FORMA появится на рабочем столе. Название можно изменить, но мы рекомендуем оставить «FORMA».",
  },
];

export default function InstallPage() {
  const [platform, setPlatform] = useState<Platform>("android");
  const [env, setEnv] = useState<EnvInfo | null>(null);
  const [origin, setOrigin] = useState("");
  const [qr, setQr] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const state = useInstallState();
  const [standalone, setStandalone] = useState(false);

  useEffect(() => {
    setStandalone(isStandalone());
    const url = window.location.origin;
    setOrigin(url);
    const info = detectEnv();
    setEnv(info);
    setPlatform(info.platform === "ios" ? "ios" : "android");

    import("qrcode")
      .then((QR) =>
        QR.toDataURL(url, {
          margin: 1,
          width: 320,
          errorCorrectionLevel: "M",
          color: { dark: "#0b0716ff", light: "#ffffffff" },
        }),
      )
      .then(setQr)
      .catch(() => setQr(null));
  }, []);

  const isTemporary = /e2b\.app$|localhost|127\.0\.0\.1/.test(origin);

  async function copyLink() {
    try {
      await navigator.clipboard.writeText(origin);
      setCopied(true);
      setTimeout(() => setCopied(false), 2200);
    } catch {
      setCopied(false);
    }
  }

  const wrongBrowser = env?.platform === "ios" && !env.safari;
  const steps = platform === "android" ? ANDROID_STEPS : IOS_STEPS;

  return (
    <div className="space-y-5">
      <Card className="overflow-hidden p-5 sm:p-7">
        <div className="flex flex-col gap-6 lg:flex-row lg:items-center">
          <div className="flex items-center gap-4">
            <span className="glass-soft grid size-[76px] shrink-0 place-items-center overflow-hidden rounded-[22px]">
              <Image
                src="/icons/icon-192.png"
                alt="FORMA"
                width={76}
                height={76}
                className="size-full object-cover"
              />
            </span>
            <div>
              <p className="text-[11px] uppercase tracking-[0.08em] text-mist/80">Установка приложения</p>
              <h1 className="gradient-text mt-1 text-[26px] font-semibold leading-tight tracking-tight sm:text-[32px]">
                FORMA на {platform === "ios" ? "iPhone" : "Android"}
              </h1>
              <p className="mt-1 text-[12.5px] text-mist">
                Без App Store · 2 МБ · всегда актуальная версия
              </p>
            </div>
          </div>

          <div className="flex flex-1 flex-wrap items-center gap-2 lg:justify-end">
            <span
              className={cn(
                "inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-[11.5px] font-medium",
                standalone || state === "installed"
                  ? "border-lime-glow/30 bg-lime-glow/12 text-lime-glow"
                  : state === "ready"
                    ? "border-cyan-glow/30 bg-cyan-glow/12 text-cyan-glow"
                    : "border-white/10 bg-white/[0.04] text-mist",
              )}
            >
              {standalone || state === "installed" ? (
                <>
                  <CheckCircle2 className="size-3.5" /> Уже установлено
                </>
              ) : state === "ready" ? (
                <>
                  <Download className="size-3.5" /> Готово к установке
                </>
              ) : (
                <>
                  <Smartphone className="size-3.5" />
                  {wrongBrowser ? "Откройте в Safari" : "Откройте на телефоне"}
                </>
              )}
            </span>
            <InstallButton />
          </div>
        </div>

        <div className="mt-6 grid gap-3 sm:grid-cols-3">
          <Stat label="Тип установки" value="PWA" delta="работает как нативное" />
          <Stat label="Обновления" value="Авто" delta="всегда последняя версия" />
          <Stat label="Данные" value="В облаке" delta="тренировки и ИИ-разборы сохранены" />
        </div>
      </Card>

      {wrongBrowser ? (
        <Card className="border-amber-glow/30 p-4">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
            <div className="flex flex-1 items-start gap-3">
              <TriangleAlert className="mt-0.5 size-4 shrink-0 text-amber-glow" />
              <p className="text-[12.5px] leading-relaxed text-amber-glow/90">
                Вы открыли страницу в {env?.browser}. На iPhone установка возможна только из Safari:
                скопируйте ссылку, откройте Safari и вставьте её в адресную строку.
              </p>
            </div>
            <div className="flex shrink-0 gap-2">
              <Btn size="sm" variant="primary" onClick={() => void copyLink()}>
                {copied ? <CheckCircle2 className="size-3.5" /> : <Copy className="size-3.5" />}
                {copied ? "Скопировано" : "Скопировать ссылку"}
              </Btn>
              {origin ? (
                <a href={`x-safari-${origin}`} className="btn-glass px-3 py-1.5 text-[12.5px]">
                  <Compass className="size-3.5" /> Открыть в Safari
                </a>
              ) : null}
            </div>
          </div>
        </Card>
      ) : null}

      <div className="grid gap-4 xl:grid-cols-[1fr_340px]">
        <Card className="p-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <SectionHeading
              title={platform === "ios" ? "Установка на iPhone в 4 шага" : "Установка в 4 шага"}
              subtitle={
                platform === "ios"
                  ? "Safari → Поделиться → На экран «Домой»"
                  : "Chrome на Android — самый простой способ"
              }
              icon={<Smartphone className="size-5" />}
            />
            <Segmented
              value={platform}
              onChange={setPlatform}
              options={[
                { value: "android", label: "Android" },
                { value: "ios", label: "iPhone" },
              ]}
              className="w-[210px]"
            />
          </div>

          <div className="mt-5 space-y-2.5">
            {steps.map((s, i) => (
              <div key={s.title} className="glass-inset flex items-start gap-3 rounded-2xl px-4 py-3.5">
                <span className="grid size-7 shrink-0 place-items-center rounded-full bg-gradient-to-br from-violet-glow to-cyan-glow text-[12px] font-semibold text-[#0b0716]">
                  {i + 1}
                </span>
                <div>
                  <p className="text-[13.5px] font-semibold text-white">{s.title}</p>
                  <p className="mt-1 text-[12.5px] leading-relaxed text-mist">{s.detail}</p>
                </div>
              </div>
            ))}
          </div>

          {platform === "ios" ? (
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              <div className="glass-soft rounded-2xl p-4">
                <div className="flex items-center gap-2">
                  <Share className="size-4 text-cyan-glow" />
                  <p className="text-[13px] font-semibold text-white">Где кнопка «Поделиться»</p>
                </div>
                <div className="mt-3 rounded-2xl border border-white/10 bg-black/35 p-3">
                  <div className="flex items-center gap-2 text-[11px] text-mist">
                    <span className="text-mist/60">‹</span>
                    <span className="flex-1 truncate rounded-lg bg-white/8 px-2 py-1">forma.app</span>
                    <span className="text-mist/60">⟳</span>
                  </div>
                  <div className="mt-2.5 flex items-center justify-between px-1 text-[10px] text-mist/70">
                    <span>‹</span>
                    <span>›</span>
                    <span className="flex flex-col items-center gap-0.5 text-cyan-glow">
                      <span className="grid size-7 place-items-center rounded-md border border-cyan-glow/50 bg-cyan-glow/12">
                        <ArrowUp className="size-3.5" />
                      </span>
                      Поделиться
                    </span>
                    <span>❐</span>
                    <span>▢</span>
                  </div>
                </div>
                <p className="mt-2 text-[11.5px] leading-relaxed text-mist/85">
                  Квадрат со стрелкой вверх по центру нижней панели Safari.
                </p>
              </div>
              <div className="glass-soft rounded-2xl p-4">
                <div className="flex items-center gap-2">
                  <Plus className="size-4 text-violet-glow" />
                  <p className="text-[13px] font-semibold text-white">Что появится на экране</p>
                </div>
                <ul className="mt-2.5 space-y-1.5 text-[12px] leading-relaxed text-mist">
                  <li>• Иконка FORMA рядом с другими приложениями.</li>
                  <li>• Запуск без адресной строки Safari — как отдельное приложение.</li>
                  <li>• Своя сессия: данные подтягиваются с сервера.</li>
                  <li>• Офлайн-заглушка, если пропал интернет.</li>
                </ul>
                <p className="mt-2 text-[11.5px] leading-relaxed text-mist/80">
                  Быстрых действий по долгому нажатию на iOS нет — это ограничение системы, а на Android они
                  работают.
                </p>
              </div>
            </div>
          ) : (
            <div className="mt-4 glass-soft rounded-2xl p-4">
              <div className="flex items-center gap-2">
                <Download className="size-4 text-cyan-glow" />
                <p className="text-[13px] font-semibold text-white">Кнопка установки не появилась?</p>
              </div>
              <ul className="mt-2 space-y-1.5 text-[12.5px] leading-relaxed text-mist">
                <li>• Убедитесь, что вы в Chrome, а не в браузере внутри Telegram.</li>
                <li>• Откройте меню ⋮ → «Добавить на главный экран» — результат тот же.</li>
                <li>• Samsung Internet: меню → «Добавить страницу на главный экран».</li>
                <li>• Сайт должен открываться по HTTPS и не в приватном режиме.</li>
                <li>• Пункт меню иногда скрыт, пока страница не прогрета — прокрутите её и обновите.</li>
              </ul>
            </div>
          )}

          {platform === "ios" ? (
            <div className="mt-3 flex items-start gap-2.5 rounded-2xl border border-cyan-glow/25 bg-cyan-glow/8 px-4 py-3">
              <Info className="mt-0.5 size-4 shrink-0 text-cyan-glow" />
              <p className="text-[12px] leading-relaxed text-cyan-glow/90">
                Уведомления на iPhone работают только на iOS 16.4+ и только после добавления на экран
                «Домой». Полноценный APK-вариант — это история Android; на iOS аналога Trusted Web Activity
                нет, но PWA ведёт себя как обычное приложение.
              </p>
            </div>
          ) : null}
        </Card>

        <div className="space-y-4">
          <Card className="p-5">
            <SectionHeading
              title="Открыть на телефоне"
              subtitle="Наведите камеру"
              icon={<QrCode className="size-5" />}
            />
            <div className="mt-4 grid place-items-center">
              <div className="rounded-3xl bg-white p-3 shadow-[0_20px_50px_-24px_rgba(124,92,255,0.8)]">
                {qr ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src={qr}
                    alt="QR-код приложения FORMA"
                    width={188}
                    height={188}
                    className="size-[188px]"
                  />
                ) : (
                  <div className="shimmer size-[188px] rounded-2xl" />
                )}
              </div>
            </div>
            <p className="mt-3 break-all rounded-xl bg-white/[0.04] px-3 py-2 text-center text-[11.5px] text-mist">
              {origin || "…"}
            </p>
            <Btn className="mt-3 w-full" onClick={() => void copyLink()}>
              {copied ? <CheckCircle2 className="size-4 text-lime-glow" /> : <Copy className="size-4" />}
              {copied ? "Ссылка скопирована" : "Скопировать ссылку"}
            </Btn>
            <p className="mt-3 text-[11.5px] leading-relaxed text-mist/80">
              Отправьте ссылку себе в мессенджер и откройте её на телефоне: на Android — в Chrome, на
              iPhone — в Safari.
            </p>
          </Card>

          <Card className="p-5">
            <SectionHeading
              title="Что вы получаете"
              subtitle="После установки"
              icon={<MonitorSmartphone className="size-5" />}
            />
            <ul className="mt-3 space-y-2 text-[12.5px] leading-relaxed text-mist">
              {[
                "Иконка на рабочем столе и в меню приложений",
                "Запуск на весь экран без адресной строки",
                "Офлайн-оболочка при плохом интернете",
                "Автообновления без магазинов приложений",
                "Данные и ИИ-разборы хранятся на сервере",
                platform === "ios" ? "Скрытие интерфейса Safari как у нативного приложения" : "Быстрые действия на иконке: тренировка, еда, замер, ИИ",
              ].map((t) => (
                <li key={t} className="flex items-start gap-2">
                  <CheckCircle2 className="mt-0.5 size-3.5 shrink-0 text-lime-glow" />
                  {t}
                </li>
              ))}
            </ul>
          </Card>
        </div>
      </div>

      <Card className="p-5">
        <SectionHeading
          title={platform === "ios" ? "Чем iOS отличается от Android" : "Нужен именно APK-файл?"}
          subtitle={
            platform === "ios"
              ? "Ограничения Safari и что с ними делать"
              : "Вариант с установкой из файла — через Trusted Web Activity"
          }
          icon={platform === "ios" ? <Compass className="size-5" /> : <Package className="size-5" />}
        />
        {platform === "ios" ? (
          <div className="mt-4 grid gap-3 lg:grid-cols-2">
            <div className="glass-inset rounded-2xl p-4">
              <p className="text-[13px] font-semibold text-white">Только Safari</p>
              <p className="mt-1.5 text-[12.5px] leading-relaxed text-mist">
                Apple не даёт другим браузерам и веб-вью добавлять приложения на экран «Домой». Если
                ссылка открыта в Telegram, Chrome или Instagram — скопируйте её и откройте в Safari.
              </p>
            </div>
            <div className="glass-inset rounded-2xl p-4">
              <p className="text-[13px] font-semibold text-white">Хранение данных</p>
              <p className="mt-1.5 text-[12.5px] leading-relaxed text-mist">
                Записи хранятся на сервере, поэтому очистка Safari или переустановка приложения не удалит
                тренировки и разборы. Кэш приложения локальный и небольшой.
              </p>
            </div>
            <div className="glass-inset rounded-2xl p-4">
              <p className="text-[13px] font-semibold text-white">Обновления</p>
              <p className="mt-1.5 text-[12.5px] leading-relaxed text-mist">
                iOS обновляет PWA при запуске. Если видите старую версию — закройте приложение из
                переключателя задач и откройте снова.
              </p>
            </div>
            <div className="glass-inset rounded-2xl p-4">
              <p className="text-[13px] font-semibold text-white">Уведомления</p>
              <p className="mt-1.5 text-[12.5px] leading-relaxed text-mist">
                С iOS 16.4 веб-приложения могут присылать пуши, но только после добавления на экран
                «Домой» и явного разрешения. На Android это работает сразу.
              </p>
            </div>
          </div>
        ) : (
          <div className="mt-4 grid gap-3 lg:grid-cols-2">
            <div className="glass-inset rounded-2xl p-4">
              <div className="flex items-center gap-2">
                <ExternalLink className="size-4 text-violet-glow" />
                <p className="text-[13px] font-semibold text-white">Вариант 1 — PWABuilder (без кода)</p>
              </div>
              <ol className="mt-2 space-y-1.5 text-[12.5px] leading-relaxed text-mist">
                <li>1. Откройте pwabuilder.com и вставьте ссылку приложения.</li>
                <li>2. Нажмите «Package for stores» → Android.</li>
                <li>3. Скачайте пакет: внутри будет готовый .apk и .aab.</li>
                <li>
                  4. Перешлите .apk на телефон и установите (разрешите установку из неизвестных
                  источников).
                </li>
              </ol>
            </div>
            <div className="glass-inset rounded-2xl p-4">
              <div className="flex items-center gap-2">
                <Terminal className="size-4 text-cyan-glow" />
                <p className="text-[13px] font-semibold text-white">Вариант 2 — Bubblewrap CLI</p>
              </div>
              <pre className="mt-2 overflow-x-auto rounded-xl bg-black/45 p-3 text-[11.5px] leading-relaxed text-[#cbb8ff]">
{`npm i -g @bubblewrap/cli
bubblewrap init --manifest ${origin || "https://ваш-домен"}/manifest.webmanifest
bubblewrap build   # получите app-release-signed.apk`}
              </pre>
              <p className="mt-2 text-[11.5px] leading-relaxed text-mist/80">
                TWA открывает ваш сайт в системном Chrome без адресной строки. Нужен HTTPS-домен и Java JDK
                + Android SDK на компьютере.
              </p>
            </div>
          </div>
        )}
        <div className="mt-3 flex items-start gap-2.5 rounded-2xl border border-amber-glow/25 bg-amber-glow/8 px-4 py-3">
          <Info className="mt-0.5 size-4 shrink-0 text-amber-glow" />
          <p className="text-[12px] leading-relaxed text-amber-glow/90">
            {platform === "ios"
              ? "В App Store приложение не публикуется, поэтому вариант через Safari — единственный без компьютера и Apple Developer аккаунта."
              : "Для повседневного использования APK не нужен: PWA ставится из Chrome за пару секунд, обновляется автоматически и не требует разрешений. APK имеет смысл только для публикации в RuStore/Google Play или раздачи файлом."}
          </p>
        </div>
      </Card>

      <Card className="p-5">
        <div className="flex flex-wrap items-center gap-3">
          <TriangleAlert className="size-4 shrink-0 text-rose-glow" />
          <p className="flex-1 text-[12.5px] leading-relaxed text-mist">
            {isTemporary
              ? "Вы открыли приложение по временной ссылке предпросмотра. Она работает только пока идёт сессия разработки, поэтому ярлык с неё перестанет открываться. Чтобы получить постоянный адрес с HTTPS, откройте инструкцию — она доступна и в приложении, и в файле ИНСТРУЦИЯ.md."
              : "Установка привязана к домену: иконка будет всегда вести на этот адрес. Если вы ранее добавляли приложение с другой ссылки — удалите старый ярлык и добавьте его заново."}
          </p>
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex gap-2">
              <Chip active>HTTPS</Chip>
              <Chip active>Manifest</Chip>
              <Chip active>Service Worker</Chip>
            </div>
            <Link href="/deploy" className="ml-auto">
              <Btn size="sm" variant="primary">
                <BookOpen className="size-3.5" /> Инструкция по постоянному домену
              </Btn>
            </Link>
          </div>
        </div>
      </Card>

      <div className="flex flex-wrap items-center justify-between gap-3 pb-2">
        <p className="text-[12px] text-mist">
          Статус:{" "}
          {standalone || state === "installed"
            ? "приложение запущено в standalone-режиме"
            : wrongBrowser
              ? `вы в ${env?.browser} — нужен Safari`
              : state === "ready"
                ? "браузер готов вызвать системный диалог установки"
                : "добавьте на экран «Домой» по инструкции"}
        </p>
        <InstallButton size="md" showManualIcon={false} />
      </div>
    </div>
  );
}
