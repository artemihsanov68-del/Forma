"use client";

import { useCallback, useEffect, useState } from "react";
import { addDays, format, subDays } from "date-fns";
import { ru } from "date-fns/locale";
import { ChevronLeft, ChevronRight, Flame, Plus, Salad, Trash2 } from "lucide-react";
import { api } from "@/lib/client";
import type { NutritionEntryDTO, NutritionSummary } from "@/lib/types";
import { Bar, Btn, Card, EmptyState, Ring, SectionHeading, Skeleton, Stat } from "@/components/ui";
import { BarsChart, TrendChart } from "@/components/charts";
import { FoodSheet } from "@/components/FoodSheet";
import { MEAL_LABELS, MEAL_ORDER, fmt, pct, todayISO } from "@/lib/utils";

interface DayResponse {
  date: string;
  entries: NutritionEntryDTO[];
  totals: { kcal: number; protein: number; fat: number; carbs: number };
  targets: { calories: number; protein: number; fat: number; carbs: number };
}

interface AnalyticsLite {
  nutrition: NutritionSummary;
}

const MACROS = [
  { key: "protein" as const, label: "Белки", color: "linear-gradient(90deg,#a78bfa,#7c5cff)", text: "text-[#cbb8ff]" },
  { key: "fat" as const, label: "Жиры", color: "linear-gradient(90deg,#ffce6b,#ff9d6b)", text: "text-amber-glow" },
  { key: "carbs" as const, label: "Углеводы", color: "linear-gradient(90deg,#46e0ff,#5eead4)", text: "text-cyan-glow" },
];

export default function NutritionPage() {
  const [date, setDate] = useState(todayISO());
  const [day, setDay] = useState<DayResponse | null>(null);
  const [summary, setSummary] = useState<NutritionSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [sheetOpen, setSheetOpen] = useState(false);
  const [sheetMeal, setSheetMeal] = useState("breakfast");

  const load = useCallback(async (d: string) => {
    setLoading(true);
    try {
      const [dayRes, analytics] = await Promise.all([
        api<DayResponse>(`/api/nutrition?date=${d}`),
        api<AnalyticsLite>(`/api/analytics?days=30`),
      ]);
      setDay(dayRes);
      setSummary(analytics.nutrition);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load(date);
    const params = new URLSearchParams(window.location.search);
    if (params.get("add")) {
      setSheetOpen(true);
      window.history.replaceState({}, "", "/nutrition");
    }
  }, [date, load]);

  async function removeEntry(id: number) {
    const res = await api<{ entries: NutritionEntryDTO[]; totals: DayResponse["totals"] }>(
      `/api/nutrition?id=${id}`,
      { method: "DELETE" },
    );
    setDay((prev) => (prev ? { ...prev, entries: res.entries, totals: res.totals } : prev));
    void load(date);
  }

  if (!day) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-56 w-full" />
        <Skeleton className="h-72 w-full" />
      </div>
    );
  }

  const t = day.targets;
  const left = t.calories - day.totals.kcal;
  const grouped = MEAL_ORDER.map((m) => ({
    meal: m,
    items: day.entries.filter((e) => e.meal === m),
  }));
  const dateLabel = format(new Date(`${date}T12:00:00`), "d MMMM, EEEE", { locale: ru });

  return (
    <div className="space-y-5">
      <FoodSheet
        open={sheetOpen}
        onClose={() => setSheetOpen(false)}
        date={date}
        meal={sheetMeal}
        onSaved={() => void load(date)}
      />

      <Card className="p-5 sm:p-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <SectionHeading title="Дневник питания" subtitle={dateLabel} icon={<Salad className="size-5" />} />
          <div className="flex items-center gap-2">
            <Btn size="icon" variant="subtle" onClick={() => setDate(subDays(new Date(`${date}T12:00:00`), 1).toISOString().slice(0, 10))}>
              <ChevronLeft className="size-4" />
            </Btn>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="input-glass w-[150px] py-2 text-center"
            />
            <Btn size="icon" variant="subtle" onClick={() => setDate(addDays(new Date(`${date}T12:00:00`), 1).toISOString().slice(0, 10))}>
              <ChevronRight className="size-4" />
            </Btn>
            <Btn size="sm" variant="subtle" onClick={() => setDate(todayISO())}>
              Сегодня
            </Btn>
          </div>
        </div>

        <div className="mt-5 flex flex-col items-center gap-6 lg:flex-row lg:items-center">
          <Ring value={day.totals.kcal} max={t.calories} size={164} stroke={14} from="#ffce6b" to="#ff8fb1">
            <div>
              <p className="text-[10.5px] uppercase tracking-[0.08em] text-mist/80">ккал</p>
              <p className="text-[28px] font-semibold leading-none text-white">{fmt(day.totals.kcal)}</p>
              <p className="mt-1 text-[11px] text-mist">
                {left >= 0 ? `осталось ${fmt(left)}` : `+${fmt(Math.abs(left))} сверх`}
              </p>
            </div>
          </Ring>

          <div className="grid w-full flex-1 gap-3 sm:grid-cols-3">
            {MACROS.map((m) => (
              <div key={m.key} className="glass-soft rounded-2xl p-3.5">
                <div className="flex items-baseline justify-between">
                  <span className="text-[11.5px] uppercase tracking-[0.06em] text-mist/80">{m.label}</span>
                  <span className={`text-[11.5px] font-semibold ${m.text}`}>
                    {pct(day.totals[m.key], t[m.key])}%
                  </span>
                </div>
                <p className="mt-1.5 flex items-baseline gap-1 text-[20px] font-semibold text-white">
                  {fmt(day.totals[m.key], 1)}
                  <span className="text-[11.5px] font-medium text-mist">/ {fmt(t[m.key])} г</span>
                </p>
                <Bar className="mt-2.5" value={day.totals[m.key]} max={t[m.key]} color={m.color} />
              </div>
            ))}
          </div>
        </div>

        <Btn
          variant="primary"
          className="mt-5 w-full py-3"
          onClick={() => {
            setSheetMeal("snack");
            setSheetOpen(true);
          }}
        >
          <Plus className="size-4" /> Добавить приём пищи
        </Btn>
      </Card>

      {summary ? (
        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
          <Stat
            label="Среднее за 30 дн."
            value={fmt(summary.avgCalories)}
            unit="ккал"
            delta={`цель ${fmt(summary.targetCalories)} · ${summary.calorieAdherencePct}%`}
            tone={Math.abs(summary.calorieAdherencePct - 100) <= 8 ? "good" : "warn"}
          />
          <Stat
            label="Белок"
            value={fmt(summary.avgProtein)}
            unit="г/день"
            delta={`${summary.proteinPerKg} г на кг веса`}
            tone={summary.proteinPerKg >= 1.6 ? "good" : "warn"}
          />
          <Stat
            label="Дисциплина"
            value={`${summary.loggedDays}/${summary.days}`}
            unit="дней"
            delta={`${fmt((summary.loggedDays / summary.days) * 100)}% дней с записями`}
            tone={summary.loggedDays / summary.days > 0.7 ? "good" : "warn"}
          />
          <Stat
            label="Баланс жиров"
            value={fmt(summary.fatSharePct)}
            unit="% ккал"
            delta={summary.fatSharePct >= 20 && summary.fatSharePct <= 35 ? "в норме (20–35%)" : "вне коридора 20–35%"}
            tone={summary.fatSharePct >= 20 && summary.fatSharePct <= 35 ? "good" : "warn"}
          />
        </div>
      ) : null}

      <div className="grid gap-4 xl:grid-cols-3">
        <Card className="p-5 xl:col-span-2">
          <SectionHeading
            title="Приёмы пищи"
            subtitle={`${day.entries.length} записей за день`}
            icon={<Flame className="size-5" />}
          />
          <div className="mt-4 space-y-3">
            {grouped.map((g) => (
              <div key={g.meal} className="glass-inset rounded-3xl p-4">
                <div className="flex items-center justify-between gap-3">
                  <p className="text-[13.5px] font-semibold text-white">
                    {MEAL_LABELS[g.meal]}
                    <span className="ml-2 text-[11.5px] font-normal text-mist">
                      {fmt(g.items.reduce((a, i) => a + i.kcal, 0))} ккал
                    </span>
                  </p>
                  <Btn
                    size="sm"
                    variant="subtle"
                    onClick={() => {
                      setSheetMeal(g.meal);
                      setSheetOpen(true);
                    }}
                  >
                    <Plus className="size-3.5" /> Добавить
                  </Btn>
                </div>

                {g.items.length ? (
                  <div className="mt-3 space-y-1.5">
                    {g.items.map((e) => (
                      <div
                        key={e.id}
                        className="flex items-center gap-3 rounded-2xl bg-white/[0.03] px-3.5 py-2.5"
                      >
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-[13px] font-medium text-white/90">{e.name}</p>
                          <p className="mt-0.5 text-[11px] text-mist">
                            {fmt(e.grams)} г · Б {fmt(e.protein, 1)} · Ж {fmt(e.fat, 1)} · У {fmt(e.carbs, 1)}
                          </p>
                        </div>
                        <span className="shrink-0 text-[13px] font-semibold text-white">{fmt(e.kcal)}</span>
                        <button
                          type="button"
                          onClick={() => void removeEntry(e.id)}
                          className="grid size-8 shrink-0 place-items-center rounded-xl text-mist/60 transition-colors hover:bg-rose-500/15 hover:text-rose-glow"
                          title="Удалить"
                        >
                          <Trash2 className="size-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="mt-2 text-[12px] text-mist/70">Пусто</p>
                )}
              </div>
            ))}
          </div>
        </Card>

        <div className="space-y-4">
          <Card className="p-5">
            <SectionHeading title="Калории за 30 дней" subtitle="Факт против цели" icon={<Flame className="size-5" />} />
            <div className="mt-4">
              {summary && summary.dailySeries.length ? (
                <TrendChart
                  data={summary.dailySeries.map((d) => ({ ...d, target: summary.targetCalories }))}
                  series={[
                    { key: "kcal", name: "Ккал", color: "#ffce6b" },
                    {
                      key: "target",
                      name: "Цель",
                      color: "#8b7bff",
                      dashed: true,
                    },
                  ]}
                  unit="ккал"
                  height={210}
                  area
                />
              ) : (
                <EmptyState title="Нет истории" hint="Добавьте продукты за несколько дней." />
              )}
            </div>
          </Card>

          <Card className="p-5">
            <SectionHeading title="Макронутриенты" subtitle="Б / Ж / У по дням" icon={<Salad className="size-5" />} />
            <div className="mt-4">
              {summary && summary.dailySeries.length ? (
                <BarsChart
                  data={summary.dailySeries.slice(-14)}
                  xKey="date"
                  stack
                  height={210}
                  series={[
                    { key: "protein", name: "Белки", color: "#a78bfa" },
                    { key: "fat", name: "Жиры", color: "#ffce6b" },
                    { key: "carbs", name: "Углеводы", color: "#46e0ff" },
                  ]}
                  unit="г"
                />
              ) : (
                <EmptyState title="Нет данных" />
              )}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
