"use client";

import { useCallback, useEffect, useState } from "react";
import {
  CalendarDays,
  ChevronDown,
  Clock,
  Dumbbell,
  Flame,
  Pencil,
  Plus,
  Trash2,
} from "lucide-react";
import { api } from "@/lib/client";
import type { WorkoutDTO } from "@/lib/types";
import { Btn, Card, Chip, EmptyState, SectionHeading, Skeleton, Stat } from "@/components/ui";
import { WorkoutEditor } from "@/components/WorkoutEditor";
import { MUSCLE_LABELS, daysAgo, formatDate, fmt } from "@/lib/utils";

const PERIODS = [
  { value: "14", label: "2 недели" },
  { value: "30", label: "30 дней" },
  { value: "90", label: "90 дней" },
  { value: "365", label: "Год" },
];

export default function WorkoutsPage() {
  const [workouts, setWorkouts] = useState<WorkoutDTO[]>([]);
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState("90");
  const [expanded, setExpanded] = useState<number | null>(null);
  const [editorOpen, setEditorOpen] = useState(false);
  const [editing, setEditing] = useState<WorkoutDTO | null>(null);
  const [busyId, setBusyId] = useState<number | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await api<{ workouts: WorkoutDTO[] }>(`/api/workouts?limit=400`);
      setWorkouts(res.workouts);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
    const params = new URLSearchParams(window.location.search);
    if (params.get("new")) {
      setEditing(null);
      setEditorOpen(true);
      window.history.replaceState({}, "", "/workouts");
    } else if (params.get("id")) {
      setExpanded(Number(params.get("id")));
      window.history.replaceState({}, "", "/workouts");
    }
  }, [load]);

  const cutoff = Number(period);
  const filtered = workouts.filter((w) => daysAgo(w.date) <= cutoff);

  const stats = filtered.reduce(
    (acc, w) => ({
      count: acc.count + 1,
      volume: acc.volume + w.totalVolume,
      sets: acc.sets + w.totalSets,
      minutes: acc.minutes + (w.durationMinutes ?? 0),
    }),
    { count: 0, volume: 0, sets: 0, minutes: 0 },
  );

  async function remove(id: number) {
    setBusyId(id);
    try {
      await api(`/api/workouts/${id}`, { method: "DELETE" });
      await load();
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div className="space-y-5">
      <Card className="p-5 sm:p-6">
        <SectionHeading
          title="Журнал тренировок"
          subtitle="Объём, подходы и длительность считаются автоматически"
          icon={<Dumbbell className="size-5" />}
          action={
            <Btn
              variant="primary"
              onClick={() => {
                setEditing(null);
                setEditorOpen(true);
              }}
            >
              <Plus className="size-4" /> Новая
            </Btn>
          }
        />
        <div className="mt-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
          <Stat label="Тренировок" value={stats.count} delta={`за ${PERIODS.find((p) => p.value === period)?.label.toLowerCase()}`} />
          <Stat label="Общий объём" value={fmt(stats.volume)} unit="кг" delta={`${fmt(stats.count ? Math.round(stats.volume / stats.count) : 0)} кг в среднем`} />
          <Stat label="Рабочих подходов" value={fmt(stats.sets)} delta={`${fmt(stats.count ? Math.round((stats.sets / stats.count) * 10) / 10 : 0)} на тренировку`} />
          <Stat label="Время в зале" value={fmt(Math.round(stats.minutes / 60))} unit="ч" delta={`${fmt(stats.count ? Math.round(stats.minutes / stats.count) : 0)} мин за сессию`} />
        </div>
        <div className="scroll-x mt-4 flex gap-2 overflow-x-auto">
          {PERIODS.map((p) => (
            <Chip key={p.value} active={period === p.value} onClick={() => setPeriod(p.value)}>
              {p.label}
            </Chip>
          ))}
        </div>
      </Card>

      <WorkoutEditor
        open={editorOpen}
        onClose={() => setEditorOpen(false)}
        onSaved={() => void load()}
        initial={editing}
      />

      {loading ? (
        <div className="space-y-3">
          {[0, 1, 2].map((i) => (
            <Skeleton key={i} className="h-28 w-full" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={<Dumbbell className="size-8" />}
          title="За этот период тренировок нет"
          hint="Создайте тренировку — подходы, объём и прогрессия сохранятся в базе."
          action={
            <Btn variant="primary" onClick={() => setEditorOpen(true)}>
              <Plus className="size-4" /> Создать тренировку
            </Btn>
          }
        />
      ) : (
        <div className="space-y-3">
          {filtered.map((w) => {
            const open = expanded === w.id;
            return (
              <Card key={w.id} className="overflow-hidden">
                <button
                  type="button"
                  onClick={() => setExpanded(open ? null : w.id)}
                  className="flex w-full items-center gap-4 px-5 py-4 text-left transition-colors hover:bg-white/[0.03]"
                >
                  <span className="glass-soft grid size-12 shrink-0 place-items-center rounded-2xl">
                    <CalendarDays className="size-5 text-violet-glow" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[15px] font-semibold text-white">{w.title}</p>
                    <p className="mt-0.5 text-[12px] text-mist">
                      {formatDate(w.date, "d MMMM, EEEE")}
                      {daysAgo(w.date) === 0 ? " · сегодня" : daysAgo(w.date) === 1 ? " · вчера" : ""}
                    </p>
                  </div>
                  <div className="hidden items-center gap-4 sm:flex">
                    <Metric icon={<Flame className="size-3.5" />} value={`${fmt(w.totalVolume)} кг`} label="объём" />
                    <Metric icon={<Dumbbell className="size-3.5" />} value={String(w.totalSets)} label="подходов" />
                    <Metric icon={<Clock className="size-3.5" />} value={w.durationMinutes ? `${w.durationMinutes}′` : "—"} label="время" />
                  </div>
                  <ChevronDown
                    className={
                      "size-4 shrink-0 text-mist transition-transform duration-300 " + (open ? "rotate-180" : "")
                    }
                  />
                </button>

                <div className="flex items-center gap-3 border-t border-white/6 px-5 pb-3 pt-1 sm:hidden">
                  <Metric icon={<Flame className="size-3.5" />} value={`${fmt(w.totalVolume)} кг`} label="объём" />
                  <Metric icon={<Dumbbell className="size-3.5" />} value={String(w.totalSets)} label="подх." />
                  <Metric icon={<Clock className="size-3.5" />} value={w.durationMinutes ? `${w.durationMinutes}′` : "—"} label="мин" />
                </div>

                {open ? (
                  <div className="border-t border-white/8 px-5 py-5">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="rounded-full border border-white/10 bg-white/[0.05] px-2.5 py-1 text-[11.5px] text-mist">
                        Самочувствие {w.feeling ?? "—"}/5
                      </span>
                      <span className="rounded-full border border-white/10 bg-white/[0.05] px-2.5 py-1 text-[11.5px] text-mist">
                        {w.exercises.length} упражнений
                      </span>
                      <div className="ml-auto flex gap-2">
                        <Btn
                          size="sm"
                          variant="subtle"
                          onClick={() => {
                            setEditing(w);
                            setEditorOpen(true);
                          }}
                        >
                          <Pencil className="size-3.5" /> Изменить
                        </Btn>
                        <Btn
                          size="sm"
                          variant="danger"
                          disabled={busyId === w.id}
                          onClick={() => void remove(w.id)}
                        >
                          <Trash2 className="size-3.5" /> {busyId === w.id ? "…" : "Удалить"}
                        </Btn>
                      </div>
                    </div>

                    {w.notes ? (
                      <p className="mt-3 rounded-2xl bg-white/[0.03] px-4 py-3 text-[13px] leading-relaxed text-white/80">
                        {w.notes}
                      </p>
                    ) : null}

                    <div className="mt-4 space-y-3">
                      {w.exercises.map((ex) => (
                        <div key={ex.id} className="glass-inset rounded-2xl p-3.5">
                          <div className="flex items-center justify-between gap-3">
                            <p className="text-[13.5px] font-semibold text-white">{ex.exerciseName}</p>
                            <span className="shrink-0 text-[11.5px] text-mist">
                              {MUSCLE_LABELS[ex.muscleGroup] ?? ex.muscleGroup} · {fmt(ex.volume)} кг
                              {ex.bestE1rm ? ` · e1RM ${fmt(ex.bestE1rm, 1)}` : ""}
                            </span>
                          </div>
                          <div className="scroll-x mt-2.5 flex gap-2 overflow-x-auto pb-1">
                            {ex.sets.map((s) => (
                              <div
                                key={s.id}
                                className={
                                  "min-w-[86px] shrink-0 rounded-xl border px-2.5 py-2 text-center " +
                                  (s.isWarmup
                                    ? "border-amber-glow/25 bg-amber-glow/8"
                                    : "border-white/8 bg-white/[0.04]")
                                }
                              >
                                <p className="text-[10px] uppercase tracking-[0.06em] text-mist/70">
                                  {s.isWarmup ? "разминка" : `подход ${s.setNumber}`}
                                </p>
                                <p className="mt-0.5 text-[13px] font-semibold text-white">
                                  {s.weightKg > 0 || s.reps > 0
                                    ? `${fmt(s.weightKg, 1)} × ${s.reps}`
                                    : s.durationSeconds
                                      ? `${s.durationSeconds} сек`
                                      : "—"}
                                </p>
                                {s.rpe ? (
                                  <p className="text-[10.5px] text-mist">RPE {fmt(s.rpe, 1)}</p>
                                ) : null}
                              </div>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : null}
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}

function Metric({ icon, value, label }: { icon: React.ReactNode; value: string; label: string }) {
  return (
    <div className="flex items-center gap-1.5">
      <span className="text-mist/70">{icon}</span>
      <span className="text-[12.5px] font-semibold text-white">{value}</span>
      <span className="hidden text-[11px] text-mist md:inline">{label}</span>
    </div>
  );
}
