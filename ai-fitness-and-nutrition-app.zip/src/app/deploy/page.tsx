"use client";

import { useCallback, useEffect, useState } from "react";
import {
  BookOpen,
  CheckCircle2,
  ChevronDown,
  Cloud,
  Copy,
  Database,
  Globe,
  KeyRound,
  Loader2,
  RefreshCcw,
  Rocket,
  Server,
  Smartphone,
  TriangleAlert,
} from "lucide-react";
import { Btn, Card, SectionHeading } from "@/components/ui";
import { cn } from "@/lib/utils";

interface SetupStatus {
  connected: boolean;
  ready: boolean;
  existing: string[];
  missing: string[];
  error?: string;
}

type SetupState =
  | { kind: "idle" }
  | { kind: "checking" }
  | { kind: "creating" }
  | { kind: "done"; message: string }
  | { kind: "error"; message: string };

interface Step {
  id: string;
  title: string;
  icon: React.ReactNode;
  time: string;
  children: React.ReactNode;
}

const PREVIEW_WARNING =
  "Ссылка предпросмотра (3000-xxxx.e2b.app) временная: она работает только пока открыта сессия разработки и только в браузере, авторизованном на arena.ai. PWA привязывается к адресу, с которого его добавили на экран «Домой», поэтому ярлык с такой ссылки перестанет открываться. Нужен постоянный HTTPS-домен.";

const NEON_STEPS = [
  "Откройте neon.tech → Sign up (можно войти через GitHub).",
  "Create project: имя forma, регион Europe (Frankfurt).",
  "В блоке Connection Details переключитесь на вкладку Pooled connection.",
  "Скопируйте строку целиком — она выглядит как postgresql://forma_owner:ПАРОЛЬ@ep-xxx.eu-central-1.aws.neon.tech/forma?sslmode=require. Пароль показывается один раз.",
];

const VERCEL_STEPS = [
  "Залейте проект на GitHub: git init → git add . → git commit → git push. Убедитесь, что файл .env не попал в репозиторий.",
  "vercel.com → Add New → Project → выберите репозиторий forma → Import.",
  "Framework Preset определится как Next.js — настройки по умолчанию корректны.",
  "Раскройте Environment Variables и добавьте DATABASE_URL (строка из Neon) и NEXT_PUBLIC_SITE_URL (ваш домен).",
  "Нажмите Deploy и дождитесь зелёной галочки — перед вами постоянный адрес вида https://forma-abc123.vercel.app.",
];

const VERIFY_STEPS = [
  "Откройте домен — должна появиться тёмная главная страница с кольцом калорий и цифрами тренировок.",
  "Проверьте https://ваш-домен/api/health — должно вернуться {\"ok\":true}.",
  "Проверьте https://ваш-домен/manifest.webmanifest — должен вернуться JSON с названием FORMA.",
  "На этой странице в третьем блоке горит «Все таблицы на месте».",
  "Если NEXT_PUBLIC_SITE_URL был указан приблизительно — исправьте в Settings → Environment Variables и нажмите Redeploy.",
  "HTTPS включён автоматически: в адресной строке должен быть замочек.",
];

const DOMAIN_STEPS = [
  "Купите домен у регистратора (reg.ru, timeweb.com, nic.ru, Cloudflare) — обычно 200–700 ₽ в год.",
  "В проекте Vercel: Settings → Domains → Add → введите forma.ru → Add.",
  "Vercel покажет DNS-записи. Обычно это A → 76.76.21.21 и CNAME www → cname.vercel-dns.com.",
  "Добавьте эти записи в панели управления доменом у регистратора (раздел DNS-зона).",
  "Подождите от 5 минут до 24 часов и нажмите Refresh в Vercel — статус станет Valid Configuration.",
  "Обновите NEXT_PUBLIC_SITE_URL на https://forma.ru и сделайте Redeploy.",
];

const PHONE_STEPS = [
  "iPhone: откройте домен в Safari → Поделиться (квадрат со стрелкой вверх) → На экран «Домой» → Добавить.",
  "Android: откройте домен в Chrome → меню ⋮ → Установить приложение.",
  "Удалите старый ярлык, созданный со ссылки предпросмотра, — иначе он будет вести на заглушку.",
];

const TROUBLESHOOTING: Array<[string, string]> = [
  [
    "На телефоне вижу «Preview Unavailable»",
    "Открыта временная ссылка. Используйте постоянный домен — это и есть цель инструкции.",
  ],
  [
    "Application error при открытии",
    "Не задана переменная DATABASE_URL. Проверьте Settings → Environment Variables в Vercel и сделайте Redeploy.",
  ],
  [
    "Главная пустая, тренировок нет",
    "Таблицы не созданы. Прокрутите до третьего блока и нажмите «Создать таблицы».",
  ],
  [
    "Кнопка пишет «Нет подключения к базе»",
    "Проверьте строку DATABASE_URL: она должна быть целиком, включая ?sslmode=require.",
  ],
  [
    "Манифест не найден (404)",
    "Убедитесь, что файл src/app/manifest.ts на месте, и сделайте Redeploy после изменений.",
  ],
  [
    "На iPhone нет пункта «На экран Домой»",
    "Открыто не в Safari. Скопируйте ссылку и вставьте её в адресную строку Safari.",
  ],
  [
    "ИИ-анализ пишет «Локальный эксперт»",
    "Это норма: без ключа работает встроенный движок. Добавьте OPENAI_API_KEY для внешней модели.",
  ],
  [
    "Изменения не видны после push",
    "Подождите сборку 1–3 минуты или сделайте Redeploy вручную: Deployments → ⋯ → Redeploy.",
  ],
];

const STEPS: Step[] = [
  {
    id: "neon",
    title: "База данных в Neon",
    icon: <Database className="size-5" />,
    time: "5 минут · бесплатно",
    children: (
      <ol className="space-y-2">
        {NEON_STEPS.map((s, i) => (
          <li key={i} className="flex gap-2.5">
            <span className="mt-0.5 grid size-5 shrink-0 place-items-center rounded-full bg-white/8 text-[11px] font-semibold text-mist">
              {i + 1}
            </span>
            <span className="text-[12.5px] leading-relaxed text-mist">{s}</span>
          </li>
        ))}
      </ol>
    ),
  },
  {
    id: "vercel",
    title: "Постоянный адрес на Vercel",
    icon: <Rocket className="size-5" />,
    time: "7 минут · бесплатно",
    children: (
      <div className="space-y-3">
        <ol className="space-y-2">
          {VERCEL_STEPS.map((s, i) => (
            <li key={i} className="flex gap-2.5">
              <span className="mt-0.5 grid size-5 shrink-0 place-items-center rounded-full bg-white/8 text-[11px] font-semibold text-mist">
                {i + 1}
              </span>
              <span className="text-[12.5px] leading-relaxed text-mist">{s}</span>
            </li>
          ))}
        </ol>
        <div className="glass-inset rounded-2xl p-3.5">
          <p className="flex items-center gap-2 text-[12.5px] font-semibold text-white">
            <KeyRound className="size-3.5 text-cyan-glow" /> Переменные окружения
          </p>
          <div className="mt-2.5 space-y-1.5">
            <EnvRow name="DATABASE_URL" value="строка подключения из Neon" required />
            <EnvRow name="NEXT_PUBLIC_SITE_URL" value="https://ваш-домен.vercel.app" required />
            <EnvRow name="OPENAI_API_KEY" value="по желанию — для ИИ-разбора внешней моделью" />
          </div>
        </div>
      </div>
    ),
  },
  {
    id: "tables",
    title: "Создать таблицы",
    icon: <Database className="size-5" />,
    time: "1 минута · одной кнопкой",
    children: <TablesStep />,
  },
  {
    id: "verify",
    title: "Проверить, что всё работает",
    icon: <Globe className="size-5" />,
    time: "2 минуты",
    children: (
      <ol className="space-y-2">
        {VERIFY_STEPS.map((s, i) => (
          <li key={i} className="flex gap-2.5">
            <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-lime-glow" />
            <span className="text-[12.5px] leading-relaxed text-mist">{s}</span>
          </li>
        ))}
      </ol>
    ),
  },
  {
    id: "domain",
    title: "Свой домен вместо vercel.app",
    icon: <Cloud className="size-5" />,
    time: "по желанию",
    children: (
      <ol className="space-y-2">
        {DOMAIN_STEPS.map((s, i) => (
          <li key={i} className="flex gap-2.5">
            <span className="mt-0.5 grid size-5 shrink-0 place-items-center rounded-full bg-white/8 text-[11px] font-semibold text-mist">
              {i + 1}
            </span>
            <span className="text-[12.5px] leading-relaxed text-mist">{s}</span>
          </li>
        ))}
      </ol>
    ),
  },
  {
    id: "phone",
    title: "Установить на телефон",
    icon: <Smartphone className="size-5" />,
    time: "1 минута",
    children: (
      <ol className="space-y-2">
        {PHONE_STEPS.map((s, i) => (
          <li key={i} className="flex gap-2.5">
            <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-cyan-glow" />
            <span className="text-[12.5px] leading-relaxed text-mist">{s}</span>
          </li>
        ))}
      </ol>
    ),
  },
  {
    id: "vps",
    title: "Вариант со своим сервером (VPS)",
    icon: <Server className="size-5" />,
    time: "для опытных",
    children: (
      <div className="space-y-3">
        <p className="text-[12.5px] leading-relaxed text-mist">
          Любой хостинг с Node.js и HTTPS подойдёт. Порядок такой:
        </p>
        <CodeBlock
          code={`git clone https://github.com/ВАШ-ЛОГИН/forma.git /var/www/forma
cd /var/www/forma && npm ci && npm run build
# в .env положите DATABASE_URL и NEXT_PUBLIC_SITE_URL
npm run start   # порт 3000`}
          note="Затем настройте Nginx как reverse proxy и выдайте бесплатный сертификат: sudo certbot --nginx -d forma.ru"
        />
        <p className="text-[12px] leading-relaxed text-mist/85">
          Альтернатива без сервера — Cloudflare Tunnel:{" "}
          <code className="rounded bg-white/8 px-1.5 py-0.5 text-[11.5px] text-white/90">
            cloudflared tunnel --url http://localhost:3000
          </code>{" "}
          даёт постоянный HTTPS-адрес с вашего компьютера.
        </p>
      </div>
    ),
  },
];

export default function DeployPage() {
  const [open, setOpen] = useState<string | null>("neon");

  return (
    <div className="space-y-5">
      <Card className="p-5 sm:p-6">
        <SectionHeading
          title="Постоянный HTTPS-домен"
          subtitle="Шесть шагов до адреса, с которого приложение ставится на телефон навсегда"
          icon={<BookOpen className="size-5" />}
        />
        <div className="mt-4 flex items-start gap-2.5 rounded-2xl border border-amber-glow/25 bg-amber-glow/8 px-4 py-3">
          <TriangleAlert className="mt-0.5 size-4 shrink-0 text-amber-glow" />
          <p className="text-[12px] leading-relaxed text-amber-glow/90">{PREVIEW_WARNING}</p>
        </div>
        <div className="mt-4 grid gap-3 sm:grid-cols-3">
          <InfoTile icon={<Database className="size-4" />} title="Neon" text="Бесплатная PostgreSQL в облаке" />
          <InfoTile icon={<Rocket className="size-4" />} title="Vercel" text="Хостинг и HTTPS бесплатно" />
          <InfoTile icon={<Globe className="size-4" />} title="Свой домен" text="Необязательно, но красиво" />
        </div>
      </Card>

      <div className="space-y-3">
        {STEPS.map((s, i) => {
          const expanded = open === s.id;
          return (
            <Card key={s.id} className="overflow-hidden">
              <button
                type="button"
                onClick={() => setOpen(expanded ? null : s.id)}
                className="flex w-full items-center gap-3.5 px-5 py-4 text-left transition-colors hover:bg-white/[0.03]"
              >
                <span className="glass-soft grid size-11 shrink-0 place-items-center rounded-2xl text-violet-glow">
                  {s.icon}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block text-[14.5px] font-semibold text-white">
                    {i + 1}. {s.title}
                  </span>
                  <span className="mt-0.5 block text-[11.5px] text-mist">{s.time}</span>
                </span>
                <ChevronDown
                  className={cn(
                    "size-4 shrink-0 text-mist transition-transform duration-300",
                    expanded && "rotate-180",
                  )}
                />
              </button>
              {expanded ? (
                <div className="border-t border-white/8 px-5 py-5">{s.children}</div>
              ) : null}
            </Card>
          );
        })}
      </div>

      <Card className="p-5">
        <SectionHeading
          title="Если что-то не работает"
          subtitle="Частые ситуации и решения"
          icon={<TriangleAlert className="size-5" />}
        />
        <div className="mt-4 space-y-2.5">
          {TROUBLESHOOTING.map(([q, a]) => (
            <div key={q} className="glass-inset rounded-2xl px-4 py-3">
              <p className="text-[13px] font-semibold text-white">{q}</p>
              <p className="mt-1.5 text-[12.5px] leading-relaxed text-mist">{a}</p>
            </div>
          ))}
        </div>
      </Card>

      <Card className="p-5">
        <div className="flex flex-wrap items-center gap-3">
          <p className="flex-1 text-[12.5px] leading-relaxed text-mist">
            Полная версия этой инструкции с командами для терминала лежит в файле{" "}
            <code className="rounded bg-white/8 px-1.5 py-0.5 text-[12px] text-white/90">
              ИНСТРУЦИЯ.md
            </code>{" "}
            в корне проекта.
          </p>
          <CopyBlock text="npm i -g vercel && vercel login && vercel --prod" label="Команда деплоя" />
        </div>
      </Card>
    </div>
  );
}

/** Step 3: create all tables with a single click — no terminal needed. */
function TablesStep() {
  const [status, setStatus] = useState<SetupStatus | null>(null);
  const [state, setState] = useState<SetupState>({ kind: "idle" });

  const check = useCallback(async () => {
    setState({ kind: "checking" });
    try {
      const res = await fetch("/api/setup", { cache: "no-store" });
      const data = (await res.json()) as SetupStatus;
      setStatus(data);
      setState({ kind: "idle" });
    } catch (err) {
      setState({
        kind: "error",
        message: err instanceof Error ? err.message : "Не удалось проверить",
      });
    }
  }, []);

  useEffect(() => {
    void check();
  }, [check]);

  async function create() {
    setState({ kind: "creating" });
    try {
      const res = await fetch("/api/setup", { method: "POST" });
      const data = (await res.json()) as {
        ok?: boolean;
        message?: string;
        error?: string;
        status?: SetupStatus;
      };
      if (!res.ok || !data.ok) throw new Error(data.error ?? "Не удалось создать таблицы");
      setStatus(data.status ?? null);
      setState({ kind: "done", message: data.message ?? "Готово" });
    } catch (err) {
      setState({
        kind: "error",
        message: err instanceof Error ? err.message : "Не удалось создать таблицы",
      });
    }
  }

  const busy = state.kind === "checking" || state.kind === "creating";

  return (
    <div className="space-y-3.5">
      <p className="text-[12.5px] leading-relaxed text-mist">
        После деплоя база пока пустая. Нажмите кнопку — приложение само создаст все 9 таблиц, индексы
        и загрузит каталоги (38 упражнений, 42 продукта) вместе с демо-историей, чтобы графики и
        ИИ-разбор сразу работали на реальных цифрах.
      </p>

      <div className="rounded-2xl border border-violet-glow/25 bg-gradient-to-br from-violet-glow/12 to-cyan-glow/8 p-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <span className="grid size-9 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-violet-glow to-cyan-glow text-[#0b0716]">
              <Database className="size-[18px]" strokeWidth={2.3} />
            </span>
            <div>
              <p className="text-[13.5px] font-semibold text-white">Создать таблицы одним нажатием</p>
              <p className="mt-0.5 text-[11.5px] text-mist">
                Терминал и Node.js не нужны — всё делается внутри приложения
              </p>
            </div>
          </div>
          <Btn variant="primary" onClick={() => void create()} disabled={busy}>
            {state.kind === "creating" ? (
              <>
                <Loader2 className="size-4 spin" /> Создаём…
              </>
            ) : (
              <>
                <Database className="size-4" /> Создать таблицы
              </>
            )}
          </Btn>
        </div>

        <div className="mt-3.5 flex flex-wrap items-center gap-2">
          <StatusPill status={status} state={state} />
          <Btn size="sm" variant="subtle" onClick={() => void check()} disabled={busy}>
            <RefreshCcw className={cn("size-3.5", busy && "spin")} /> Проверить
          </Btn>
        </div>

        {status?.missing.length ? (
          <p className="mt-2.5 text-[11.5px] leading-relaxed text-mist/85">
            Сейчас отсутствуют: {status.missing.join(", ")}
          </p>
        ) : null}
        {status?.existing.length ? (
          <p className="mt-2.5 text-[11.5px] leading-relaxed text-mist/85">
            Уже существуют: {status.existing.join(", ")}
          </p>
        ) : null}

        {state.kind === "done" ? (
          <p className="mt-3 flex items-center gap-2 text-[12.5px] font-medium text-lime-glow">
            <CheckCircle2 className="size-4" /> {state.message}
          </p>
        ) : null}
        {state.kind === "error" ? (
          <p className="mt-3 text-[12.5px] leading-relaxed text-rose-glow">{state.message}</p>
        ) : null}
      </div>

      <p className="text-[12px] leading-relaxed text-mist/85">
        Кнопку можно нажимать много раз — повторный запуск ничего не сломает. Демо-данные (36
        тренировок за 12 недель, 22 дня питания, 9 замеров обхватов) можно удалить в разделе
        «Профиль → Очистить мои данные» и вести свой дневник с нуля.
      </p>

      <details className="glass-inset rounded-2xl px-4 py-3">
        <summary className="cursor-pointer text-[12.5px] font-medium text-white">
          Альтернатива: через терминал (если удобнее)
        </summary>
        <div className="mt-3 space-y-2.5">
          <p className="text-[12px] leading-relaxed text-mist">
            Установите Node.js с nodejs.org, откройте терминал в папке проекта и выполните:
          </p>
          <CodeBlock
            code={`DATABASE_URL="postgresql://user:pass@ep-xxx.eu-central-1.aws.neon.tech/db?sslmode=require" \\
  npx drizzle-kit push`}
            note="Ожидаемый вывод: [✓] Changes applied"
          />
        </div>
      </details>
    </div>
  );
}

function StatusPill({ status, state }: { status: SetupStatus | null; state: SetupState }) {
  if (state.kind === "checking") {
    return (
      <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.05] px-3 py-1.5 text-[11.5px] text-mist">
        <Loader2 className="size-3.5 spin" /> Проверяем подключение…
      </span>
    );
  }
  if (!status) return null;
  if (!status.connected) {
    return (
      <span className="inline-flex items-center gap-2 rounded-full border border-rose-glow/30 bg-rose-glow/12 px-3 py-1.5 text-[11.5px] text-rose-glow">
        <TriangleAlert className="size-3.5" /> Нет подключения к базе
      </span>
    );
  }
  if (status.ready) {
    return (
      <span className="inline-flex items-center gap-2 rounded-full border border-lime-glow/30 bg-lime-glow/12 px-3 py-1.5 text-[11.5px] text-lime-glow">
        <CheckCircle2 className="size-3.5" /> Все таблицы на месте
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-2 rounded-full border border-amber-glow/30 bg-amber-glow/12 px-3 py-1.5 text-[11.5px] text-amber-glow">
      <TriangleAlert className="size-3.5" /> Таблиц ещё нет — нажмите «Создать таблицы»
    </span>
  );
}

function InfoTile({
  icon,
  title,
  text,
}: {
  icon: React.ReactNode;
  title: string;
  text: string;
}) {
  return (
    <div className="glass-inset rounded-2xl px-4 py-3">
      <div className="flex items-center gap-2">
        <span className="text-cyan-glow">{icon}</span>
        <p className="text-[13px] font-semibold text-white">{title}</p>
      </div>
      <p className="mt-1 text-[12px] leading-relaxed text-mist">{text}</p>
    </div>
  );
}

function EnvRow({
  name,
  value,
  required,
}: {
  name: string;
  value: string;
  required?: boolean;
}) {
  return (
    <div className="flex flex-wrap items-center gap-2 rounded-xl bg-black/30 px-3 py-2">
      <code className="text-[11.5px] font-semibold text-[#cbb8ff]">{name}</code>
      <span className="text-[11.5px] text-mist">{value}</span>
      {required ? (
        <span className="ml-auto rounded-full bg-rose-glow/14 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-rose-glow">
          обязательно
        </span>
      ) : (
        <span className="ml-auto rounded-full bg-white/8 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-mist">
          опция
        </span>
      )}
    </div>
  );
}

function CodeBlock({ code, note }: { code: string; note?: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <div className="relative rounded-2xl border border-white/8 bg-black/45 p-3.5 pr-14">
      <pre className="overflow-x-auto text-[11.5px] leading-relaxed text-[#cbb8ff]">{code}</pre>
      <Btn
        size="icon"
        variant="subtle"
        className="absolute right-2.5 top-2.5"
        title="Скопировать"
        onClick={async () => {
          try {
            await navigator.clipboard.writeText(code);
            setCopied(true);
            setTimeout(() => setCopied(false), 1800);
          } catch {
            setCopied(false);
          }
        }}
      >
        {copied ? (
          <CheckCircle2 className="size-3.5 text-lime-glow" />
        ) : (
          <Copy className="size-3.5" />
        )}
      </Btn>
      {note ? <p className="mt-2 text-[11px] text-mist/80">{note}</p> : null}
    </div>
  );
}

function CopyBlock({ text, label }: { text: string; label: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <Btn
      size="sm"
      variant="subtle"
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(text);
          setCopied(true);
          setTimeout(() => setCopied(false), 1800);
        } catch {
          setCopied(false);
        }
      }}
    >
      {copied ? <CheckCircle2 className="size-3.5 text-lime-glow" /> : <Copy className="size-3.5" />}
      {copied ? "Скопировано" : label}
    </Btn>
  );
}
