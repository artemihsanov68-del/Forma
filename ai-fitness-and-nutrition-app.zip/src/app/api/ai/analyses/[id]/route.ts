import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { aiAnalyses } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";

export const dynamic = "force-dynamic";

type Params = { params: Promise<{ id: string }> };

export async function GET(_req: Request, { params }: Params) {
  await ensureSeeded();
  const { id } = await params;
  const [row] = await db.select().from(aiAnalyses).where(eq(aiAnalyses.id, Number(id)));
  if (!row) return NextResponse.json({ error: "Анализ не найден" }, { status: 404 });
  return NextResponse.json({ analysis: row });
}

export async function DELETE(_req: Request, { params }: Params) {
  await ensureSeeded();
  const { id } = await params;
  await db.delete(aiAnalyses).where(eq(aiAnalyses.id, Number(id)));
  return NextResponse.json({ ok: true });
}
