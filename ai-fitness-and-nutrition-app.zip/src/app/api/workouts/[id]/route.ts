import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { exerciseSets, workoutExercises, workouts } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { getWorkoutsDetailed } from "@/lib/stats";
import { totalsFor, type IncomingExercise } from "@/app/api/workouts/route";

export const dynamic = "force-dynamic";

type Params = { params: Promise<{ id: string }> };

export async function GET(_req: Request, { params }: Params) {
  await ensureSeeded();
  const { id } = await params;
  const workoutId = Number(id);
  const all = await getWorkoutsDetailed({ limit: 600 });
  const workout = all.find((w) => w.id === workoutId);
  if (!workout) return NextResponse.json({ error: "Тренировка не найдена" }, { status: 404 });
  return NextResponse.json({ workout });
}

export async function PATCH(req: Request, { params }: Params) {
  await ensureSeeded();
  const { id } = await params;
  const workoutId = Number(id);
  const body = (await req.json()) as {
    date?: string;
    title?: string;
    focus?: string;
    durationMinutes?: number | null;
    notes?: string | null;
    feeling?: number | null;
    exercises?: IncomingExercise[];
  };

  const patch: Record<string, unknown> = {};
  for (const key of ["date", "title", "focus", "durationMinutes", "notes", "feeling"] as const) {
    if (body[key] !== undefined) patch[key] = body[key];
  }

  if (body.exercises) {
    const totals = totalsFor(body.exercises);
    patch.totalVolume = totals.volume;
    patch.totalSets = totals.sets;
  }

  if (Object.keys(patch).length) {
    await db.update(workouts).set(patch).where(eq(workouts.id, workoutId));
  }

  if (body.exercises) {
    const oldEx = await db
      .select({ id: workoutExercises.id })
      .from(workoutExercises)
      .where(eq(workoutExercises.workoutId, workoutId));
    if (oldEx.length) {
      await db
        .delete(exerciseSets)
        .where(eq(exerciseSets.workoutExerciseId, oldEx[0].id));
      for (const o of oldEx) {
        await db.delete(exerciseSets).where(eq(exerciseSets.workoutExerciseId, o.id));
      }
    }
    await db.delete(workoutExercises).where(eq(workoutExercises.workoutId, workoutId));

    for (let i = 0; i < body.exercises.length; i++) {
      const ex = body.exercises[i];
      if (!ex.exerciseName?.trim()) continue;
      const [row] = await db
        .insert(workoutExercises)
        .values({
          workoutId,
          exerciseId: ex.exerciseId ?? null,
          exerciseName: ex.exerciseName.trim(),
          muscleGroup: ex.muscleGroup ?? "other",
          sortOrder: i,
        })
        .returning();
      const sets = (ex.sets ?? []).map((s, idx) => ({
        workoutExerciseId: row.id,
        setNumber: idx + 1,
        weightKg: Number(s.weightKg) || 0,
        reps: Number(s.reps) || 0,
        rpe: s.rpe == null || Number.isNaN(Number(s.rpe)) ? null : Number(s.rpe),
        durationSeconds: s.durationSeconds ? Number(s.durationSeconds) : null,
        distanceKm: s.distanceKm ? Number(s.distanceKm) : null,
        isWarmup: Boolean(s.isWarmup),
      }));
      if (sets.length) await db.insert(exerciseSets).values(sets);
    }
  }

  const all = await getWorkoutsDetailed({ limit: 600 });
  return NextResponse.json({ workout: all.find((w) => w.id === workoutId) ?? null });
}

export async function DELETE(_req: Request, { params }: Params) {
  await ensureSeeded();
  const { id } = await params;
  await db.delete(workouts).where(eq(workouts.id, Number(id)));
  return NextResponse.json({ ok: true });
}
