import {
  boolean,
  date,
  doublePrecision,
  index,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

/** Single-tenant app: one profile row (id = 1). */
export const profiles = pgTable("profiles", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().default("Атлет"),
  sex: text("sex").notNull().default("male"), // male | female
  birthDate: date("birth_date"),
  heightCm: doublePrecision("height_cm").notNull().default(178),
  weightKg: doublePrecision("weight_kg").notNull().default(80),
  activityLevel: text("activity_level").notNull().default("moderate"),
  goal: text("goal").notNull().default("recomp"), // cut | bulk | recomp | maintain
  targetCalories: integer("target_calories").notNull().default(2600),
  targetProtein: integer("target_protein").notNull().default(160),
  targetFat: integer("target_fat").notNull().default(80),
  targetCarbs: integer("target_carbs").notNull().default(300),
  workoutsPerWeek: integer("workouts_per_week").notNull().default(4),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

/** Exercise catalog. */
export const exercises = pgTable(
  "exercises",
  {
    id: serial("id").primaryKey(),
    name: text("name").notNull(),
    muscleGroup: text("muscle_group").notNull(), // chest | back | legs | shoulders | arms | core | cardio | other
    equipment: text("equipment").notNull().default("barbell"),
    kind: text("kind").notNull().default("strength"), // strength | cardio | bodyweight
    isCustom: boolean("is_custom").notNull().default(false),
  },
  (t) => [uniqueIndex("exercises_name_uniq").on(t.name)],
);

export const workouts = pgTable(
  "workouts",
  {
    id: serial("id").primaryKey(),
    date: date("date").notNull(),
    title: text("title").notNull().default("Тренировка"),
    focus: text("focus"),
    durationMinutes: integer("duration_minutes"),
    notes: text("notes"),
    feeling: integer("feeling"), // 1..5
    totalVolume: doublePrecision("total_volume").notNull().default(0),
    totalSets: integer("total_sets").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("workouts_date_idx").on(t.date)],
);

export const workoutExercises = pgTable(
  "workout_exercises",
  {
    id: serial("id").primaryKey(),
    workoutId: integer("workout_id")
      .notNull()
      .references(() => workouts.id, { onDelete: "cascade" }),
    exerciseId: integer("exercise_id").references(() => exercises.id, {
      onDelete: "set null",
    }),
    exerciseName: text("exercise_name").notNull(),
    muscleGroup: text("muscle_group").notNull().default("other"),
    sortOrder: integer("sort_order").notNull().default(0),
    notes: text("notes"),
  },
  (t) => [index("workout_exercises_workout_idx").on(t.workoutId)],
);

export const exerciseSets = pgTable(
  "exercise_sets",
  {
    id: serial("id").primaryKey(),
    workoutExerciseId: integer("workout_exercise_id")
      .notNull()
      .references(() => workoutExercises.id, { onDelete: "cascade" }),
    setNumber: integer("set_number").notNull().default(1),
    weightKg: doublePrecision("weight_kg").notNull().default(0),
    reps: integer("reps").notNull().default(0),
    rpe: doublePrecision("rpe"),
    durationSeconds: integer("duration_seconds"), // for cardio / planks
    distanceKm: doublePrecision("distance_km"),
    isWarmup: boolean("is_warmup").notNull().default(false),
  },
  (t) => [index("exercise_sets_parent_idx").on(t.workoutExerciseId)],
);

export const foodCatalog = pgTable(
  "food_catalog",
  {
    id: serial("id").primaryKey(),
    name: text("name").notNull(),
    brand: text("brand"),
    category: text("category").notNull().default("other"),
    kcal: doublePrecision("kcal").notNull().default(0),
    protein: doublePrecision("protein").notNull().default(0),
    fat: doublePrecision("fat").notNull().default(0),
    carbs: doublePrecision("carbs").notNull().default(0),
    perGrams: doublePrecision("per_grams").notNull().default(100),
    isCustom: boolean("is_custom").notNull().default(false),
  },
  (t) => [index("food_catalog_name_idx").on(t.name)],
);

export const nutritionEntries = pgTable(
  "nutrition_entries",
  {
    id: serial("id").primaryKey(),
    date: date("date").notNull(),
    meal: text("meal").notNull().default("snack"), // breakfast | lunch | dinner | snack
    name: text("name").notNull(),
    grams: doublePrecision("grams").notNull().default(100),
    kcal: doublePrecision("kcal").notNull().default(0),
    protein: doublePrecision("protein").notNull().default(0),
    fat: doublePrecision("fat").notNull().default(0),
    carbs: doublePrecision("carbs").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("nutrition_date_idx").on(t.date)],
);

export const measurements = pgTable(
  "measurements",
  {
    id: serial("id").primaryKey(),
    date: date("date").notNull(),
    weightKg: doublePrecision("weight_kg"),
    bodyFat: doublePrecision("body_fat"),
    neck: doublePrecision("neck"),
    chest: doublePrecision("chest"),
    shoulders: doublePrecision("shoulders"),
    waist: doublePrecision("waist"),
    hips: doublePrecision("hips"),
    glutes: doublePrecision("glutes"),
    thigh: doublePrecision("thigh"),
    biceps: doublePrecision("biceps"),
    forearm: doublePrecision("forearm"),
    calf: doublePrecision("calf"),
    notes: text("notes"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("measurements_date_idx").on(t.date)],
);

/** Every AI analysis (online provider or local expert engine) is persisted here. */
export const aiAnalyses = pgTable(
  "ai_analyses",
  {
    id: serial("id").primaryKey(),
    kind: text("kind").notNull(), // training | nutrition | body | full
    title: text("title").notNull(),
    periodLabel: text("period_label").notNull().default(""),
    provider: text("provider").notNull().default("local-expert"),
    model: text("model").notNull().default("expert-engine-v1"),
    online: boolean("online").notNull().default(false),
    prompt: text("prompt"),
    rawResponse: text("raw_response"),
    summary: text("summary").notNull().default(""),
    score: integer("score"),
    highlights: jsonb("highlights").$type<
      Array<{ title: string; detail: string; tone?: string }>
    >(),
    insights: jsonb("insights").$type<Array<{ title: string; detail: string }>>(),
    recommendations: jsonb("recommendations").$type<
      Array<{ title: string; detail: string; priority?: string }>
    >(),
    plan: jsonb("plan").$type<Array<string>>(),
    metrics: jsonb("metrics").$type<Record<string, unknown>>(),
    dataSnapshot: jsonb("data_snapshot").$type<Record<string, unknown>>(),
    durationMs: integer("duration_ms"),
    error: text("error"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("ai_created_idx").on(t.createdAt)],
);

export type Profile = typeof profiles.$inferSelect;
export type Exercise = typeof exercises.$inferSelect;
export type Workout = typeof workouts.$inferSelect;
export type WorkoutExercise = typeof workoutExercises.$inferSelect;
export type ExerciseSet = typeof exerciseSets.$inferSelect;
export type FoodItem = typeof foodCatalog.$inferSelect;
export type NutritionEntry = typeof nutritionEntries.$inferSelect;
export type Measurement = typeof measurements.$inferSelect;
export type AiAnalysis = typeof aiAnalyses.$inferSelect;
