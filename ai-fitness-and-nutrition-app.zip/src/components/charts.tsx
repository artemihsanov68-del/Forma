"use client";

import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { formatDate } from "@/lib/utils";

export interface LineSeries {
  key: string;
  name: string;
  color: string;
  dashed?: boolean;
}

const axisStyle = {
  fontSize: 11,
  fill: "rgba(167,174,203,0.85)",
  fontFamily: "inherit",
} as const;

function GlassTooltip({
  active,
  payload,
  label,
  unit,
  dateLabel,
}: {
  active?: boolean;
  payload?: Array<{ name?: string; value?: number | string; color?: string; dataKey?: string | number }>;
  label?: string | number;
  unit?: string;
  dateLabel?: boolean;
}) {
  if (!active || !payload?.length) return null;
  const title =
    typeof label === "string" && /^\d{4}-\d{2}-\d{2}$/.test(label) && dateLabel !== false
      ? formatDate(label, "d MMM")
      : String(label ?? "");
  return (
    <div className="glass rounded-2xl px-3.5 py-2.5 shadow-[0_20px_40px_-20px_rgba(0,0,0,0.9)]">
      {title ? (
        <p className="mb-1.5 text-[11px] font-medium uppercase tracking-[0.06em] text-mist/80">
          {title}
        </p>
      ) : null}
      <div className="space-y-1">
        {payload.map((p, i) => (
          <p key={i} className="flex items-center gap-2 text-[12.5px] text-white">
            <span
              className="size-2 rounded-full"
              style={{ background: p.color ?? "#a78bfa", boxShadow: `0 0 8px ${p.color ?? "#a78bfa"}` }}
            />
            <span className="text-mist">{p.name}</span>
            <span className="ml-auto font-semibold">
              {typeof p.value === "number" ? p.value.toLocaleString("ru-RU") : p.value}
              {unit ? ` ${unit}` : ""}
            </span>
          </p>
        ))}
      </div>
    </div>
  );
}

export function TrendChart({
  data,
  series,
  xKey = "date",
  unit,
  height = 240,
  area = false,
  yDomain,
  dateAxis = true,
}: {
  data: Array<Record<string, unknown>>;
  series: LineSeries[];
  xKey?: string;
  unit?: string;
  height?: number;
  area?: boolean;
  yDomain?: [number | string, number | string];
  dateAxis?: boolean;
}) {
  const Chart = area ? AreaChart : LineChart;
  return (
    <div style={{ width: "100%", height }}>
      <ResponsiveContainer>
        <Chart data={data} margin={{ top: 8, right: 8, bottom: 0, left: -18 }}>
          <defs>
            {series.map((s) => (
              <linearGradient key={s.key} id={`grad-${s.key}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={s.color} stopOpacity={0.5} />
                <stop offset="100%" stopColor={s.color} stopOpacity={0.02} />
              </linearGradient>
            ))}
          </defs>
          <CartesianGrid stroke="rgba(255,255,255,0.06)" vertical={false} />
          <XAxis
            dataKey={xKey}
            tick={axisStyle}
            axisLine={false}
            tickLine={false}
            tickFormatter={(v: string) => (dateAxis && /^\d{4}-\d{2}-\d{2}$/.test(v) ? formatDate(v, "d MMM") : v)}
            minTickGap={22}
          />
          <YAxis
            tick={axisStyle}
            axisLine={false}
            tickLine={false}
            width={54}
            domain={yDomain}
            tickFormatter={(v: number) => (Math.abs(v) >= 1000 ? `${Math.round(v / 1000)}k` : String(v))}
          />
          <Tooltip content={<GlassTooltip unit={unit} />} cursor={{ stroke: "rgba(255,255,255,0.18)" }} />
          {series.length > 1 ? (
            <Legend
              wrapperStyle={{ fontSize: 11.5, color: "rgba(167,174,203,0.9)", paddingTop: 6 }}
              iconType="circle"
              iconSize={7}
            />
          ) : null}
          {area
            ? series.map((s) => (
                <Area
                  key={s.key}
                  type="monotone"
                  dataKey={s.key}
                  name={s.name}
                  stroke={s.color}
                  strokeWidth={2.4}
                  fill={`url(#grad-${s.key})`}
                  dot={false}
                  activeDot={{ r: 4, strokeWidth: 0, fill: s.color }}
                  strokeDasharray={s.dashed ? "5 4" : undefined}
                />
              ))
            : series.map((s) => (
                <Line
                  key={s.key}
                  type="monotone"
                  dataKey={s.key}
                  name={s.name}
                  stroke={s.color}
                  strokeWidth={2.6}
                  dot={false}
                  activeDot={{ r: 4.5, strokeWidth: 2, stroke: "rgba(255,255,255,0.7)", fill: s.color }}
                  strokeDasharray={s.dashed ? "5 4" : undefined}
                />
              ))}
        </Chart>
      </ResponsiveContainer>
    </div>
  );
}

export function BarsChart({
  data,
  xKey,
  series,
  unit,
  height = 220,
  colors,
  horizontal = false,
  stack = false,
}: {
  data: Array<Record<string, unknown>>;
  xKey: string;
  series: LineSeries[];
  unit?: string;
  height?: number;
  colors?: string[];
  horizontal?: boolean;
  stack?: boolean;
}) {
  return (
    <div style={{ width: "100%", height }}>
      <ResponsiveContainer>
        <BarChart
          data={data}
          layout={horizontal ? "vertical" : "horizontal"}
          margin={{ top: 6, right: 10, bottom: 0, left: horizontal ? 8 : -20 }}
          barCategoryGap={horizontal ? 8 : "22%"}
        >
          <CartesianGrid stroke="rgba(255,255,255,0.06)" vertical={horizontal} horizontal={!horizontal} />
          <XAxis
            type={horizontal ? "number" : "category"}
            dataKey={horizontal ? undefined : xKey}
            tick={axisStyle}
            axisLine={false}
            tickLine={false}
            tickFormatter={(v: string) =>
              /^\d{4}-\d{2}-\d{2}$/.test(v) ? formatDate(v, "d MMM") : String(v)
            }
            minTickGap={16}
          />
          <YAxis
            type={horizontal ? "category" : "number"}
            dataKey={horizontal ? xKey : undefined}
            tick={axisStyle}
            axisLine={false}
            tickLine={false}
            width={horizontal ? 92 : 56}
            tickFormatter={(v: number | string) =>
              typeof v === "number" && Math.abs(v) >= 1000 ? `${Math.round(v / 1000)}k` : String(v)
            }
          />
          <Tooltip content={<GlassTooltip unit={unit} />} cursor={{ fill: "rgba(255,255,255,0.05)" }} />
          {series.map((s, i) => (
            <Bar
              key={s.key}
              dataKey={s.key}
              name={s.name}
              stackId={stack ? "a" : undefined}
              radius={horizontal ? [0, 8, 8, 0] : [8, 8, 0, 0]}
              fill={colors?.[i] ?? s.color}
              maxBarSize={horizontal ? 22 : 40}
            >
              {colors && colors.length > series.length
                ? data.map((_, idx) => (
                    <Cell key={idx} fill={colors[idx % colors.length]} fillOpacity={0.85} />
                  ))
                : null}
            </Bar>
          ))}
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
