"use client";

import { useEffect, type ReactNode } from "react";
import { X } from "lucide-react";
import { cn } from "@/lib/utils";

export function Card({
  children,
  className,
  hover = false,
  as: Tag = "div",
}: {
  children: ReactNode;
  className?: string;
  hover?: boolean;
  as?: "div" | "section" | "article" | "li";
}) {
  return (
    <Tag className={cn("glass rounded-[28px]", hover && "glass-hover", className)}>{children}</Tag>
  );
}

export function SectionHeading({
  title,
  subtitle,
  icon,
  action,
  className,
}: {
  title: string;
  subtitle?: string;
  icon?: ReactNode;
  action?: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("flex items-end justify-between gap-3", className)}>
      <div className="flex items-center gap-3">
        {icon ? (
          <span className="glass-soft grid size-10 shrink-0 place-items-center rounded-2xl text-violet-glow">
            {icon}
          </span>
        ) : null}
        <div>
          <h2 className="text-[17px] font-semibold tracking-tight text-white">{title}</h2>
          {subtitle ? <p className="mt-0.5 text-[12.5px] text-mist">{subtitle}</p> : null}
        </div>
      </div>
      {action}
    </div>
  );
}

type BtnProps = {
  children: ReactNode;
  onClick?: () => void;
  variant?: "primary" | "ghost" | "danger" | "subtle";
  size?: "sm" | "md" | "lg" | "icon";
  className?: string;
  disabled?: boolean;
  type?: "button" | "submit";
  title?: string;
};

export function Btn({
  children,
  onClick,
  variant = "ghost",
  size = "md",
  className,
  disabled,
  type = "button",
  title,
}: BtnProps) {
  return (
    <button
      type={type}
      title={title}
      disabled={disabled}
      onClick={onClick}
      className={cn(
        "btn-glass",
        variant === "primary" && "btn-primary",
        variant === "danger" && "border-rose-300/30 bg-rose-500/18 text-rose-100",
        variant === "subtle" && "bg-white/[0.04] border-white/8",
        size === "sm" && "px-3 py-1.5 text-[12.5px]",
        size === "md" && "px-4 py-2.5 text-[13.5px]",
        size === "lg" && "px-6 py-3.5 text-[15px]",
        size === "icon" && "size-9 p-0 rounded-full",
        className,
      )}
    >
      {children}
    </button>
  );
}

export function Field({
  label,
  children,
  hint,
  className,
}: {
  label?: string;
  children: ReactNode;
  hint?: string;
  className?: string;
}) {
  return (
    <label className={cn("block", className)}>
      {label ? (
        <span className="mb-1.5 block text-[11.5px] font-medium uppercase tracking-[0.07em] text-mist/80">
          {label}
        </span>
      ) : null}
      {children}
      {hint ? <span className="mt-1 block text-[11px] text-mist/60">{hint}</span> : null}
    </label>
  );
}

export function Input(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return <input {...props} className={cn("input-glass", props.className)} />;
}

export function Textarea(props: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea {...props} className={cn("input-glass resize-none", props.className)} />;
}

export function Select(props: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return <select {...props} className={cn("input-glass appearance-none pr-8", props.className)} />;
}

export function Chip({
  children,
  active,
  onClick,
  className,
}: {
  children: ReactNode;
  active?: boolean;
  onClick?: () => void;
  className?: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "rounded-full border px-3 py-1.5 text-[12.5px] font-medium transition-all duration-300",
        active
          ? "border-white/30 bg-white/16 text-white shadow-[inset_0_1px_0_rgba(255,255,255,0.35)]"
          : "border-white/8 bg-white/[0.03] text-mist hover:border-white/16 hover:text-white/90",
        className,
      )}
    >
      {children}
    </button>
  );
}

export function Segmented<T extends string>({
  options,
  value,
  onChange,
  className,
}: {
  options: Array<{ value: T; label: string }>;
  value: T;
  onChange: (v: T) => void;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "glass-inset flex gap-1 rounded-full p-1",
        className,
      )}
    >
      {options.map((o) => (
        <button
          key={o.value}
          type="button"
          onClick={() => onChange(o.value)}
          className={cn(
            "flex-1 rounded-full px-3 py-1.5 text-[12.5px] font-semibold transition-all duration-300",
            value === o.value
              ? "tab-active-glow bg-gradient-to-b from-white/22 to-white/8 text-white"
              : "text-mist hover:text-white/80",
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function Sheet({
  open,
  onClose,
  title,
  subtitle,
  children,
  footer,
  wide,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  children: ReactNode;
  footer?: ReactNode;
  wide?: boolean;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center">
      <div className="sheet-backdrop absolute inset-0" onClick={onClose} />
      <div
        className={cn(
          "sheet-panel glass relative flex max-h-[92vh] w-full flex-col rounded-t-[34px] sm:rounded-[34px]",
          wide ? "sm:max-w-3xl" : "sm:max-w-xl",
        )}
      >
        <div className="flex items-start justify-between gap-4 border-b border-white/8 px-5 pb-4 pt-5 sm:px-7">
          <div>
            <h3 className="text-[19px] font-semibold tracking-tight text-white">{title}</h3>
            {subtitle ? <p className="mt-1 text-[12.5px] text-mist">{subtitle}</p> : null}
          </div>
          <Btn size="icon" variant="subtle" onClick={onClose} title="Закрыть">
            <X className="size-4" />
          </Btn>
        </div>
        <div className="thin-scroll flex-1 overflow-y-auto px-5 py-5 sm:px-7">{children}</div>
        {footer ? (
          <div className="border-t border-white/8 px-5 py-4 sm:px-7">{footer}</div>
        ) : null}
      </div>
    </div>
  );
}

export function Ring({
  value,
  max,
  size = 128,
  stroke = 11,
  from = "#a78bfa",
  to = "#22d3ee",
  children,
}: {
  value: number;
  max: number;
  size?: number;
  stroke?: number;
  from?: string;
  to?: string;
  children?: ReactNode;
}) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const ratio = max > 0 ? Math.min(1, value / max) : 0;
  const id = `ring-${from.replace("#", "")}-${to.replace("#", "")}`;
  return (
    <div className="relative grid place-items-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <defs>
          <linearGradient id={id} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={from} />
            <stop offset="100%" stopColor={to} />
          </linearGradient>
        </defs>
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke="rgba(255,255,255,0.09)"
          strokeWidth={stroke}
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={`url(#${id})`}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={c * (1 - ratio)}
          style={{ transition: "stroke-dashoffset 900ms cubic-bezier(0.22,1,0.36,1)" }}
        />
      </svg>
      <div className="absolute inset-0 grid place-items-center text-center">{children}</div>
    </div>
  );
}

export function Bar({
  value,
  max,
  color = "linear-gradient(90deg,#a78bfa,#22d3ee)",
  className,
}: {
  value: number;
  max: number;
  color?: string;
  className?: string;
}) {
  const ratio = max > 0 ? Math.min(1, value / max) : 0;
  return (
    <div className={cn("glass-inset h-2 w-full overflow-hidden rounded-full", className)}>
      <div
        className="h-full rounded-full"
        style={{
          width: `${ratio * 100}%`,
          background: color,
          transition: "width 800ms cubic-bezier(0.22,1,0.36,1)",
          boxShadow: "0 0 14px rgba(167,139,250,0.55)",
        }}
      />
    </div>
  );
}

export function Stat({
  label,
  value,
  unit,
  delta,
  tone = "neutral",
  className,
}: {
  label: string;
  value: string | number;
  unit?: string;
  delta?: string;
  tone?: "neutral" | "good" | "warn" | "bad";
  className?: string;
}) {
  return (
    <div className={cn("glass-soft rounded-2xl px-3.5 py-3", className)}>
      <p className="text-[11px] font-medium uppercase tracking-[0.06em] text-mist/75">{label}</p>
      <p className="mt-1 flex items-baseline gap-1 text-[22px] font-semibold leading-none text-white">
        {value}
        {unit ? <span className="text-[12px] font-medium text-mist">{unit}</span> : null}
      </p>
      {delta ? (
        <p
          className={cn(
            "mt-1.5 text-[11.5px] font-medium",
            tone === "good" && "text-lime-glow",
            tone === "warn" && "text-amber-glow",
            tone === "bad" && "text-rose-glow",
            tone === "neutral" && "text-mist",
          )}
        >
          {delta}
        </p>
      ) : null}
    </div>
  );
}

export function Spinner({ className }: { className?: string }) {
  return (
    <span
      className={cn(
        "spin inline-block size-4 rounded-full border-2 border-white/25 border-t-white",
        className,
      )}
    />
  );
}

export function EmptyState({
  icon,
  title,
  hint,
  action,
}: {
  icon?: ReactNode;
  title: string;
  hint?: string;
  action?: ReactNode;
}) {
  return (
    <div className="glass-soft flex flex-col items-center gap-3 rounded-3xl px-6 py-10 text-center">
      {icon ? <span className="text-violet-glow/80">{icon}</span> : null}
      <div>
        <p className="text-[15px] font-semibold text-white">{title}</p>
        {hint ? <p className="mx-auto mt-1 max-w-sm text-[12.5px] text-mist">{hint}</p> : null}
      </div>
      {action}
    </div>
  );
}

export function Skeleton({ className }: { className?: string }) {
  return <div className={cn("shimmer rounded-2xl", className)} />;
}

export function ToneDot({ tone }: { tone?: string }) {
  const map: Record<string, string> = {
    good: "bg-lime-glow shadow-[0_0_12px_#a6f97c]",
    warn: "bg-amber-glow shadow-[0_0_12px_#ffce6b]",
    bad: "bg-rose-glow shadow-[0_0_12px_#ff8fb1]",
  };
  return <span className={cn("size-2 shrink-0 rounded-full", map[tone ?? "good"] ?? map.good)} />;
}
