"use client";

import { useEffect, useMemo, useState } from "react";
import { GripVertical, Plus, Save, Trash2 } from "lucide-react";
import { api, patch, post } from "@/lib/client";
import type { ExerciseCatalogItem, WorkoutDTO } from "@/lib/types";
import { Btn, Field, Input, Select, Sheet, Textarea } from "@/components/ui";
import { MUSCLE_LABELS, MUSCLE_ORDER, todayISO } from "@/lib/utils";

interface EditableSet {
  key: string;
  weightKg: string;
  reps: string;
  rpe: string;
  durationSeconds: string;
  isWarmup: boolean;
}

interface EditableExercise {
  key: string;
  exerciseName: string;
  muscleGroup: string;
  exerciseId: number | null;
  sets: EditableSet[];
}

const uid = () => Math.random().toString(36).slice(2, 9);

const emptySet = (): EditableSet => ({
  key: uid(),
  weightKg: "",
  reps: "",
  rpe: "",
  durationSeconds: "",
  isWarmup: false,
});

const emptyExercise = (): EditableExercise => ({
  key: uid(),
  exerciseName: "",
  muscleGroup: "chest",
  exerciseId: null,
  sets: [emptySet(), emptySet(), emptySet()],
});

export function WorkoutEditor({
  open,
  onClose,
  onSaved,
  initial,
}: {
  open: boolean;
  onClose: () => void;
  onSaved: () => void;
  initial?: WorkoutDTO | null;
}) {
  const [date, setDate] = useState(todayISO());
  const [title, setTitle] = useState("");
  const [focus, setFocus] = useState("push");
  const [duration, setDuration] = useState("");
  const [feeling, setFeeling] = useState<number>(4);
  const [notes, setNotes] = useState("");
  const [list, setList] = useState<EditableExercise[]>([emptyExercise()]);
  const [catalog, setCatalog] = useState<ExerciseCatalogItem[]>([]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!open) return;
    api<{ exercises: ExerciseCatalogItem[] }>("/api/exercises")
      .then((r) => setCatalog(r.exercises))
      .catch(() => setCatalog([]));
  }, [open]);

  useEffect(() => {
    if (!open) return;
    setError(null);
    if (initial) {
      setDate(initial.date);
      setTitle(initial.title);
      setFocus(initial.focus ?? "push");
      setDuration(initial.durationMinutes ? String(initial.durationMinutes) : "");
      setFeeling(initial.feeling ?? 4);
      setNotes(initial.notes ?? "");
      setList(
        initial.exercises.length
          ? initial.exercises.map((e) => ({
              key: uid(),
              exerciseName: e.exerciseName,
              muscleGroup: e.muscleGroup,
              exerciseId: e.exerciseId,
              sets: e.sets.length
                ? e.sets.map((s) => ({
                    key: uid(),
                    weightKg: s.weightKg ? String(s.weightKg) : "",
                    reps: s.reps ? String(s.reps) : "",
                    rpe: s.rpe ? String(s.rpe) : "",
                    durationSeconds: s.durationSeconds ? String(s.durationSeconds) : "",
                    isWarmup: s.isWarmup,
                  }))
                : [emptySet()],
            }))
          : [emptyExercise()],
      );
    } else {
      setDate(todayISO());
      setTitle("");
      setFocus("push");
      setDuration("");
      setFeeling(4);
      setNotes("");
      setList([emptyExercise()]);
    }
  }, [open, initial]);

  const grouped = useMemo(() => {
    const map = new Map<string, ExerciseCatalogItem[]>();
    for (const c of catalog) {
      const arr = map.get(c.muscleGroup) ?? [];
      arr.push(c);
      map.set(c.muscleGroup, arr);
    }
    return map;
  }, [catalog]);

  const totals = useMemo(() => {
    let volume = 0;
    let sets = 0;
    for (const ex of list) {
      for (const s of ex.sets) {
        if (s.isWarmup) continue;
        volume += (Number(s.weightKg) || 0) * (Number(s.reps) || 0) + (Number(s.durationSeconds) || 0) * 0.1;
        sets += 1;
      }
    }
    return { volume: Math.round(volume), sets };
  }, [list]);

  function updateExercise(key: string, patchObj: Partial<EditableExercise>) {
    setList((prev) => prev.map((e) => (e.key === key ? { ...e, ...patchObj } : e)));
  }

  function updateSet(exKey: string, setKey: string, patchObj: Partial<EditableSet>) {
    setList((prev) =>
      prev.map((e) =>
        e.key === exKey
          ? { ...e, sets: e.sets.map((s) => (s.key === setKey ? { ...s, ...patchObj } : s)) }
          : e,
      ),
    );
  }

  async function save() {
    const payload = {
      date,
      title: title.trim() || defaultTitle(focus),
      focus,
      durationMinutes: duration ? Number(duration) : null,
      notes,
      feeling,
      exercises: list
        .filter((e) => e.exerciseName.trim())
        .map((e) => ({
          exerciseId: e.exerciseId,
          exerciseName: e.exerciseName.trim(),
          muscleGroup: e.muscleGroup,
          sets: e.sets
            .filter((s) => Number(s.weightKg) > 0 || Number(s.reps) > 0 || Number(s.durationSeconds) > 0)
            .map((s) => ({
              weightKg: Number(s.weightKg) || 0,
              reps: Number(s.reps) || 0,
              rpe: s.rpe ? Number(s.rpe) : null,
              durationSeconds: s.durationSeconds ? Number(s.durationSeconds) : null,
              isWarmup: s.isWarmup,
            })),
        })),
    };

    if (!payload.exercises.length) {
      setError("Добавьте хотя бы одно упражнение");
      return;
    }

    setSaving(true);
    setError(null);
    try {
      if (initial) await patch(`/api/workouts/${initial.id}`, payload);
      else await post("/api/workouts", payload);
      onSaved();
      onClose();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Не удалось сохранить");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Sheet
      open={open}
      onClose={onClose}
      wide
      title={initial ? "Редактировать тренировку" : "Новая тренировка"}
      subtitle={`${totals.sets} рабочих подходов · объём ${totals.volume.toLocaleString("ru-RU")} кг`}
      footer={
        <div className="flex items-center gap-3">
          {error ? (
            <span className="flex-1 text-[12px] text-rose-glow">{error}</span>
          ) : (
            <span className="flex-1 text-[11.5px] text-mist">
              Объём считается автоматически: вес × повторения
            </span>
          )}
          <Btn onClick={onClose}>Отмена</Btn>
          <Btn variant="primary" onClick={() => void save()} disabled={saving}>
            <Save className="size-4" /> {saving ? "Сохраняем…" : "Сохранить"}
          </Btn>
        </div>
      }
    >
      <div className="space-y-5">
        <div className="grid gap-3.5 sm:grid-cols-2 lg:grid-cols-4">
          <Field label="Дата">
            <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
          </Field>
          <Field label="Название">
            <Input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder={defaultTitle(focus)}
            />
          </Field>
          <Field label="Направление">
            <Select value={focus} onChange={(e) => setFocus(e.target.value)}>
              <option value="push">Жим (грудь/плечи/трицепс)</option>
              <option value="pull">Тяга (спина/бицепс)</option>
              <option value="legs">Ноги</option>
              <option value="upper">Верх тела</option>
              <option value="lower">Низ тела</option>
              <option value="full">Всё тело</option>
              <option value="cardio">Кардио</option>
            </Select>
          </Field>
          <Field label="Длительность, мин">
            <Input
              type="number"
              inputMode="numeric"
              value={duration}
              onChange={(e) => setDuration(e.target.value)}
              placeholder="60"
            />
          </Field>
        </div>

        <div>
          <p className="mb-1.5 text-[11.5px] font-medium uppercase tracking-[0.07em] text-mist/80">
            Самочувствие
          </p>
          <div className="flex gap-2">
            {[1, 2, 3, 4, 5].map((v) => (
              <button
                key={v}
                type="button"
                onClick={() => setFeeling(v)}
                className={
                  "h-10 flex-1 rounded-2xl border text-[13px] font-semibold transition-all duration-300 " +
                  (feeling === v
                    ? "tab-active-glow border-white/30 bg-gradient-to-b from-white/20 to-white/8 text-white"
                    : "border-white/8 bg-white/[0.03] text-mist hover:text-white/80")
                }
              >
                {v}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-3">
          {list.map((ex, exIdx) => (
            <div key={ex.key} className="glass-soft rounded-3xl p-4">
              <div className="flex items-start gap-3">
                <span className="mt-2 hidden text-mist/40 sm:block">
                  <GripVertical className="size-4" />
                </span>
                <div className="grid flex-1 gap-3 sm:grid-cols-[1.6fr_1fr]">
                  <Field label={`Упражнение ${exIdx + 1}`}>
                    <Input
                      list={`catalog-${ex.key}`}
                      value={ex.exerciseName}
                      placeholder="Начните вводить или выберите"
                      onChange={(e) => {
                        const name = e.target.value;
                        const match = catalog.find(
                          (c) => c.name.toLowerCase() === name.toLowerCase(),
                        );
                        updateExercise(ex.key, {
                          exerciseName: name,
                          exerciseId: match?.id ?? null,
                          muscleGroup: match?.muscleGroup ?? ex.muscleGroup,
                        });
                      }}
                    />
                    <datalist id={`catalog-${ex.key}`}>
                      {catalog.map((c) => (
                        <option key={c.id} value={c.name} />
                      ))}
                    </datalist>
                  </Field>
                  <Field label="Группа">
                    <Select
                      value={ex.muscleGroup}
                      onChange={(e) => updateExercise(ex.key, { muscleGroup: e.target.value })}
                    >
                      {MUSCLE_ORDER.map((m) => (
                        <option key={m} value={m}>
                          {MUSCLE_LABELS[m]}
                        </option>
                      ))}
                    </Select>
                  </Field>
                </div>
                <Btn
                  size="icon"
                  variant="subtle"
                  className="mt-6"
                  title="Удалить упражнение"
                  onClick={() => setList((prev) => prev.filter((e) => e.key !== ex.key))}
                >
                  <Trash2 className="size-4 text-rose-glow/80" />
                </Btn>
              </div>

              {grouped.get(ex.muscleGroup)?.length && !ex.exerciseName ? (
                <div className="scroll-x mt-3 flex gap-2 overflow-x-auto pb-1">
                  {grouped.get(ex.muscleGroup)!.slice(0, 10).map((c) => (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() =>
                        updateExercise(ex.key, {
                          exerciseName: c.name,
                          exerciseId: c.id,
                          muscleGroup: c.muscleGroup,
                        })
                      }
                      className="shrink-0 rounded-full border border-white/8 bg-white/[0.04] px-3 py-1.5 text-[12px] text-mist transition-colors hover:border-white/20 hover:text-white"
                    >
                      {c.name}
                    </button>
                  ))}
                </div>
              ) : null}

              <div className="mt-4 space-y-1.5">
                <div className="grid grid-cols-[36px_1fr_1fr_74px_58px_36px] items-center gap-2 px-1 text-[10.5px] uppercase tracking-[0.06em] text-mist/70">
                  <span>№</span>
                  <span>Вес, кг</span>
                  <span>Повторы</span>
                  <span>RPE</span>
                  <span>Разм.</span>
                  <span />
                </div>
                {ex.sets.map((s, i) => (
                  <div
                    key={s.key}
                    className="grid grid-cols-[36px_1fr_1fr_74px_58px_36px] items-center gap-2"
                  >
                    <span
                      className={
                        "grid size-8 place-items-center rounded-xl text-[12px] font-semibold " +
                        (s.isWarmup ? "bg-white/6 text-mist" : "bg-violet-glow/16 text-[#cbb8ff]")
                      }
                    >
                      {i + 1}
                    </span>
                    <Input
                      type="number"
                      inputMode="decimal"
                      step="0.5"
                      value={s.weightKg}
                      placeholder="0"
                      onChange={(e) => updateSet(ex.key, s.key, { weightKg: e.target.value })}
                    />
                    <Input
                      type="number"
                      inputMode="numeric"
                      value={s.reps}
                      placeholder="0"
                      onChange={(e) => updateSet(ex.key, s.key, { reps: e.target.value })}
                    />
                    <Input
                      type="number"
                      inputMode="decimal"
                      step="0.5"
                      value={s.rpe}
                      placeholder="—"
                      onChange={(e) => updateSet(ex.key, s.key, { rpe: e.target.value })}
                    />
                    <button
                      type="button"
                      onClick={() => updateSet(ex.key, s.key, { isWarmup: !s.isWarmup })}
                      className={
                        "h-9 rounded-xl border text-[11px] font-semibold transition-colors " +
                        (s.isWarmup
                          ? "border-amber-glow/40 bg-amber-glow/16 text-amber-glow"
                          : "border-white/8 bg-white/[0.03] text-mist")
                      }
                    >
                      {s.isWarmup ? "да" : "нет"}
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        updateExercise(ex.key, { sets: ex.sets.filter((x) => x.key !== s.key) })
                      }
                      className="grid size-8 place-items-center rounded-xl text-mist/60 transition-colors hover:bg-white/8 hover:text-rose-glow"
                    >
                      <Trash2 className="size-3.5" />
                    </button>
                  </div>
                ))}
              </div>

              <div className="mt-3 flex flex-wrap gap-2">
                <Btn
                  size="sm"
                  variant="subtle"
                  onClick={() => {
                    const last = ex.sets[ex.sets.length - 1];
                    updateExercise(ex.key, {
                      sets: [
                        ...ex.sets,
                        {
                          ...emptySet(),
                          weightKg: last?.weightKg ?? "",
                          reps: last?.reps ?? "",
                          rpe: last?.rpe ?? "",
                        },
                      ],
                    });
                  }}
                >
                  <Plus className="size-3.5" /> Подход
                </Btn>
                <Btn
                  size="sm"
                  variant="subtle"
                  onClick={() =>
                    updateExercise(ex.key, {
                      sets: ex.sets.map((s, idx) =>
                        idx === 0
                          ? s
                          : {
                              ...s,
                              weightKg: ex.sets[idx - 1].weightKg,
                              reps: ex.sets[idx - 1].reps,
                            },
                      ),
                    })
                  }
                >
                  Копировать предыдущий
                </Btn>
              </div>
            </div>
          ))}

          <Btn onClick={() => setList((prev) => [...prev, emptyExercise()])} className="w-full py-3">
            <Plus className="size-4" /> Добавить упражнение
          </Btn>
        </div>

        <Field label="Заметки">
          <Textarea
            rows={3}
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Как прошла тренировка, что мешало, какие ощущения"
          />
        </Field>
      </div>
    </Sheet>
  );
}

function defaultTitle(focus: string) {
  const map: Record<string, string> = {
    push: "Жим / Плечи / Трицепс",
    pull: "Спина / Бицепс",
    legs: "Ноги / Кор",
    upper: "Верх тела",
    lower: "Низ тела",
    full: "Всё тело",
    cardio: "Кардио",
  };
  return map[focus] ?? "Тренировка";
}
