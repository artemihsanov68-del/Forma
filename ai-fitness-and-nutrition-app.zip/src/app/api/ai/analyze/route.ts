import { NextResponse } from "next/server";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { aiAnalyses } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { KIND_META, buildContext, generateAnalysis, type AnalysisKind } from "@/lib/coach";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

const KINDS: AnalysisKind[] = ["training", "nutrition", "body", "full"];

export async function POST(req: Request) {
  await ensureSeeded();
  const body = (await req.json().catch(() => ({}))) as { kind?: string };
  const kind = (KINDS.includes(body.kind as AnalysisKind) ? body.kind : "full") as AnalysisKind;

  const ctx = await buildContext();
  const meta = KIND_META[kind];
  const periodLabel =
    kind === "nutrition"
      ? `последние ${ctx.nutrition.loggedDays} дней учёта`
      : kind === "body"
        ? `${ctx.body.measurementCount} замеров`
        : `${ctx.training.workoutCount} тренировок за ${ctx.training.days} дней`;

  const { result, prompt, raw, metrics, dataSnapshot, durationMs } = await generateAnalysis(kind, ctx);

  const [saved] = await db
    .insert(aiAnalyses)
    .values({
      kind,
      title: meta.title,
      periodLabel,
      provider: result.provider,
      model: result.model,
      online: result.online,
      prompt: prompt.slice(0, 60000),
      rawResponse: raw?.slice(0, 60000) ?? null,
      summary: result.summary,
      score: result.score,
      highlights: result.highlights,
      insights: result.insights,
      recommendations: result.recommendations,
      plan: result.plan,
      metrics,
      dataSnapshot,
      durationMs,
      error: result.error ?? null,
    })
    .returning();

  const recent = await db
    .select({
      id: aiAnalyses.id,
      kind: aiAnalyses.kind,
      title: aiAnalyses.title,
      score: aiAnalyses.score,
      online: aiAnalyses.online,
      provider: aiAnalyses.provider,
      createdAt: aiAnalyses.createdAt,
    })
    .from(aiAnalyses)
    .orderBy(desc(aiAnalyses.createdAt))
    .limit(20);

  return NextResponse.json({ analysis: saved, recent });
}
