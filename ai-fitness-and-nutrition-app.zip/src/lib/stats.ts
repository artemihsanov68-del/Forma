import { and, asc, desc, eq, gte, inArray } from "drizzle-orm";
import { format, startOfDay, startOfWeek, subDays } from "date-fns";
import { db } from "@/db";
import {
  exerciseSets,
  measurements,
  nutritionEntries,
  profiles,
  workoutExercises,
  workouts,
} from "@/db/schema";
import {
  ACTIVITY_K,
  MEASUREMENT_POINTS,
  ageFrom,
  bestSet,
  calcBMR,
  estimate1RM,
  macroTargets,
} from "@/lib/utils";

export interface SetDTO {
  id: number;
  setNumber: number;
  weightKg: number;
  reps: number;
  rpe: number | null;
  durationSeconds: number | null;
  distanceKm: number | null;
  isWarmup: boolean;
}

export interface ExerciseDTO {
  id: number;
  exerciseName: string;
  muscleGroup: string;
  sortOrder: number;
  exerciseId: number | null;
  sets: SetDTO[];
  volume: number;
  bestE1rm: number;
}

export interface WorkoutDTO {
  id: number;
  date: string;
  title: string;
  focus: string | null;
  durationMinutes: number | null;
  notes: string | null;
  feeling: number | null;
  totalVolume: number;
  totalSets: number;
  exercises: ExerciseDTO[];
}

const num = (v: unknown) => (typeof v === "number" && Number.isFinite(v) ? v : 0);

const countWorking = (e: { sets: SetDTO[] }) => e.sets.filter((s) => !s.isWarmup).length;

export async function getWorkoutsDetailed(opts?: { limit?: number; fromDate?: string }) {
  const conditions = [];
  if (opts?.fromDate) conditions.push(gte(workouts.date, opts.fromDate));
  const rows = await db
    .select()
    .from(workouts)
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(workouts.date), desc(workouts.id))
    .limit(opts?.limit ?? 600);

  if (rows.length === 0) return [] as WorkoutDTO[];
  const ids = rows.map((r) => r.id);

  const exRows = await db
    .select()
    .from(workoutExercises)
    .where(inArray(workoutExercises.workoutId, ids))
    .orderBy(asc(workoutExercises.sortOrder), asc(workoutExercises.id));

  const setRows = exRows.length
    ? await db
        .select()
        .from(exerciseSets)
        .where(
          inArray(
            exerciseSets.workoutExerciseId,
            exRows.map((e) => e.id),
          ),
        )
        .orderBy(asc(exerciseSets.setNumber), asc(exerciseSets.id))
    : [];

  const setsByEx = new Map<number, SetDTO[]>();
  for (const s of setRows) {
    const list = setsByEx.get(s.workoutExerciseId) ?? [];
    list.push({
      id: s.id,
      setNumber: s.setNumber,
      weightKg: num(s.weightKg),
      reps: s.reps ?? 0,
      rpe: s.rpe,
      durationSeconds: s.durationSeconds,
      distanceKm: s.distanceKm,
      isWarmup: s.isWarmup,
    });
    setsByEx.set(s.workoutExerciseId, list);
  }

  const exByWorkout = new Map<number, ExerciseDTO[]>();
  for (const e of exRows) {
    const sets = setsByEx.get(e.id) ?? [];
    const volume = sets
      .filter((s) => !s.isWarmup)
      .reduce((acc, s) => acc + s.weightKg * s.reps + (s.durationSeconds ?? 0) * 0.1, 0);
    const best = bestSet(sets);
    const dto: ExerciseDTO = {
      id: e.id,
      exerciseName: e.exerciseName,
      muscleGroup: e.muscleGroup,
      sortOrder: e.sortOrder,
      exerciseId: e.exerciseId,
      sets,
      volume: Math.round(volume),
      bestE1rm: best ? estimate1RM(best.weightKg, best.reps) : 0,
    };
    const list = exByWorkout.get(e.workoutId) ?? [];
    list.push(dto);
    exByWorkout.set(e.workoutId, list);
  }

  return rows.map<WorkoutDTO>((w) => {
    const exs = exByWorkout.get(w.id) ?? [];
    return {
      id: w.id,
      date: w.date,
      title: w.title,
      focus: w.focus,
      durationMinutes: w.durationMinutes,
      notes: w.notes,
      feeling: w.feeling,
      totalVolume: Math.round(w.totalVolume || 0),
      totalSets: exs.reduce((a, e) => a + countWorking(e), 0),
      exercises: exs,
    };
  });
}

export async function getProfileWithTargets() {
  const [profile] = await db.select().from(profiles).limit(1);
  const latestMeasurement = await db
    .select()
    .from(measurements)
    .orderBy(desc(measurements.date))
    .limit(1);
  const weight = latestMeasurement[0]?.weightKg ?? profile?.weightKg ?? 80;
  const age = ageFrom(profile?.birthDate);
  const bmr = calcBMR(profile?.sex ?? "male", weight, profile?.heightCm ?? 178, age);
  const tdee = Math.round(bmr * (ACTIVITY_K[profile?.activityLevel ?? "moderate"] ?? 1.55));
  const suggested = macroTargets(profile?.goal ?? "recomp", tdee);
  return {
    profile,
    weight,
    age,
    bmr,
    tdee,
    targets: {
      calories: profile?.targetCalories ?? suggested.calories,
      protein: profile?.targetProtein ?? suggested.protein,
      fat: profile?.targetFat ?? suggested.fat,
      carbs: profile?.targetCarbs ?? suggested.carbs,
      suggested,
    },
  };
}

export interface ProgressionEntry {
  exercise: string;
  muscleGroup: string;
  sessions: number;
  firstValue: number;
  lastValue: number;
  changePct: number;
  topWeight: number;
  trend: "up" | "down" | "flat";
  stalled: boolean;
  unit: "kg" | "sec";
  history: Array<{ date: string; e1rm: number; topWeight: number; reps: number; volume: number; seconds: number }>;
}

export interface TrainingSummary {
  days: number;
  workoutCount: number;
  workoutsPerWeek: number;
  totalVolume: number;
  avgVolume: number;
  totalSets: number;
  avgSetsPerWorkout: number;
  avgDuration: number;
  avgFeeling: number;
  weeklyVolume: number;
  prevWeeklyVolume: number;
  volumeTrendPct: number;
  daysSinceLastWorkout: number | null;
  muscleSplit: Array<{ group: string; sets: number; volume: number; share: number }>;
  weeklySeries: Array<{ week: string; volume: number; sets: number; workouts: number }>;
  progression: ProgressionEntry[];
  personalRecords: Array<{ exercise: string; e1rm: number; weightKg: number; reps: number; date: string }>;
  lastWorkout?: { date: string; title: string; volume: number; sets: number };
}

export async function buildTrainingSummary(days = 90): Promise<TrainingSummary> {
  const since = format(subDays(startOfDay(new Date()), days), "yyyy-MM-dd");
  const list = await getWorkoutsDetailed({ fromDate: since });
  const ordered = [...list].sort((a, b) => a.date.localeCompare(b.date) || a.id - b.id);

  const totalVolume = ordered.reduce((a, w) => a + w.totalVolume, 0);
  const totalSets = ordered.reduce((a, w) => a + w.totalSets, 0);
  const durations = ordered.map((w) => w.durationMinutes).filter((v): v is number => !!v);
  const feelings = ordered.map((w) => w.feeling).filter((v): v is number => !!v);

  const weekMap = new Map<string, { volume: number; sets: number; workouts: number }>();
  for (const w of ordered) {
    const key = format(
      startOfWeek(new Date(`${w.date}T12:00:00`), { weekStartsOn: 1 }),
      "yyyy-MM-dd",
    );
    const cur = weekMap.get(key) ?? { volume: 0, sets: 0, workouts: 0 };
    cur.volume += w.totalVolume;
    cur.sets += w.totalSets;
    cur.workouts += 1;
    weekMap.set(key, cur);
  }
  const weeklySeries = [...weekMap.entries()]
    .sort((a, b) => a[0].localeCompare(b[0]))
    .map(([week, v]) => ({ week, ...v }));

  const muscleMap = new Map<string, { sets: number; volume: number }>();
  for (const w of ordered) {
    for (const e of w.exercises) {
      const cur = muscleMap.get(e.muscleGroup) ?? { sets: 0, volume: 0 };
      cur.sets += countWorking(e);
      cur.volume += e.volume;
      muscleMap.set(e.muscleGroup, cur);
    }
  }
  const muscleSetsTotal = [...muscleMap.values()].reduce((a, m) => a + m.sets, 0) || 1;
  const muscleSplit = [...muscleMap.entries()]
    .map(([group, v]) => ({
      group,
      sets: v.sets,
      volume: Math.round(v.volume),
      share: Math.round((v.sets / muscleSetsTotal) * 100),
    }))
    .sort((a, b) => b.sets - a.sets);

  const exMap = new Map<string, { muscleGroup: string; history: ProgressionEntry["history"] }>();
  for (const w of ordered) {
    for (const e of w.exercises) {
      const best = bestSet(e.sets);
      const entry = exMap.get(e.exerciseName) ?? { muscleGroup: e.muscleGroup, history: [] };
      const seconds = e.sets.reduce((a, s) => Math.max(a, s.durationSeconds ?? 0), 0);
      if (best) {
        entry.history.push({
          date: w.date,
          e1rm: estimate1RM(best.weightKg, best.reps),
          topWeight: best.weightKg,
          reps: best.reps,
          volume: e.volume,
          seconds,
        });
      } else if (seconds > 0) {
        entry.history.push({ date: w.date, e1rm: 0, topWeight: 0, reps: 0, volume: seconds, seconds });
      }
      entry.muscleGroup = e.muscleGroup;
      exMap.set(e.exerciseName, entry);
    }
  }

  const progression: ProgressionEntry[] = [...exMap.entries()]
    .map(([exercise, v]) => {
      const h = v.history;
      const unit: "kg" | "sec" = h.some((p) => p.e1rm > 0) ? "kg" : "sec";
      const val = (p: ProgressionEntry["history"][number]) => (unit === "kg" ? p.e1rm : p.seconds);
      const firstVal = val(h[0]);
      const lastVal = val(h[h.length - 1]);
      const changePct = firstVal > 0 ? Math.round(((lastVal - firstVal) / firstVal) * 1000) / 10 : 0;
      const tail = h.slice(-3).map(val);
      const base = tail[0] || firstVal || 1;
      const spread = tail.length >= 3 ? (Math.max(...tail) - Math.min(...tail)) / base : 0;
      const recentChange =
        tail.length >= 2 ? (tail[tail.length - 1] - tail[0]) / base : changePct / 100;
      // Плато = последние 3 сессии почти не отличаются И нет роста
      const stalled = spread < 0.02 && Math.abs(recentChange) < 0.015;
      return {
        exercise,
        muscleGroup: v.muscleGroup,
        sessions: h.length,
        firstValue: Math.round(firstVal * 10) / 10,
        lastValue: Math.round(lastVal * 10) / 10,
        changePct,
        topWeight: Math.max(...h.map((p) => p.topWeight), 0),
        trend: (changePct > 1.5 ? "up" : changePct < -1.5 ? "down" : "flat") as "up" | "down" | "flat",
        stalled,
        unit,
        history: h,
      };
    })
    .sort((a, b) => b.sessions - a.sessions || b.changePct - a.changePct);

  const prMap = new Map<string, { e1rm: number; weightKg: number; reps: number; date: string }>();
  for (const p of progression) {
    for (const h of p.history) {
      if (h.e1rm <= 0) continue;
      const cur = prMap.get(p.exercise);
      if (!cur || h.e1rm > cur.e1rm) {
        prMap.set(p.exercise, { e1rm: h.e1rm, weightKg: h.topWeight, reps: h.reps, date: h.date });
      }
    }
  }

  const weeks = Math.max(1, days / 7);
  const lastTwo = weeklySeries.slice(-2);
  const weeklyVolume = lastTwo.length ? lastTwo[lastTwo.length - 1].volume : 0;
  const prevWeeklyVolume = lastTwo.length === 2 ? lastTwo[0].volume : 0;
  const last = ordered[ordered.length - 1];

  return {
    days,
    workoutCount: ordered.length,
    workoutsPerWeek: Math.round((ordered.length / weeks) * 10) / 10,
    totalVolume,
    avgVolume: ordered.length ? Math.round(totalVolume / ordered.length) : 0,
    totalSets,
    avgSetsPerWorkout: ordered.length ? Math.round((totalSets / ordered.length) * 10) / 10 : 0,
    avgDuration: durations.length
      ? Math.round(durations.reduce((a, b) => a + b, 0) / durations.length)
      : 0,
    avgFeeling: feelings.length
      ? Math.round((feelings.reduce((a, b) => a + b, 0) / feelings.length) * 10) / 10
      : 0,
    weeklyVolume,
    prevWeeklyVolume,
    volumeTrendPct:
      prevWeeklyVolume > 0
        ? Math.round(((weeklyVolume - prevWeeklyVolume) / prevWeeklyVolume) * 100)
        : 0,
    daysSinceLastWorkout: last
      ? Math.round((Date.now() - new Date(`${last.date}T12:00:00`).getTime()) / 86400000)
      : null,
    muscleSplit,
    weeklySeries,
    progression,
    personalRecords: [...prMap.entries()]
      .map(([exercise, v]) => ({ exercise, ...v }))
      .sort((a, b) => b.e1rm - a.e1rm),
    lastWorkout: last
      ? { date: last.date, title: last.title, volume: last.totalVolume, sets: last.totalSets }
      : undefined,
  };
}

export interface NutritionSummary {
  days: number;
  loggedDays: number;
  avgCalories: number;
  avgProtein: number;
  avgFat: number;
  avgCarbs: number;
  proteinPerKg: number;
  fatSharePct: number;
  targetCalories: number;
  targetProtein: number;
  calorieAdherencePct: number;
  proteinAdherencePct: number;
  daysUnderTarget: number;
  daysOverTarget: number;
  weeklyDeltaKcal: number;
  weight: number;
  dailySeries: Array<{ date: string; kcal: number; protein: number; fat: number; carbs: number }>;
  todayTotal: { kcal: number; protein: number; fat: number; carbs: number };
}

export async function buildNutritionSummary(days = 30): Promise<NutritionSummary> {
  const since = format(subDays(startOfDay(new Date()), days - 1), "yyyy-MM-dd");
  const rows = await db
    .select()
    .from(nutritionEntries)
    .where(gte(nutritionEntries.date, since))
    .orderBy(asc(nutritionEntries.date));

  const byDate = new Map<string, { kcal: number; protein: number; fat: number; carbs: number }>();
  for (const r of rows) {
    const cur = byDate.get(r.date) ?? { kcal: 0, protein: 0, fat: 0, carbs: 0 };
    cur.kcal += num(r.kcal);
    cur.protein += num(r.protein);
    cur.fat += num(r.fat);
    cur.carbs += num(r.carbs);
    byDate.set(r.date, cur);
  }

  const dailySeries = [...byDate.entries()]
    .sort((a, b) => a[0].localeCompare(b[0]))
    .map(([date, v]) => ({
      date,
      kcal: Math.round(v.kcal),
      protein: Math.round(v.protein),
      fat: Math.round(v.fat),
      carbs: Math.round(v.carbs),
    }));

  const { targets, weight } = await getProfileWithTargets();
  const count = dailySeries.length || 1;
  const sum = (k: "kcal" | "protein" | "fat" | "carbs") =>
    dailySeries.reduce((a, d) => a + d[k], 0);
  const avgCalories = Math.round(sum("kcal") / count);
  const avgProtein = Math.round(sum("protein") / count);
  const avgFat = Math.round(sum("fat") / count);
  const avgCarbs = Math.round(sum("carbs") / count);

  const half = Math.floor(dailySeries.length / 2);
  const avgKcal = (arr: typeof dailySeries) =>
    arr.length ? arr.reduce((a, d) => a + d.kcal, 0) / arr.length : 0;
  const today = byDate.get(format(new Date(), "yyyy-MM-dd")) ?? {
    kcal: 0,
    protein: 0,
    fat: 0,
    carbs: 0,
  };

  return {
    days,
    loggedDays: dailySeries.length,
    avgCalories,
    avgProtein,
    avgFat,
    avgCarbs,
    proteinPerKg: weight ? Math.round((avgProtein / weight) * 100) / 100 : 0,
    fatSharePct: avgCalories ? Math.round(((avgFat * 9) / avgCalories) * 100) : 0,
    targetCalories: targets.calories,
    targetProtein: targets.protein,
    calorieAdherencePct: targets.calories ? Math.round((avgCalories / targets.calories) * 100) : 0,
    proteinAdherencePct: targets.protein ? Math.round((avgProtein / targets.protein) * 100) : 0,
    daysUnderTarget: dailySeries.filter((d) => d.kcal < targets.calories * 0.95).length,
    daysOverTarget: dailySeries.filter((d) => d.kcal > targets.calories * 1.05).length,
    weeklyDeltaKcal: Math.round(
      avgKcal(dailySeries.slice(half)) - avgKcal(dailySeries.slice(0, half)),
    ),
    weight,
    dailySeries,
    todayTotal: {
      kcal: Math.round(today.kcal),
      protein: Math.round(today.protein),
      fat: Math.round(today.fat),
      carbs: Math.round(today.carbs),
    },
  };
}

export interface BodyChange {
  key: string;
  label: string;
  latest: number | null;
  first: number | null;
  delta: number | null;
}

export interface BodySummary {
  latest?: Record<string, number | string | null>;
  series: Array<Record<string, string | number | null>>;
  changes: BodyChange[];
  ratio: number | null;
  measurementCount: number;
  daysSinceLast: number | null;
  bodyFatDelta: number | null;
}

export async function buildBodySummary(): Promise<BodySummary> {
  const rows = await db.select().from(measurements).orderBy(asc(measurements.date));
  const series = rows.map((r) => {
    const obj: Record<string, string | number | null> = { date: r.date };
    for (const p of MEASUREMENT_POINTS) {
      obj[p.key] = (r as unknown as Record<string, number | null>)[p.key] ?? null;
    }
    obj.bodyFat = r.bodyFat ?? null;
    return obj;
  });

  const first = rows[0];
  const latest = rows[rows.length - 1];
  const pick = (row: (typeof rows)[number] | undefined, key: string) =>
    row ? ((row as unknown as Record<string, number | null>)[key] ?? null) : null;

  const changes: BodyChange[] = MEASUREMENT_POINTS.map((p) => {
    const l = pick(latest, p.key);
    const f = pick(first, p.key);
    return {
      key: p.key,
      label: p.label,
      latest: l,
      first: f,
      delta: l !== null && f !== null ? Math.round((l - f) * 10) / 10 : null,
    };
  });

  let latestRecord: Record<string, number | string | null> | undefined;
  if (latest) {
    latestRecord = { date: latest.date, notes: latest.notes, bodyFat: latest.bodyFat };
    for (const p of MEASUREMENT_POINTS) {
      latestRecord[p.key] = (latest as unknown as Record<string, number | null>)[p.key] ?? null;
    }
  }

  const ratio =
    latest?.shoulders && latest?.waist
      ? Math.round((latest.shoulders / latest.waist) * 100) / 100
      : null;

  const bfFirst = pick(first, "bodyFat");
  const bfLast = pick(latest, "bodyFat");

  return {
    latest: latestRecord,
    series,
    changes,
    ratio,
    measurementCount: rows.length,
    daysSinceLast: latest
      ? Math.round((Date.now() - new Date(`${latest.date}T12:00:00`).getTime()) / 86400000)
      : null,
    bodyFatDelta: bfFirst !== null && bfLast !== null ? Math.round((bfLast - bfFirst) * 10) / 10 : null,
  };
}

export async function getNutritionForDate(dateISO: string) {
  const rows = await db
    .select()
    .from(nutritionEntries)
    .where(eq(nutritionEntries.date, dateISO))
    .orderBy(asc(nutritionEntries.id));
  const totals = rows.reduce(
    (acc, r) => ({
      kcal: acc.kcal + num(r.kcal),
      protein: acc.protein + num(r.protein),
      fat: acc.fat + num(r.fat),
      carbs: acc.carbs + num(r.carbs),
    }),
    { kcal: 0, protein: 0, fat: 0, carbs: 0 },
  );
  return {
    entries: rows,
    totals: {
      kcal: Math.round(totals.kcal),
      protein: Math.round(totals.protein * 10) / 10,
      fat: Math.round(totals.fat * 10) / 10,
      carbs: Math.round(totals.carbs * 10) / 10,
    },
  };
}
