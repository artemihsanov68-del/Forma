"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import {
  ArrowRight,
  Database,
  CalendarPlus,
  Dumbbell,
  Flame,
  LineChart,
  Ruler,
  Salad,
  Settings2,
  Smartphone,
  Sparkles,
  TrendingDown,
  TrendingUp,
  Trophy,
} from "lucide-react";
import { api } from "@/lib/client";
import type { AnalysisDTO, AnalyticsResponse, NutritionEntryDTO } from "@/lib/types";
import { Bar, Btn, Card, EmptyState, Ring, SectionHeading, Skeleton, Stat } from "@/components/ui";
import { BarsChart, TrendChart } from "@/components/charts";
import { ProfileSheet } from "@/components/ProfileSheet";
import { InstallButton } from "@/components/Pwa";
import {
  GOAL_LABELS,
  MEAL_LABELS,
  MUSCLE_LABELS,
  formatDate,
  formatDateFull,
  fmt,
  pct,
  signed,
  todayISO,
} from "@/lib/utils";

interface DayNutrition {
  date: string;
  entries: NutritionEntryDTO[];
  totals: { kcal: number; protein: number; fat: number; carbs: number };
  targets: { calories: number; protein: number; fat: number; carbs: number };
}

const MACRO_COLORS: Array<{ key: "protein" | "fat" | "carbs"; label: string; color: string }> = [
  { key: "protein", label: "Белки", color: "linear-gradient(90deg,#a78bfa,#7c5cff)" },
  { key: "fat", label: "Жиры", color: "linear-gradient(90deg,#ffce6b,#ff9d6b)" },
  { key: "carbs", label: "Углеводы", color: "linear-gradient(90deg,#46e0ff,#5eead4)" },
];

export default function DashboardPage() {
  const [data, setData] = useState<AnalyticsResponse | null>(null);
  const [day, setDay] = useState<DayNutrition | null>(null);
  const [analyses, setAnalyses] = useState<AnalysisDTO[]>([]);
  const [workouts, setWorkouts] = useState<AnalyticsResponse["training"]["progression"]>([]);
  const [recent, setRecent] = useState<Array<{ id: number; date: string; title: string; totalVolume: number; totalSets: number; durationMinutes: number | null }>>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [profileOpen, setProfileOpen] = useState(false);

  async function load() {
    setLoading(true);
    setLoadError(null);
    try {
      const [analytics, dayData, ai, w] = await Promise.all([
        api<AnalyticsResponse>(`/api/analytics?days=90`),
        api<DayNutrition>(`/api/nutrition?date=${todayISO()}`),
        api<{ analyses: AnalysisDTO[] }>("/api/ai/analyses"),
        api<{ workouts: Array<{ id: number; date: string; title: string; totalVolume: number; totalSets: number; durationMinutes: number | null }> }>("/api/workouts?limit=5"),
      ]);
      setData(analytics);
      setDay(dayData);
      setAnalyses(ai.analyses);
      setWorkouts(analytics.training.progression);
      setRecent(w.workouts);
    } catch (err) {
      console.error(err);
      setLoadError(
        err instanceof Error
          ? err.message
          : "Не удалось загрузить данные. Проверьте подключение к базе.",
      );
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void load();
  }, []);

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-64 w-full" />
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {[0, 1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-24 w-full" />
          ))}
        </div>
        <Skeleton className="h-72 w-full" />
      </div>
    );
  }

  if (loadError || !data || !day) {
    return (
      <Card className="p-6 sm:p-8">
        <div className="flex flex-col items-start gap-4">
          <span className="grid size-12 place-items-center rounded-2xl bg-rose-glow/14 text-rose-glow">
            <Database className="size-6" />
          </span>
          <div>
            <h1 className="text-[22px] font-semibold tracking-tight text-white">
              База данных ещё не подключена
            </h1>
            <p className="mt-2 max-w-xl text-[13.5px] leading-relaxed text-mist">
              Приложение не смогло прочитать данные. Обычно это значит, что не задана переменная{" "}
              <code className="rounded bg-white/8 px-1.5 py-0.5 text-[12.5px] text-white/90">
                DATABASE_URL
              </code>{" "}
              или таблицы ещё не созданы. Откройте инструкцию — там есть кнопка, которая создаст все
              таблицы одним нажатием, без терминала.
            </p>
            {loadError ? (
              <p className="mt-3 rounded-2xl bg-white/[0.03] px-4 py-3 text-[12px] leading-relaxed text-mist/85">
                {loadError}
              </p>
            ) : null}
          </div>
          <div className="flex flex-wrap gap-2">
            <Link href="/deploy">
              <Btn variant="primary">
                <Database className="size-4" /> Создать таблицы
              </Btn>
            </Link>
            <Btn onClick={() => void load()}>Повторить попытку</Btn>
          </div>
        </div>
      </Card>
    );
  }

  const { training, nutrition, body, profile } = data;
  const targets = day.targets;
  const left = Math.max(0, targets.calories - day.totals.kcal);
  const lastAnalysis = analyses[0];
  const waist = body.changes.find((c) => c.key === "waist");
  const weightChange = body.changes.find((c) => c.key === "weightKg");
  const topProgress = [...workouts].sort((a, b) => b.changePct - a.changePct).slice(0, 5);

  const hour = new Date().getHours();
  const greeting = hour < 5 ? "Доброй ночи" : hour < 12 ? "Доброе утро" : hour < 18 ? "Добрый день" : "Добрый вечер";

  return (
    <div className="space-y-5">
      <ProfileSheet
        open={profileOpen}
        onClose={() => setProfileOpen(false)}
        profile={profile}
        onSaved={() => void load()}
      />

      {/* Hero */}
      <Card className="overflow-hidden p-5 sm:p-7">
        <div className="flex flex-col gap-7 lg:flex-row lg:items-center lg:justify-between">
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <span className="glass-soft rounded-full px-2.5 py-1 text-[11px] font-medium uppercase tracking-[0.08em] text-mist">
                {formatDateFull(todayISO())}
              </span>
              <span className="rounded-full border border-violet-glow/30 bg-violet-glow/12 px-2.5 py-1 text-[11px] font-medium text-[#cbb8ff]">
                {GOAL_LABELS[profile.profile?.goal ?? "recomp"]}
              </span>
              {profile.ai ? (
                <span className="flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.04] px-2.5 py-1 text-[11px] text-mist">
                  <span
                    className={
                      "size-1.5 rounded-full " +
                      (profile.ai.online ? "bg-lime-glow shadow-[0_0_8px_#a6f97c]" : "bg-cyan-glow shadow-[0_0_8px_#46e0ff]")
                    }
                  />
                  ИИ: {profile.ai.provider}
                </span>
              ) : null}
            </div>

            <h1 className="gradient-text mt-4 text-[30px] font-semibold leading-[1.1] tracking-tight sm:text-[38px]">
              {greeting}, {profile.profile?.name ?? "атлет"}
            </h1>
            <p className="mt-2 max-w-lg text-[13.5px] leading-relaxed text-mist">
              {training.daysSinceLastWorkout === null
                ? "Начните первую тренировку — и здесь появится ваша динамика."
                : training.daysSinceLastWorkout === 0
                  ? "Сегодня уже была тренировка. Отличная работа!"
                  : `Последняя тренировка была ${training.daysSinceLastWorkout} дн. назад. Недельный объём ${fmt(training.weeklyVolume)} кг (${signed(training.volumeTrendPct, 0)}%).`}
            </p>

            <div className="mt-5 flex flex-wrap gap-2">
              <Link href="/workouts?new=1">
                <Btn variant="primary" size="md">
                  <Dumbbell className="size-4" /> Тренировка
                </Btn>
              </Link>
              <Link href="/nutrition?add=1">
                <Btn size="md">
                  <Salad className="size-4" /> Добавить еду
                </Btn>
              </Link>
              <Link href="/body?add=1">
                <Btn size="md">
                  <Ruler className="size-4" /> Замер
                </Btn>
              </Link>
              <Btn size="md" variant="subtle" onClick={() => setProfileOpen(true)}>
                <Settings2 className="size-4" /> Профиль
              </Btn>
            </div>
          </div>

          {/* Calorie ring */}
          <div className="glass-soft flex shrink-0 items-center gap-6 rounded-[28px] p-5">
            <Ring value={day.totals.kcal} max={targets.calories} size={152} stroke={13}>
              <div>
                <p className="text-[10.5px] font-medium uppercase tracking-[0.08em] text-mist/80">
                  ккал
                </p>
                <p className="text-[26px] font-semibold leading-none text-white">
                  {fmt(day.totals.kcal)}
                </p>
                <p className="mt-1 text-[11px] text-mist">из {fmt(targets.calories)}</p>
              </div>
            </Ring>
            <div className="w-[150px] space-y-3">
              {MACRO_COLORS.map((m) => (
                <div key={m.key}>
                  <div className="mb-1 flex items-baseline justify-between">
                    <span className="text-[11.5px] text-mist">{m.label}</span>
                    <span className="text-[12px] font-semibold text-white">
                      {fmt(day.totals[m.key])}
                      <span className="ml-1 text-[10.5px] font-normal text-mist">
                        / {fmt(targets[m.key])} г
                      </span>
                    </span>
                  </div>
                  <Bar value={day.totals[m.key]} max={targets[m.key]} color={m.color} />
                </div>
              ))}
              <p className="pt-1 text-[11px] text-mist">
                {left > 0 ? `Осталось ${fmt(left)} ккал` : `Перебор ${fmt(day.totals.kcal - targets.calories)} ккал`}
              </p>
            </div>
          </div>
        </div>
      </Card>

      {/* Stats */}
      <div className="grid gap-3.5 sm:grid-cols-2 xl:grid-cols-4">
        <Stat
          label="Тренировок за 90 дн."
          value={training.workoutCount}
          unit={`· ${training.workoutsPerWeek}/нед`}
          delta={`${fmt(training.totalVolume)} кг суммарно`}
        />
        <Stat
          label="Недельный объём"
          value={fmt(training.weeklyVolume)}
          unit="кг"
          delta={`${training.volumeTrendPct >= 0 ? "рост" : "спад"} ${signed(training.volumeTrendPct, 0)}% к прошлой неделе`}
          tone={training.volumeTrendPct >= 0 ? "good" : "warn"}
        />
        <Stat
          label="Белок"
          value={nutrition.proteinPerKg}
          unit="г/кг"
          delta={`${fmt(nutrition.avgProtein)} г в день · цель ${fmt(targets.protein)} г`}
          tone={nutrition.proteinPerKg >= 1.6 ? "good" : "warn"}
        />
        <Stat
          label="Вес / талия"
          value={fmt(profile.weight, 1)}
          unit="кг"
          delta={
            weightChange?.delta != null
              ? `${signed(weightChange.delta)} кг · талия ${waist?.delta != null ? `${signed(waist.delta)} см` : "—"}`
              : "нет замеров"
          }
          tone={(weightChange?.delta ?? 0) <= 0 ? "good" : "warn"}
        />
      </div>

      {/* AI insight */}
      <Card className="p-5 sm:p-6">
        <SectionHeading
          title="ИИ-тренер"
          subtitle={
            lastAnalysis
              ? `${lastAnalysis.title} · ${formatDate(lastAnalysis.createdAt.slice(0, 10), "d MMM")} · ${lastAnalysis.provider}`
              : "Разбор тренировок, питания и тела"
          }
          icon={<Sparkles className="size-5" />}
          action={
            <Link href="/coach">
              <Btn size="sm">
                {lastAnalysis ? "Все разборы" : "Сделать анализ"} <ArrowRight className="size-3.5" />
              </Btn>
            </Link>
          }
        />
        {lastAnalysis ? (
          <div className="mt-4 flex flex-col gap-4 sm:flex-row sm:items-center">
            <div className="shrink-0">
              <Ring
                value={lastAnalysis.score ?? 0}
                max={100}
                size={104}
                stroke={10}
                from="#a6f97c"
                to="#46e0ff"
              >
                <div>
                  <p className="text-[22px] font-semibold leading-none text-white">
                    {lastAnalysis.score ?? "—"}
                  </p>
                  <p className="mt-1 text-[10px] uppercase tracking-[0.08em] text-mist/80">индекс</p>
                </div>
              </Ring>
            </div>
            <p className="text-[13.5px] leading-relaxed text-white/85">{lastAnalysis.summary}</p>
          </div>
        ) : (
          <p className="mt-4 text-[13.5px] leading-relaxed text-mist">
            Запустите разбор — модель сопоставит объём тренировок, прогрессию силовых, КБЖУ и динамику
            обхватов и сохранит выводы в приложении.
          </p>
        )}
      </Card>

      {/* Charts */}
      <div className="grid gap-4 xl:grid-cols-3">
        <Card className="p-5 xl:col-span-2">
          <SectionHeading
            title="Объём по неделям"
            subtitle="Тоннаж и количество рабочих подходов"
            icon={<TrendingUp className="size-5" />}
            action={
              <Link href="/progress" className="text-[12.5px] font-medium text-violet-glow hover:text-white">
                Прогрессия →
              </Link>
            }
          />
          <div className="mt-4">
            {training.weeklySeries.length ? (
              <TrendChart
                data={training.weeklySeries.map((w) => ({ ...w, date: w.week }))}
                series={[{ key: "volume", name: "Объём, кг", color: "#a78bfa" }]}
                area
                unit="кг"
                height={230}
              />
            ) : (
              <EmptyState title="Пока нет данных" hint="Добавьте первую тренировку." />
            )}
          </div>
        </Card>

        <Card className="p-5">
          <SectionHeading
            title="Мышечные группы"
            subtitle="Распределение подходов за 90 дней"
            icon={<LineChart className="size-5" />}
          />
          <div className="mt-4">
            {training.muscleSplit.length ? (
              <BarsChart
                data={training.muscleSplit.map((m) => ({
                  name: MUSCLE_LABELS[m.group] ?? m.group,
                  sets: m.sets,
                  share: m.share,
                }))}
                xKey="name"
                series={[{ key: "sets", name: "Подходы", color: "#46e0ff" }]}
                unit="подх."
                height={230}
                horizontal
              />
            ) : (
              <EmptyState title="Нет данных" />
            )}
          </div>
        </Card>
      </div>

      {/* Progression + body */}
      <div className="grid gap-4 xl:grid-cols-3">
        <Card className="p-5 xl:col-span-2">
          <SectionHeading
            title="Прогрессия силовых"
            subtitle="Расчётный 1ПМ (Эппли) по упражнениям"
            icon={<Trophy className="size-5" />}
          />
          <div className="mt-4 space-y-2.5">
            {topProgress.length ? (
              topProgress.map((p) => (
                <div
                  key={p.exercise}
                  className="glass-soft flex items-center gap-3 rounded-2xl px-4 py-3"
                >
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[13.5px] font-semibold text-white">{p.exercise}</p>
                    <p className="mt-0.5 text-[11.5px] text-mist">
                      {MUSCLE_LABELS[p.muscleGroup] ?? p.muscleGroup} · {p.sessions} сессий ·{" "}
                      {p.unit === "kg" ? `${fmt(p.firstValue, 1)} → ${fmt(p.lastValue, 1)} кг` : `${fmt(p.firstValue)} → ${fmt(p.lastValue)} сек`}
                    </p>
                  </div>
                  <span
                    className={
                      "flex items-center gap-1 rounded-full px-2.5 py-1 text-[12px] font-semibold " +
                      (p.trend === "up"
                        ? "bg-lime-glow/14 text-lime-glow"
                        : p.trend === "down"
                          ? "bg-rose-glow/14 text-rose-glow"
                          : "bg-white/8 text-mist")
                    }
                  >
                    {p.trend === "up" ? (
                      <TrendingUp className="size-3.5" />
                    ) : p.trend === "down" ? (
                      <TrendingDown className="size-3.5" />
                    ) : null}
                    {signed(p.changePct, 1)}%
                  </span>
                </div>
              ))
            ) : (
              <EmptyState title="Нет прогрессии" hint="Записывайте рабочие подходы, чтобы видеть рост e1RM." />
            )}
          </div>
        </Card>

        <Card className="p-5">
          <SectionHeading
            title="Обхваты"
            subtitle={
              body.measurementCount
                ? `${body.measurementCount} замеров · плечи/талия ${body.ratio ?? "—"}`
                : "Нет замеров"
            }
            icon={<Ruler className="size-5" />}
            action={
              <Link href="/body" className="text-[12.5px] font-medium text-violet-glow hover:text-white">
                Все →
              </Link>
            }
          />
          <div className="mt-4 grid grid-cols-2 gap-2">
            {body.changes
              .filter((c) => c.latest !== null)
              .slice(0, 8)
              .map((c) => (
                <div key={c.key} className="glass-inset rounded-2xl px-3 py-2.5">
                  <p className="text-[11px] text-mist/80">{c.label}</p>
                  <p className="mt-0.5 flex items-baseline gap-1.5 text-[15px] font-semibold text-white">
                    {fmt(c.latest, 1)}
                    <span className="text-[11px] font-medium text-mist">см</span>
                    {c.delta !== null && c.delta !== 0 ? (
                      <span
                        className={
                          "ml-auto text-[11px] font-semibold " +
                          (c.key === "waist"
                            ? c.delta < 0
                              ? "text-lime-glow"
                              : "text-amber-glow"
                            : c.delta > 0
                              ? "text-lime-glow"
                              : "text-rose-glow")
                        }
                      >
                        {signed(c.delta)}
                      </span>
                    ) : null}
                  </p>
                </div>
              ))}
            {body.changes.every((c) => c.latest === null) ? (
              <div className="col-span-2">
                <EmptyState title="Замеров пока нет" hint="Добавьте первый обхват." />
              </div>
            ) : null}
          </div>
        </Card>
      </div>

      {/* Today meals + recent workouts */}
      <div className="grid gap-4 xl:grid-cols-2">
        <Card className="p-5">
          <SectionHeading
            title="Сегодня в дневнике"
            subtitle={`${day.entries.length} записей · ${pct(day.totals.kcal, targets.calories)}% калорий`}
            icon={<Flame className="size-5" />}
            action={
              <Link href="/nutrition" className="text-[12.5px] font-medium text-violet-glow hover:text-white">
                Дневник →
              </Link>
            }
          />
          <div className="mt-4 space-y-2">
            {day.entries.length ? (
              day.entries.slice(0, 6).map((e) => (
                <div key={e.id} className="flex items-center gap-3 rounded-2xl px-1 py-1.5">
                  <span className="glass-inset w-[74px] shrink-0 rounded-xl px-2 py-1 text-center text-[11px] text-mist">
                    {MEAL_LABELS[e.meal] ?? e.meal}
                  </span>
                  <span className="min-w-0 flex-1 truncate text-[13px] text-white/90">{e.name}</span>
                  <span className="shrink-0 text-[11.5px] text-mist">{fmt(e.grams)} г</span>
                  <span className="w-[62px] shrink-0 text-right text-[12.5px] font-semibold text-white">
                    {fmt(e.kcal)}
                  </span>
                </div>
              ))
            ) : (
              <EmptyState
                title="День пустой"
                hint="Добавьте первый приём пищи, чтобы видеть КБЖУ."
                action={
                  <Link href="/nutrition?add=1">
                    <Btn size="sm" variant="primary">
                      <CalendarPlus className="size-3.5" /> Добавить
                    </Btn>
                  </Link>
                }
              />
            )}
          </div>
        </Card>

        <Card className="p-5">
          <SectionHeading
            title="Последние тренировки"
            subtitle={`${training.avgSetsPerWorkout} подходов · ${training.avgDuration} мин в среднем`}
            icon={<Dumbbell className="size-5" />}
            action={
              <Link href="/workouts" className="text-[12.5px] font-medium text-violet-glow hover:text-white">
                Журнал →
              </Link>
            }
          />
          <div className="mt-4 space-y-2">
            {recent.length ? (
              recent.map((w) => (
                <Link
                  key={w.id}
                  href={`/workouts?id=${w.id}`}
                  className="glass-soft flex items-center gap-3 rounded-2xl px-4 py-3 transition-colors hover:border-white/20"
                >
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[13.5px] font-semibold text-white">{w.title}</p>
                    <p className="mt-0.5 text-[11.5px] text-mist">
                      {formatDate(w.date, "d MMM, EEEE")}
                      {w.durationMinutes ? ` · ${w.durationMinutes} мин` : ""}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-[13px] font-semibold text-white">{fmt(w.totalVolume)} кг</p>
                    <p className="text-[11px] text-mist">{w.totalSets} подходов</p>
                  </div>
                </Link>
              ))
            ) : (
              <EmptyState
                title="Тренировок ещё нет"
                hint="Создайте первую — объём и прогрессия посчитаются автоматически."
                action={
                  <Link href="/workouts?new=1">
                    <Btn size="sm" variant="primary">
                      <Dumbbell className="size-3.5" /> Начать
                    </Btn>
                  </Link>
                }
              />
            )}
          </div>
        </Card>
      </div>

      {/* Install as an app */}
      <Card className="p-5">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
          <span className="grid size-12 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-violet-glow to-cyan-glow text-[#0b0716] shadow-[0_12px_30px_-14px_rgba(124,92,255,0.9)]">
            <Smartphone className="size-6" strokeWidth={2.2} />
          </span>
          <div className="min-w-0 flex-1">
            <p className="text-[14.5px] font-semibold text-white">Установить FORMA на телефон</p>
            <p className="mt-1 text-[12.5px] leading-relaxed text-mist">
              Android — Chrome, iPhone — Safari. Иконка на рабочем столе и запуск на весь экран без
              магазинов приложений.
            </p>
          </div>
          <div className="flex shrink-0 flex-wrap gap-2">
            <InstallButton size="md" />
            <Link href="/install">
              <Btn size="md" variant="subtle">
                Инструкция
              </Btn>
            </Link>
          </div>
        </div>
      </Card>
    </div>
  );
}
