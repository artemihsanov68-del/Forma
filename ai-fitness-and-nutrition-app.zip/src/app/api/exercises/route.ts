import { NextResponse } from "next/server";
import { asc, ilike, or } from "drizzle-orm";
import { db } from "@/db";
import { exercises } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  await ensureSeeded();
  const q = new URL(req.url).searchParams.get("q")?.trim();
  const rows = q
    ? await db
        .select()
        .from(exercises)
        .where(or(ilike(exercises.name, `%${q}%`), ilike(exercises.muscleGroup, `%${q}%`)))
        .orderBy(asc(exercises.muscleGroup), asc(exercises.name))
        .limit(60)
    : await db.select().from(exercises).orderBy(asc(exercises.muscleGroup), asc(exercises.name));
  return NextResponse.json({ exercises: rows });
}

export async function POST(req: Request) {
  await ensureSeeded();
  const body = (await req.json()) as {
    name?: string;
    muscleGroup?: string;
    equipment?: string;
  };
  const name = body.name?.trim();
  if (!name) {
    return NextResponse.json({ error: "Укажите название упражнения" }, { status: 400 });
  }
  const existing = await db.select().from(exercises).where(ilike(exercises.name, name)).limit(1);
  if (existing[0]) return NextResponse.json({ exercise: existing[0] });
  const [created] = await db
    .insert(exercises)
    .values({
      name,
      muscleGroup: body.muscleGroup ?? "other",
      equipment: body.equipment ?? "other",
      kind: "strength",
      isCustom: true,
    })
    .returning();
  return NextResponse.json({ exercise: created });
}
