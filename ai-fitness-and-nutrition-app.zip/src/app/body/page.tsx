"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { Plus, Ruler, Save, Scale, Trash2, TrendingDown, TrendingUp } from "lucide-react";
import { api, post } from "@/lib/client";
import type { BodySummary, MeasurementDTO } from "@/lib/types";
import {
  Btn,
  Card,
  Chip,
  EmptyState,
  Field,
  Input,
  SectionHeading,
  Sheet,
  Skeleton,
  Stat,
  Textarea,
} from "@/components/ui";
import { TrendChart } from "@/components/charts";
import { MEASUREMENT_POINTS, formatDate, fmt, signed, todayISO } from "@/lib/utils";

const LINE_COLORS = ["#a78bfa", "#46e0ff", "#a6f97c", "#ffce6b", "#ff8fb1", "#5eead4"];

interface Response {
  measurements: MeasurementDTO[];
  summary: BodySummary;
}

export default function BodyPage() {
  const [data, setData] = useState<Response | null>(null);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [selected, setSelected] = useState<string[]>(["weightKg", "waist", "chest", "biceps"]);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      setData(await api<Response>("/api/measurements"));
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
    const params = new URLSearchParams(window.location.search);
    if (params.get("add")) {
      setOpen(true);
      window.history.replaceState({}, "", "/body");
    }
  }, [load]);

  const series = useMemo(() => data?.summary.series ?? [], [data]);
  const latest = data?.summary.latest;
  const changes = data?.summary.changes ?? [];

  if (loading || !data) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-52 w-full" />
        <Skeleton className="h-80 w-full" />
      </div>
    );
  }

  async function remove(id: number) {
    await api(`/api/measurements?id=${id}`, { method: "DELETE" });
    void load();
  }

  return (
    <div className="space-y-5">
      <MeasurementSheet open={open} onClose={() => setOpen(false)} onSaved={() => void load()} />

      <Card className="p-5 sm:p-6">
        <SectionHeading
          title="Обхваты и композиция тела"
          subtitle={
            data.summary.measurementCount
              ? `${data.summary.measurementCount} замеров · плечи/талия ${data.summary.ratio ?? "—"}${
                  data.summary.daysSinceLast !== null ? ` · последний ${data.summary.daysSinceLast} дн. назад` : ""
                }`
              : "Сделайте первый замер"
          }
          icon={<Ruler className="size-5" />}
          action={
            <Btn variant="primary" onClick={() => setOpen(true)}>
              <Plus className="size-4" /> Новый замер
            </Btn>
          }
        />

        {changes.some((c) => c.latest !== null) ? (
          <div className="mt-5 grid gap-2.5 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-6">
            {changes
              .filter((c) => c.latest !== null)
              .map((c) => {
                const goodDirection =
                  c.key === "waist" || c.key === "hips"
                    ? (c.delta ?? 0) <= 0
                    : (c.delta ?? 0) >= 0;
                return (
                  <div key={c.key} className="glass-soft rounded-2xl px-3.5 py-3">
                    <p className="text-[11px] uppercase tracking-[0.06em] text-mist/80">{c.label}</p>
                    <p className="mt-1 flex items-baseline gap-1 text-[19px] font-semibold text-white">
                      {fmt(c.latest, 1)}
                      <span className="text-[11px] font-medium text-mist">
                        {c.key === "weightKg" ? "кг" : "см"}
                      </span>
                    </p>
                    <p
                      className={
                        "mt-1 flex items-center gap-1 text-[11.5px] font-medium " +
                        (c.delta === null || c.delta === 0
                          ? "text-mist"
                          : goodDirection
                            ? "text-lime-glow"
                            : "text-amber-glow")
                      }
                    >
                      {c.delta !== null && c.delta !== 0 ? (
                        (c.delta ?? 0) > 0 ? (
                          <TrendingUp className="size-3" />
                        ) : (
                          <TrendingDown className="size-3" />
                        )
                      ) : null}
                      {c.delta !== null ? `${signed(c.delta)} с первого замера` : "—"}
                    </p>
                  </div>
                );
              })}
          </div>
        ) : (
          <div className="mt-5">
            <EmptyState
              icon={<Scale className="size-8" />}
              title="Замеров пока нет"
              hint="Измеряйтесь раз в 10–14 дней утром натощак: лента параллельно полу, без натяжения."
              action={
                <Btn variant="primary" onClick={() => setOpen(true)}>
                  <Plus className="size-4" /> Добавить замер
                </Btn>
              }
            />
          </div>
        )}
      </Card>

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <Stat
          label="Индекс плечи / талия"
          value={data.summary.ratio ?? "—"}
          delta={
            (data.summary.ratio ?? 0) >= 1.6
              ? "атлетическая пропорция"
              : (data.summary.ratio ?? 0) >= 1.4
                ? "хорошо, цель 1,6+"
                : "зона роста"
          }
          tone={(data.summary.ratio ?? 0) >= 1.5 ? "good" : "warn"}
        />
        <Stat
          label="Вес"
          value={fmt(latest?.weightKg as number | null, 1)}
          unit="кг"
          delta={changes.find((c) => c.key === "weightKg")?.delta != null ? `${signed(changes.find((c) => c.key === "weightKg")!.delta!)} кг за период` : "—"}
        />
        <Stat
          label="Процент жира"
          value={latest?.bodyFat != null ? fmt(latest.bodyFat as number, 1) : "—"}
          unit="%"
          delta={data.summary.bodyFatDelta != null ? `${signed(data.summary.bodyFatDelta)} п.п.` : "не измерялся"}
          tone={(data.summary.bodyFatDelta ?? 0) <= 0 ? "good" : "warn"}
        />
        <Stat
          label="Талия"
          value={fmt(latest?.waist as number | null, 1)}
          unit="см"
          delta={changes.find((c) => c.key === "waist")?.delta != null ? `${signed(changes.find((c) => c.key === "waist")!.delta!)} см` : "—"}
          tone={(changes.find((c) => c.key === "waist")?.delta ?? 0) <= 0 ? "good" : "warn"}
        />
      </div>

      <Card className="p-5">
        <SectionHeading
          title="Динамика обхватов"
          subtitle="Выберите до 4 точек для сравнения"
          icon={<TrendingUp className="size-5" />}
        />
        <div className="scroll-x mt-4 flex flex-wrap gap-2">
          {MEASUREMENT_POINTS.map((p) => (
            <Chip
              key={p.key}
              active={selected.includes(p.key)}
              onClick={() =>
                setSelected((prev) =>
                  prev.includes(p.key)
                    ? prev.filter((k) => k !== p.key)
                    : prev.length >= 4
                      ? [...prev.slice(1), p.key]
                      : [...prev, p.key],
                )
              }
            >
              {p.label}
            </Chip>
          ))}
        </div>
        <div className="mt-4">
          {series.length > 1 && selected.length ? (
            <TrendChart
              data={series}
              unit="см"
              height={300}
              series={selected.map((key, i) => ({
                key,
                name: MEASUREMENT_POINTS.find((p) => p.key === key)?.label ?? key,
                color: LINE_COLORS[MEASUREMENT_POINTS.findIndex((p) => p.key === key) % LINE_COLORS.length] ?? LINE_COLORS[i],
              }))}
            />
          ) : (
            <EmptyState
              title="Нужно минимум два замера"
              hint="После второго замера здесь появится график динамики."
            />
          )}
        </div>
      </Card>

      <Card className="p-5">
        <SectionHeading
          title="История замеров"
          subtitle={`${data.measurements.length} записей`}
          icon={<Ruler className="size-5" />}
        />
        <div className="thin-scroll mt-4 max-h-[420px] space-y-2 overflow-y-auto pr-1">
          {[...data.measurements]
            .sort((a, b) => b.date.localeCompare(a.date))
            .map((m) => (
              <div key={m.id} className="glass-inset rounded-2xl px-4 py-3">
                <div className="flex items-center gap-3">
                  <div className="min-w-0 flex-1">
                    <p className="text-[13.5px] font-semibold text-white">{formatDate(m.date, "d MMMM yyyy")}</p>
                    <p className="mt-0.5 truncate text-[11.5px] text-mist">
                      {MEASUREMENT_POINTS.map((p) => {
                        const v = (m as unknown as Record<string, number | null>)[p.key];
                        return v ? `${p.short} ${fmt(v, 1)}` : null;
                      })
                        .filter(Boolean)
                        .join(" · ")}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => void remove(m.id)}
                    className="grid size-8 shrink-0 place-items-center rounded-xl text-mist/60 transition-colors hover:bg-rose-500/15 hover:text-rose-glow"
                    title="Удалить"
                  >
                    <Trash2 className="size-3.5" />
                  </button>
                </div>
                {m.notes ? <p className="mt-2 text-[12px] text-mist/85">{m.notes}</p> : null}
              </div>
            ))}
          {!data.measurements.length ? <EmptyState title="История пуста" /> : null}
        </div>
      </Card>
    </div>
  );
}

function MeasurementSheet({
  open,
  onClose,
  onSaved,
}: {
  open: boolean;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [form, setForm] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!open) return;
    const initial: Record<string, string> = { date: todayISO(), notes: "" };
    for (const p of MEASUREMENT_POINTS) initial[p.key] = "";
    initial.bodyFat = "";
    setForm(initial);
    setError(null);
  }, [open]);

  const set = (k: string, v: string) => setForm((f) => ({ ...f, [k]: v }));

  async function save() {
    setSaving(true);
    setError(null);
    try {
      const payload: Record<string, unknown> = { date: form.date || todayISO(), notes: form.notes || null };
      for (const p of [...MEASUREMENT_POINTS.map((x) => x.key), "bodyFat"]) {
        payload[p] = form[p] === "" ? null : Number(form[p]);
      }
      await post("/api/measurements", payload);
      onSaved();
      onClose();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Не удалось сохранить");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Sheet
      open={open}
      onClose={onClose}
      wide
      title="Новый замер"
      subtitle="Заполните только то, что измерили сегодня"
      footer={
        <div className="flex items-center gap-3">
          {error ? <span className="flex-1 text-[12px] text-rose-glow">{error}</span> : <span className="flex-1" />}
          <Btn onClick={onClose}>Отмена</Btn>
          <Btn variant="primary" onClick={() => void save()} disabled={saving}>
            <Save className="size-4" /> {saving ? "Сохраняем…" : "Сохранить"}
          </Btn>
        </div>
      }
    >
      <div className="space-y-4">
        <div className="grid gap-3.5 sm:grid-cols-2">
          <Field label="Дата">
            <Input type="date" value={form.date ?? ""} onChange={(e) => set("date", e.target.value)} />
          </Field>
          <Field label="Процент жира" hint="Опционально, по калиперу или весам">
            <Input
              type="number"
              inputMode="decimal"
              step="0.1"
              value={form.bodyFat ?? ""}
              onChange={(e) => set("bodyFat", e.target.value)}
              placeholder="18.5"
            />
          </Field>
        </div>

        <div className="grid gap-3.5 sm:grid-cols-2 lg:grid-cols-3">
          {MEASUREMENT_POINTS.map((p) => (
            <Field
              key={p.key}
              label={p.key === "weightKg" ? "Вес, кг" : `${p.label}, см`}
            >
              <Input
                type="number"
                inputMode="decimal"
                step="0.1"
                value={form[p.key] ?? ""}
                onChange={(e) => set(p.key, e.target.value)}
                placeholder={p.key === "weightKg" ? "84.2" : "0.0"}
              />
            </Field>
          ))}
        </div>

        <Field label="Заметки">
          <Textarea
            rows={2}
            value={form.notes ?? ""}
            onChange={(e) => set("notes", e.target.value)}
            placeholder="Условия замера, самочувствие"
          />
        </Field>

        <div className="glass-inset rounded-2xl p-4 text-[12px] leading-relaxed text-mist">
          <p className="font-semibold text-white/90">Протокол измерения</p>
          <p className="mt-1.5">
            Утром, натощак, после туалета. Сантиметровая лента параллельна полу и не сдавливает кожу.
            Грудь — по нижней точке лопаток и самым выступающим точкам. Плечи — по краю дельтовидных.
            Талия — по линии пупка на спокойном выдохе. Ягодицы и таз — по самым выступающим точкам.
            Бедро — под ягодичной складкой. Бицепс — в напряжении, предплечье — в самой широкой точке.
          </p>
        </div>
      </div>
    </Sheet>
  );
}
